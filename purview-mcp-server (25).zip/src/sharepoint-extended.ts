// ============================================================
// Microsoft Purview MCP Server - SharePoint Extended Module
// Full SharePoint management via Microsoft Graph API
// ============================================================

import { graphRequest, graphUpload } from "./auth.js";

// ============================================================
// 1. SITE MANAGEMENT
// ============================================================

export async function listSites(search?: string): Promise<unknown> {
  if (search) {
    return await graphRequest("GET", `/sites?search=${encodeURIComponent(search)}&$top=50`);
  }
  return await graphRequest("GET", "/sites?search=*&$top=50");
}

export async function getSiteInfo(siteUrl: string): Promise<unknown> {
  const url = new URL(siteUrl);
  const hostname = url.hostname;
  const sitePath = url.pathname.replace(/\/$/, "");
  let endpoint: string;
  if (sitePath && sitePath !== "/" && (sitePath.includes("/sites/") || sitePath.includes("/teams/"))) {
    const relativePath = sitePath.startsWith("/") ? sitePath.slice(1) : sitePath;
    endpoint = `/sites/${hostname}:/${relativePath}?$expand=drives,lists`;
  } else {
    endpoint = `/sites/${hostname}?$expand=drives,lists`;
  }
  return await graphRequest("GET", endpoint);
}

export async function createSite(displayName: string, alias: string, description?: string, isPublic?: boolean): Promise<unknown> {
  // Create a modern Team site via Graph
  const body = {
    displayName,
    alias,
    description: description || "",
    isPublic: isPublic ?? false,
  };
  // Note: This creates a group-connected team site
  const group = await graphRequest("POST", "/groups", {
    displayName,
    mailNickname: alias,
    description: description || "",
    visibility: isPublic ? "Public" : "Private",
    groupTypes: ["Unified"],
    mailEnabled: true,
    securityEnabled: false,
  });
  return group;
}

export async function getSiteAnalytics(siteUrl: string): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  return await graphRequest("GET", `/sites/${site.id}/analytics/allTime`);
}

// ============================================================
// 2. LIST MANAGEMENT
// ============================================================

export async function getLists(siteUrl: string): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  return await graphRequest("GET", `/sites/${site.id}/lists?$top=100`);
}

export async function createList(siteUrl: string, displayName: string, columns: Array<{ name: string; type: string; required?: boolean }>): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };

  const columnDefs = columns.map((col) => {
    const base: Record<string, unknown> = { name: col.name, enforceUniqueValues: false };
    switch (col.type.toLowerCase()) {
      case "text":
      case "string":
        base.text = { allowMultipleLines: false, maxLength: 255 };
        break;
      case "multiline":
        base.text = { allowMultipleLines: true };
        break;
      case "number":
        base.number = {};
        break;
      case "datetime":
      case "date":
        base.dateTime = { format: "dateTime" };
        break;
      case "boolean":
      case "yesno":
        base.boolean = {};
        break;
      case "choice":
        base.choice = { choices: ["Option 1", "Option 2", "Option 3"] };
        break;
      case "person":
        base.personOrGroup = {};
        break;
      case "currency":
        base.currency = {};
        break;
    }
    if (col.required) base.required = true;
    return base;
  });

  const body = {
    displayName,
    list: { template: "genericList" },
    columns: columnDefs,
  };

  return await graphRequest("POST", `/sites/${site.id}/lists`, body);
}

export async function getListItems(siteUrl: string, listName: string, top?: number, filter?: string, select?: string): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  const lists = await graphRequest("GET", `/sites/${site.id}/lists`) as { value: Array<{ id: string; displayName: string }> };
  const list = lists.value.find((l) => l.displayName.toLowerCase() === listName.toLowerCase());
  if (!list) throw new Error(`List "${listName}" not found. Available: ${lists.value.map((l) => l.displayName).join(", ")}`);

  let endpoint = `/sites/${site.id}/lists/${list.id}/items?$expand=fields&$top=${top || 100}`;
  if (filter) endpoint += `&$filter=${encodeURIComponent(filter)}`;
  if (select) endpoint += `&$select=${encodeURIComponent(select)}`;

  return await graphRequest("GET", endpoint);
}

export async function addListItem(siteUrl: string, listName: string, fields: Record<string, unknown>): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  const lists = await graphRequest("GET", `/sites/${site.id}/lists`) as { value: Array<{ id: string; displayName: string }> };
  const list = lists.value.find((l) => l.displayName.toLowerCase() === listName.toLowerCase());
  if (!list) throw new Error(`List "${listName}" not found.`);

  return await graphRequest("POST", `/sites/${site.id}/lists/${list.id}/items`, { fields });
}

export async function updateListItem(siteUrl: string, listName: string, itemId: string, fields: Record<string, unknown>): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  const lists = await graphRequest("GET", `/sites/${site.id}/lists`) as { value: Array<{ id: string; displayName: string }> };
  const list = lists.value.find((l) => l.displayName.toLowerCase() === listName.toLowerCase());
  if (!list) throw new Error(`List "${listName}" not found.`);

  return await graphRequest("PATCH", `/sites/${site.id}/lists/${list.id}/items/${itemId}/fields`, fields);
}

export async function deleteListItem(siteUrl: string, listName: string, itemId: string): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  const lists = await graphRequest("GET", `/sites/${site.id}/lists`) as { value: Array<{ id: string; displayName: string }> };
  const list = lists.value.find((l) => l.displayName.toLowerCase() === listName.toLowerCase());
  if (!list) throw new Error(`List "${listName}" not found.`);

  return await graphRequest("DELETE", `/sites/${site.id}/lists/${list.id}/items/${itemId}`);
}

// ============================================================
// 3. FILE OPERATIONS
// ============================================================

export async function getFileMetadata(siteUrl: string, docLibrary: string, filePath: string): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  const drives = await graphRequest("GET", `/sites/${site.id}/drives`) as { value: Array<{ id: string; name: string }> };
  const drive = drives.value.find((d) => d.name.toLowerCase() === docLibrary.toLowerCase());
  if (!drive) throw new Error(`Library "${docLibrary}" not found.`);

  const cleanPath = filePath.replace(/^\//, "");
  return await graphRequest("GET", `/sites/${site.id}/drives/${drive.id}/items/root:/${cleanPath}`);
}

export async function downloadFileUrl(siteUrl: string, docLibrary: string, filePath: string): Promise<string> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  const drives = await graphRequest("GET", `/sites/${site.id}/drives`) as { value: Array<{ id: string; name: string }> };
  const drive = drives.value.find((d) => d.name.toLowerCase() === docLibrary.toLowerCase());
  if (!drive) throw new Error(`Library "${docLibrary}" not found.`);

  const cleanPath = filePath.replace(/^\//, "");
  const item = await graphRequest("GET", `/sites/${site.id}/drives/${drive.id}/items/root:/${cleanPath}`) as { ["@microsoft.graph.downloadUrl"]?: string; webUrl: string };
  return item["@microsoft.graph.downloadUrl"] || item.webUrl;
}

export async function deleteFile(siteUrl: string, docLibrary: string, filePath: string): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  const drives = await graphRequest("GET", `/sites/${site.id}/drives`) as { value: Array<{ id: string; name: string }> };
  const drive = drives.value.find((d) => d.name.toLowerCase() === docLibrary.toLowerCase());
  if (!drive) throw new Error(`Library "${docLibrary}" not found.`);

  const cleanPath = filePath.replace(/^\//, "");
  return await graphRequest("DELETE", `/sites/${site.id}/drives/${drive.id}/items/root:/${cleanPath}`);
}

export async function moveFile(siteUrl: string, docLibrary: string, sourcePath: string, destFolder: string, newName?: string): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  const drives = await graphRequest("GET", `/sites/${site.id}/drives`) as { value: Array<{ id: string; name: string }> };
  const drive = drives.value.find((d) => d.name.toLowerCase() === docLibrary.toLowerCase());
  if (!drive) throw new Error(`Library "${docLibrary}" not found.`);

  const cleanSource = sourcePath.replace(/^\//, "");
  const cleanDest = destFolder.replace(/^\/|\/$/g, "");

  // Get the destination folder's item ID
  const destItem = await graphRequest("GET", `/sites/${site.id}/drives/${drive.id}/items/root:/${cleanDest}`) as { id: string };

  const body: Record<string, unknown> = {
    parentReference: { driveId: drive.id, id: destItem.id },
  };
  if (newName) body.name = newName;

  return await graphRequest("PATCH", `/sites/${site.id}/drives/${drive.id}/items/root:/${cleanSource}`, body);
}

export async function copyFile(siteUrl: string, docLibrary: string, sourcePath: string, destFolder: string, newName?: string): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  const drives = await graphRequest("GET", `/sites/${site.id}/drives`) as { value: Array<{ id: string; name: string }> };
  const drive = drives.value.find((d) => d.name.toLowerCase() === docLibrary.toLowerCase());
  if (!drive) throw new Error(`Library "${docLibrary}" not found.`);

  const cleanSource = sourcePath.replace(/^\//, "");
  const cleanDest = destFolder.replace(/^\/|\/$/g, "");
  const destItem = await graphRequest("GET", `/sites/${site.id}/drives/${drive.id}/items/root:/${cleanDest}`) as { id: string };

  const fileName = newName || sourcePath.split("/").pop() || "copy";

  return await graphRequest("POST", `/sites/${site.id}/drives/${drive.id}/items/root:/${cleanSource}:/copy`, {
    parentReference: { driveId: drive.id, id: destItem.id },
    name: fileName,
  });
}

// ============================================================
// 4. SEARCH
// ============================================================

export async function searchSharePoint(query: string, entityTypes?: string[]): Promise<unknown> {
  const types = entityTypes || ["driveItem", "listItem", "site"];
  const body = {
    requests: [
      {
        entityTypes: types,
        query: { queryString: query },
        from: 0,
        size: 25,
      },
    ],
  };
  return await graphRequest("POST", "/search/query", body);
}

// ============================================================
// 5. PERMISSIONS & SHARING
// ============================================================

export async function getSitePermissions(siteUrl: string): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  return await graphRequest("GET", `/sites/${site.id}/permissions`);
}

export async function shareFile(siteUrl: string, docLibrary: string, filePath: string, recipients: string[], message?: string, role?: string): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  const drives = await graphRequest("GET", `/sites/${site.id}/drives`) as { value: Array<{ id: string; name: string }> };
  const drive = drives.value.find((d) => d.name.toLowerCase() === docLibrary.toLowerCase());
  if (!drive) throw new Error(`Library "${docLibrary}" not found.`);

  const cleanPath = filePath.replace(/^\//, "");
  const item = await graphRequest("GET", `/sites/${site.id}/drives/${drive.id}/items/root:/${cleanPath}`) as { id: string };

  const body = {
    requireSignIn: true,
    sendInvitation: true,
    roles: [role || "read"],
    recipients: recipients.map((email) => ({ email })),
    message: message || "Shared via Purview MCP Server",
  };

  return await graphRequest("POST", `/sites/${site.id}/drives/${drive.id}/items/${item.id}/invite`, body);
}

export async function createSharingLink(siteUrl: string, docLibrary: string, filePath: string, type: string, scope: string): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  const drives = await graphRequest("GET", `/sites/${site.id}/drives`) as { value: Array<{ id: string; name: string }> };
  const drive = drives.value.find((d) => d.name.toLowerCase() === docLibrary.toLowerCase());
  if (!drive) throw new Error(`Library "${docLibrary}" not found.`);

  const cleanPath = filePath.replace(/^\//, "");
  const item = await graphRequest("GET", `/sites/${site.id}/drives/${drive.id}/items/root:/${cleanPath}`) as { id: string };

  return await graphRequest("POST", `/sites/${site.id}/drives/${drive.id}/items/${item.id}/createLink`, {
    type: type || "view",
    scope: scope || "organization",
  });
}

// ============================================================
// 6. RECYCLE BIN
// ============================================================

export async function getRecycleBin(siteUrl: string, docLibrary: string): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  const drives = await graphRequest("GET", `/sites/${site.id}/drives`) as { value: Array<{ id: string; name: string }> };
  const drive = drives.value.find((d) => d.name.toLowerCase() === docLibrary.toLowerCase());
  if (!drive) throw new Error(`Library "${docLibrary}" not found.`);

  // Get recently deleted items via delta
  return await graphRequest("GET", `/sites/${site.id}/drives/${drive.id}/items/root/delta?$top=50`);
}

// ============================================================
// 7. SITE PAGES & CONTENT
// ============================================================

export async function getSitePages(siteUrl: string): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  return await graphRequest("GET", `/sites/${site.id}/pages?$top=50`);
}

export async function getSubsites(siteUrl: string): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  return await graphRequest("GET", `/sites/${site.id}/sites?$top=50`);
}

// ============================================================
// 8. COLUMNS & CONTENT TYPES
// ============================================================

export async function getSiteColumns(siteUrl: string): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  return await graphRequest("GET", `/sites/${site.id}/columns?$top=100`);
}

export async function getContentTypes(siteUrl: string): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  return await graphRequest("GET", `/sites/${site.id}/contentTypes?$top=100`);
}

export async function getListColumns(siteUrl: string, listName: string): Promise<unknown> {
  const site = await getSiteInfo(siteUrl) as { id: string };
  const lists = await graphRequest("GET", `/sites/${site.id}/lists`) as { value: Array<{ id: string; displayName: string }> };
  const list = lists.value.find((l) => l.displayName.toLowerCase() === listName.toLowerCase());
  if (!list) throw new Error(`List "${listName}" not found.`);

  return await graphRequest("GET", `/sites/${site.id}/lists/${list.id}/columns`);
}
