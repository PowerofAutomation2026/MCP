// ============================================================
// Microsoft Purview MCP Server - Analytics Module
// Advanced audit log analysis, threat hunting, risk scoring
// ============================================================

import { AuditRecord } from "./types.js";

// ============================================================
// 1. RISK SCORING ENGINE
// ============================================================

interface RiskScore {
  record: {
    timestamp: string;
    user: string;
    operation: string;
    service: string;
    clientIp: string;
    objectId?: string;
  };
  riskLevel: "critical" | "high" | "medium" | "low" | "info";
  riskScore: number; // 0-100
  reasons: string[];
}

const HIGH_RISK_OPERATIONS = new Set([
  "UserLoginFailed",
  "PasswordChanged",
  "ResetUserPassword",
  "Add member to role.",
  "Remove member from role.",
  "Set-AdminAuditLogConfig",
  "New-TransportRule",
  "Remove-TransportRule",
  "Set-TransportRule",
  "Disable-Mailbox",
  "Remove-Mailbox",
  "Set-Mailbox",
  "Add-MailboxPermission",
  "FileDeletedFirstStageRecycleBin",
  "FileDeletedSecondStageRecycleBin",
  "SharingPolicyChanged",
  "CompanySharePointExternalSharingPolicyChanged",
  "SharingInvitationCreated",
  "AnonymousLinkCreated",
  "SensitivityLabelUpdated",
  "DLPRuleMatch",
  "FileDownloaded",
  "FileSyncDownloadedFull",
  "MailItemsAccessed",
  "SearchQueryPerformed",
  "MemberAdded",
  "MemberRoleChanged",
  "ApplicationAdminConsentGranted",
  "Add app role assignment grant to user.",
  "Consent to application.",
  "Add service principal.",
  "Update application.",
  "Add delegated permission grant.",
]);

const SENSITIVE_SERVICES = new Set([
  "AzureActiveDirectory",
  "SecurityComplianceCenter",
  "Exchange",
]);

export function analyzeRisks(records: AuditRecord[]): {
  summary: {
    totalRecords: number;
    criticalCount: number;
    highCount: number;
    mediumCount: number;
    lowCount: number;
    topRisks: string[];
  };
  criticalFindings: RiskScore[];
  highFindings: RiskScore[];
  riskByUser: Record<string, { totalScore: number; eventCount: number; avgScore: number }>;
  riskByOperation: Record<string, { count: number; avgScore: number }>;
} {
  const scored: RiskScore[] = [];

  for (const r of records) {
    const reasons: string[] = [];
    let score = 0;

    // High-risk operation
    if (HIGH_RISK_OPERATIONS.has(r.operation)) {
      score += 30;
      reasons.push(`High-risk operation: ${r.operation}`);
    }

    // Sensitive service
    if (SENSITIVE_SERVICES.has(r.service)) {
      score += 10;
      reasons.push(`Sensitive service: ${r.service}`);
    }

    // Off-hours activity (before 6 AM or after 10 PM UTC)
    const hour = new Date(r.createdDateTime).getUTCHours();
    if (hour < 6 || hour > 22) {
      score += 15;
      reasons.push(`Off-hours activity (${hour}:00 UTC)`);
    }

    // Failed login
    if (r.operation === "UserLoginFailed") {
      score += 25;
      reasons.push("Failed login attempt");
    }

    // Bulk file operations (check auditData for indicators)
    if (
      r.operation.includes("FileDeleted") ||
      r.operation.includes("FileDownloaded")
    ) {
      score += 15;
      reasons.push(`Sensitive file operation: ${r.operation}`);
    }

    // External sharing
    if (
      r.operation.includes("Sharing") ||
      r.operation.includes("AnonymousLink")
    ) {
      score += 20;
      reasons.push(`External sharing activity: ${r.operation}`);
    }

    // Admin operations
    if (
      r.operation.includes("Admin") ||
      r.operation.includes("role") ||
      r.operation.includes("Role")
    ) {
      score += 20;
      reasons.push(`Administrative action: ${r.operation}`);
    }

    // Permission grants
    if (
      r.operation.includes("Consent") ||
      r.operation.includes("permission") ||
      r.operation.includes("Permission")
    ) {
      score += 25;
      reasons.push(`Permission/consent change: ${r.operation}`);
    }

    // DLP matches
    if (r.operation.includes("DLP") || r.operation.includes("Sensitivity")) {
      score += 30;
      reasons.push(`Data protection event: ${r.operation}`);
    }

    // Cap at 100
    score = Math.min(score, 100);

    const riskLevel: RiskScore["riskLevel"] =
      score >= 80 ? "critical" : score >= 60 ? "high" : score >= 30 ? "medium" : score >= 10 ? "low" : "info";

    if (reasons.length > 0) {
      scored.push({
        record: {
          timestamp: r.createdDateTime,
          user: r.userPrincipalName,
          operation: r.operation,
          service: r.service,
          clientIp: r.clientIp,
          objectId: r.objectId,
        },
        riskLevel,
        riskScore: score,
        reasons,
      });
    }
  }

  // Sort by risk score
  scored.sort((a, b) => b.riskScore - a.riskScore);

  const criticalFindings = scored.filter((s) => s.riskLevel === "critical").slice(0, 25);
  const highFindings = scored.filter((s) => s.riskLevel === "high").slice(0, 25);

  // Aggregate by user
  const riskByUser: Record<string, { totalScore: number; eventCount: number; avgScore: number }> = {};
  for (const s of scored) {
    const user = s.record.user || "Unknown";
    if (!riskByUser[user]) riskByUser[user] = { totalScore: 0, eventCount: 0, avgScore: 0 };
    riskByUser[user].totalScore += s.riskScore;
    riskByUser[user].eventCount++;
    riskByUser[user].avgScore = Math.round(riskByUser[user].totalScore / riskByUser[user].eventCount);
  }

  // Aggregate by operation
  const riskByOp: Record<string, { total: number; count: number }> = {};
  for (const s of scored) {
    if (!riskByOp[s.record.operation]) riskByOp[s.record.operation] = { total: 0, count: 0 };
    riskByOp[s.record.operation].total += s.riskScore;
    riskByOp[s.record.operation].count++;
  }
  const riskByOperation: Record<string, { count: number; avgScore: number }> = {};
  for (const [op, data] of Object.entries(riskByOp)) {
    riskByOperation[op] = { count: data.count, avgScore: Math.round(data.total / data.count) };
  }

  return {
    summary: {
      totalRecords: records.length,
      criticalCount: scored.filter((s) => s.riskLevel === "critical").length,
      highCount: scored.filter((s) => s.riskLevel === "high").length,
      mediumCount: scored.filter((s) => s.riskLevel === "medium").length,
      lowCount: scored.filter((s) => s.riskLevel === "low").length,
      topRisks: criticalFindings.slice(0, 5).map(
        (f) => `${f.record.user}: ${f.record.operation} (score: ${f.riskScore})`
      ),
    },
    criticalFindings,
    highFindings,
    riskByUser,
    riskByOperation,
  };
}

// ============================================================
// 2. EXECUTIVE SUMMARY GENERATOR
// ============================================================

export function generateExecutiveSummary(records: AuditRecord[]): {
  overview: string;
  keyMetrics: Record<string, number | string>;
  serviceBreakdown: Record<string, number>;
  topUsers: Array<{ user: string; actions: number }>;
  topOperations: Array<{ operation: string; count: number }>;
  hourlyDistribution: Record<string, number>;
  timeline: string;
  recommendations: string[];
} {
  // Service breakdown
  const serviceBreakdown: Record<string, number> = {};
  const userCounts: Record<string, number> = {};
  const opCounts: Record<string, number> = {};
  const hourly: Record<string, number> = {};
  const ipSet = new Set<string>();
  let failedLogins = 0;
  let fileOps = 0;
  let sharingOps = 0;
  let adminOps = 0;

  for (const r of records) {
    // Services
    serviceBreakdown[r.service] = (serviceBreakdown[r.service] || 0) + 1;

    // Users
    const user = r.userPrincipalName || "system";
    userCounts[user] = (userCounts[user] || 0) + 1;

    // Operations
    opCounts[r.operation] = (opCounts[r.operation] || 0) + 1;

    // Hourly
    const hour = new Date(r.createdDateTime).getUTCHours();
    const hourKey = `${hour.toString().padStart(2, "0")}:00`;
    hourly[hourKey] = (hourly[hourKey] || 0) + 1;

    // IPs
    if (r.clientIp) ipSet.add(r.clientIp);

    // Categories
    if (r.operation === "UserLoginFailed") failedLogins++;
    if (r.operation.includes("File")) fileOps++;
    if (r.operation.includes("Sharing") || r.operation.includes("Anonymous")) sharingOps++;
    if (r.operation.includes("Admin") || r.operation.includes("role")) adminOps++;
  }

  const topUsers = Object.entries(userCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([user, actions]) => ({ user, actions }));

  const topOperations = Object.entries(opCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 15)
    .map(([operation, count]) => ({ operation, count }));

  const uniqueUsers = Object.keys(userCounts).length;
  const uniqueIPs = ipSet.size;
  const uniqueServices = Object.keys(serviceBreakdown).length;

  // Date range
  const dates = records.map((r) => new Date(r.createdDateTime).getTime()).sort();
  const startDate = dates.length ? new Date(dates[0]).toISOString().slice(0, 10) : "N/A";
  const endDate = dates.length ? new Date(dates[dates.length - 1]).toISOString().slice(0, 10) : "N/A";

  // Peak hour
  const peakHour = Object.entries(hourly).sort((a, b) => b[1] - a[1])[0];

  // Recommendations
  const recommendations: string[] = [];
  if (failedLogins > 10) recommendations.push(`🔴 High failed login count (${failedLogins}) — investigate potential brute force or credential stuffing.`);
  if (sharingOps > 20) recommendations.push(`🟡 Elevated sharing activity (${sharingOps} events) — review external sharing policies.`);
  if (adminOps > 50) recommendations.push(`🟡 High admin operation volume (${adminOps}) — verify authorized changes.`);
  if (uniqueIPs > uniqueUsers * 3) recommendations.push(`🟡 High IP-to-user ratio — users may be accessing from many locations.`);
  if (fileOps > records.length * 0.5) recommendations.push(`ℹ️ File operations dominate (${fileOps}/${records.length}) — consider DLP policy review.`);
  if (recommendations.length === 0) recommendations.push("✅ No significant anomalies detected in this audit period.");

  const overview = `Audit period ${startDate} to ${endDate}: ${records.length.toLocaleString()} total events across ${uniqueServices} services from ${uniqueUsers} unique users and ${uniqueIPs} IP addresses. Peak activity at ${peakHour?.[0] || "N/A"} UTC with ${peakHour?.[1] || 0} events.`;

  return {
    overview,
    keyMetrics: {
      totalEvents: records.length,
      uniqueUsers,
      uniqueIPs,
      uniqueServices,
      failedLogins,
      fileOperations: fileOps,
      sharingEvents: sharingOps,
      adminActions: adminOps,
      peakHour: peakHour?.[0] || "N/A",
      dateRange: `${startDate} → ${endDate}`,
    },
    serviceBreakdown,
    topUsers,
    topOperations,
    hourlyDistribution: hourly,
    timeline: `${startDate} → ${endDate}`,
    recommendations,
  };
}

// ============================================================
// 3. THREAT HUNTING PRESETS
// ============================================================

export interface ThreatHuntPreset {
  id: string;
  name: string;
  description: string;
  mitreTactic: string;
  operationFilters?: string[];
  serviceFilters?: string[];
  recordTypeFilters?: string[];
  keywordFilter?: string;
  riskLevel: string;
}

export const THREAT_HUNT_PRESETS: ThreatHuntPreset[] = [
  {
    id: "impossible_travel",
    name: "Impossible Travel Detection",
    description: "Detect logins from geographically distant locations within a short time frame. After search completes, analyze client IPs for geographic anomalies.",
    mitreTactic: "TA0001 - Initial Access",
    operationFilters: ["UserLoggedIn"],
    serviceFilters: ["AzureActiveDirectory"],
    riskLevel: "critical",
  },
  {
    id: "brute_force",
    name: "Brute Force / Password Spray",
    description: "Detect multiple failed login attempts indicating credential attacks.",
    mitreTactic: "TA0006 - Credential Access",
    operationFilters: ["UserLoginFailed"],
    serviceFilters: ["AzureActiveDirectory"],
    riskLevel: "critical",
  },
  {
    id: "privilege_escalation",
    name: "Privilege Escalation",
    description: "Detect role assignments, admin grants, and permission changes that could indicate privilege escalation.",
    mitreTactic: "TA0004 - Privilege Escalation",
    operationFilters: [
      "Add member to role.",
      "Add app role assignment grant to user.",
      "Consent to application.",
      "Add delegated permission grant.",
      "Add service principal.",
    ],
    serviceFilters: ["AzureActiveDirectory"],
    riskLevel: "critical",
  },
  {
    id: "data_exfiltration",
    name: "Data Exfiltration Patterns",
    description: "Detect bulk file downloads, sync operations, and external sharing that may indicate data theft.",
    mitreTactic: "TA0010 - Exfiltration",
    operationFilters: [
      "FileDownloaded",
      "FileSyncDownloadedFull",
      "AnonymousLinkCreated",
      "SharingInvitationCreated",
      "CompanyLinkCreated",
    ],
    serviceFilters: ["SharePoint", "OneDrive"],
    riskLevel: "high",
  },
  {
    id: "mailbox_tampering",
    name: "Mailbox Tampering / Email Forwarding",
    description: "Detect mailbox rule creation, forwarding setup, and delegate access changes that could indicate email compromise.",
    mitreTactic: "TA0003 - Persistence",
    operationFilters: [
      "New-InboxRule",
      "Set-InboxRule",
      "Set-Mailbox",
      "Add-MailboxPermission",
      "Set-TransportRule",
      "New-TransportRule",
      "UpdateInboxRules",
    ],
    serviceFilters: ["Exchange"],
    riskLevel: "high",
  },
  {
    id: "evasion_audit_tampering",
    name: "Defense Evasion / Audit Tampering",
    description: "Detect attempts to disable or modify audit logging, security policies, or compliance configurations.",
    mitreTactic: "TA0005 - Defense Evasion",
    operationFilters: [
      "Set-AdminAuditLogConfig",
      "Set-OrganizationConfig",
      "Disable-OrganizationCustomization",
      "Remove-TransportRule",
      "DisableAuditLog",
    ],
    riskLevel: "critical",
  },
  {
    id: "oauth_abuse",
    name: "OAuth / App Consent Abuse",
    description: "Detect malicious OAuth app registrations and consent grants that could give attackers persistent access.",
    mitreTactic: "TA0003 - Persistence",
    operationFilters: [
      "Consent to application.",
      "Add service principal.",
      "Update application.",
      "Add app role assignment grant to user.",
      "Add OAuth2PermissionGrant.",
      "Add application.",
    ],
    serviceFilters: ["AzureActiveDirectory"],
    riskLevel: "critical",
  },
  {
    id: "teams_data_leak",
    name: "Teams Data Leak Detection",
    description: "Detect sensitive file sharing, guest additions, and policy changes in Microsoft Teams.",
    mitreTactic: "TA0010 - Exfiltration",
    operationFilters: [
      "MemberAdded",
      "MemberRoleChanged",
      "ChannelAdded",
      "TeamCreated",
      "TabAdded",
      "BotAddedToTeam",
      "ConnectorAdded",
    ],
    serviceFilters: ["MicrosoftTeams"],
    riskLevel: "medium",
  },
  {
    id: "copilot_sensitive",
    name: "Copilot Sensitive Data Access",
    description: "Detect Copilot interactions that may access sensitive or restricted content. Analyze CopilotInteraction events for DLP-tagged content.",
    mitreTactic: "TA0009 - Collection",
    operationFilters: ["CopilotInteraction"],
    riskLevel: "medium",
  },
  {
    id: "off_hours_access",
    name: "Off-Hours / Weekend Access",
    description: "Detect user activity outside normal business hours (before 6AM or after 10PM UTC, weekends). Post-search analysis flags these events.",
    mitreTactic: "TA0001 - Initial Access",
    operationFilters: ["UserLoggedIn", "FileAccessed", "FileDownloaded", "MailItemsAccessed"],
    riskLevel: "medium",
  },
];

export function getThreatHuntPreset(id: string): ThreatHuntPreset | undefined {
  return THREAT_HUNT_PRESETS.find((p) => p.id === id);
}

// ============================================================
// 4. COPILOT ADOPTION ANALYTICS
// ============================================================

export function analyzeCopilotAdoption(records: AuditRecord[]): {
  summary: {
    totalInteractions: number;
    uniqueUsers: number;
    dateRange: string;
    avgInteractionsPerUser: number;
    avgInteractionsPerDay: number;
    peakHour: string;
    peakDay: string;
  };
  byUser: Array<{ user: string; interactions: number; firstSeen: string; lastSeen: string }>;
  byDay: Record<string, number>;
  byHour: Record<string, number>;
  byDayOfWeek: Record<string, number>;
  byAppContext: Record<string, number>;
  adoptionTrend: string;
  recommendations: string[];
} {
  const userMap: Record<string, { count: number; first: string; last: string }> = {};
  const byDay: Record<string, number> = {};
  const byHour: Record<string, number> = {};
  const byDow: Record<string, number> = { Mon: 0, Tue: 0, Wed: 0, Thu: 0, Fri: 0, Sat: 0, Sun: 0 };
  const byApp: Record<string, number> = {};
  const dowNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  for (const r of records) {
    const dt = new Date(r.createdDateTime);
    const user = r.userPrincipalName || "Unknown";
    const day = r.createdDateTime.slice(0, 10);
    const hour = `${dt.getUTCHours().toString().padStart(2, "0")}:00`;
    const dow = dowNames[dt.getUTCDay()];

    // User stats
    if (!userMap[user]) userMap[user] = { count: 0, first: r.createdDateTime, last: r.createdDateTime };
    userMap[user].count++;
    if (r.createdDateTime < userMap[user].first) userMap[user].first = r.createdDateTime;
    if (r.createdDateTime > userMap[user].last) userMap[user].last = r.createdDateTime;

    byDay[day] = (byDay[day] || 0) + 1;
    byHour[hour] = (byHour[hour] || 0) + 1;
    byDow[dow] = (byDow[dow] || 0) + 1;

    // Extract app context from audit data
    const auditData = r.auditData || {};
    const appName = (auditData as Record<string, unknown>).AppAccessContext?.toString() ||
      (auditData as Record<string, unknown>).Application?.toString() ||
      (auditData as Record<string, unknown>).Workload?.toString() ||
      r.service || "Unknown";
    byApp[appName] = (byApp[appName] || 0) + 1;
  }

  const byUser = Object.entries(userMap)
    .map(([user, data]) => ({
      user,
      interactions: data.count,
      firstSeen: data.first.slice(0, 10),
      lastSeen: data.last.slice(0, 10),
    }))
    .sort((a, b) => b.interactions - a.interactions);

  const uniqueUsers = byUser.length;
  const days = Object.keys(byDay).sort();
  const totalDays = days.length || 1;
  const dateRange = days.length ? `${days[0]} → ${days[days.length - 1]}` : "N/A";
  const avgPerUser = uniqueUsers > 0 ? Math.round(records.length / uniqueUsers) : 0;
  const avgPerDay = Math.round(records.length / totalDays);

  const peakHour = Object.entries(byHour).sort((a, b) => b[1] - a[1])[0];
  const peakDay = Object.entries(byDay).sort((a, b) => b[1] - a[1])[0];

  // Trend analysis
  let adoptionTrend = "stable";
  if (days.length >= 4) {
    const mid = Math.floor(days.length / 2);
    const firstHalf = days.slice(0, mid).reduce((sum, d) => sum + (byDay[d] || 0), 0);
    const secondHalf = days.slice(mid).reduce((sum, d) => sum + (byDay[d] || 0), 0);
    if (secondHalf > firstHalf * 1.2) adoptionTrend = "increasing";
    else if (secondHalf < firstHalf * 0.8) adoptionTrend = "declining";
  }

  // Recommendations
  const recommendations: string[] = [];
  if (uniqueUsers < 5) recommendations.push("📈 Low adoption — consider Copilot training sessions and awareness campaigns.");
  if (adoptionTrend === "declining") recommendations.push("📉 Usage is declining — survey users about barriers to adoption.");
  if (adoptionTrend === "increasing") recommendations.push("📈 Great news — Copilot adoption is trending upward!");
  if (byDow.Sat + byDow.Sun > records.length * 0.1) recommendations.push("🕐 Notable weekend usage — users are engaging with Copilot outside work hours.");
  const topUser = byUser[0];
  if (topUser && topUser.interactions > avgPerUser * 5) recommendations.push(`⭐ Power user identified: ${topUser.user} with ${topUser.interactions} interactions — consider as Copilot champion.`);
  if (recommendations.length === 0) recommendations.push("✅ Healthy Copilot adoption across the organization.");

  return {
    summary: {
      totalInteractions: records.length,
      uniqueUsers,
      dateRange,
      avgInteractionsPerUser: avgPerUser,
      avgInteractionsPerDay: avgPerDay,
      peakHour: peakHour?.[0] || "N/A",
      peakDay: peakDay?.[0] || "N/A",
    },
    byUser: byUser.slice(0, 30),
    byDay,
    byHour,
    byDayOfWeek: byDow,
    byAppContext: byApp,
    adoptionTrend,
    recommendations,
  };
}

// ============================================================
// 5. USER ACTIVITY TIMELINE
// ============================================================

export function buildUserTimeline(
  records: AuditRecord[],
  userUpn: string
): {
  user: string;
  totalEvents: number;
  uniqueIPs: string[];
  uniqueServices: string[];
  timeline: Array<{
    timestamp: string;
    operation: string;
    service: string;
    clientIp: string;
    objectId?: string;
    riskIndicator?: string;
  }>;
  sessionAnalysis: {
    estimatedSessions: number;
    avgSessionDuration: string;
    longestGap: string;
  };
} {
  const userRecords = records
    .filter((r) => r.userPrincipalName?.toLowerCase() === userUpn.toLowerCase())
    .sort((a, b) => new Date(a.createdDateTime).getTime() - new Date(b.createdDateTime).getTime());

  const ips = new Set<string>();
  const services = new Set<string>();

  const timeline = userRecords.map((r) => {
    if (r.clientIp) ips.add(r.clientIp);
    services.add(r.service);

    let riskIndicator: string | undefined;
    if (HIGH_RISK_OPERATIONS.has(r.operation)) riskIndicator = "⚠️ HIGH RISK";
    else if (r.operation.includes("Failed")) riskIndicator = "🔴 FAILED";
    else if (r.operation.includes("Sharing") || r.operation.includes("Anonymous")) riskIndicator = "🟡 SHARING";

    return {
      timestamp: r.createdDateTime,
      operation: r.operation,
      service: r.service,
      clientIp: r.clientIp,
      objectId: r.objectId,
      riskIndicator,
    };
  });

  // Session analysis (gap > 30 min = new session)
  let sessions = 1;
  let longestGap = 0;
  const gaps: number[] = [];
  for (let i = 1; i < userRecords.length; i++) {
    const gap = new Date(userRecords[i].createdDateTime).getTime() - new Date(userRecords[i - 1].createdDateTime).getTime();
    gaps.push(gap);
    if (gap > 30 * 60 * 1000) sessions++;
    if (gap > longestGap) longestGap = gap;
  }

  const totalDuration = userRecords.length >= 2
    ? new Date(userRecords[userRecords.length - 1].createdDateTime).getTime() - new Date(userRecords[0].createdDateTime).getTime()
    : 0;
  const avgSession = sessions > 0 ? Math.round(totalDuration / sessions / 60000) : 0;

  return {
    user: userUpn,
    totalEvents: userRecords.length,
    uniqueIPs: Array.from(ips),
    uniqueServices: Array.from(services),
    timeline: timeline.slice(0, 200),
    sessionAnalysis: {
      estimatedSessions: sessions,
      avgSessionDuration: `${avgSession} minutes`,
      longestGap: `${Math.round(longestGap / 60000)} minutes`,
    },
  };
}

// ============================================================
// 6. COMPARE AUDIT PERIODS
// ============================================================

export function compareAuditPeriods(
  period1Records: AuditRecord[],
  period2Records: AuditRecord[],
  period1Label: string,
  period2Label: string
): {
  comparison: {
    period1: { label: string; totalEvents: number; uniqueUsers: number; uniqueOps: number };
    period2: { label: string; totalEvents: number; uniqueUsers: number; uniqueOps: number };
    change: { events: string; users: string; };
  };
  newOperations: string[];
  droppedOperations: string[];
  newUsers: string[];
  droppedUsers: string[];
  operationChanges: Array<{ operation: string; period1Count: number; period2Count: number; change: string }>;
  alerts: string[];
} {
  const ops1 = new Set(period1Records.map((r) => r.operation));
  const ops2 = new Set(period2Records.map((r) => r.operation));
  const users1 = new Set(period1Records.map((r) => r.userPrincipalName));
  const users2 = new Set(period2Records.map((r) => r.userPrincipalName));

  const opCount1: Record<string, number> = {};
  const opCount2: Record<string, number> = {};
  period1Records.forEach((r) => { opCount1[r.operation] = (opCount1[r.operation] || 0) + 1; });
  period2Records.forEach((r) => { opCount2[r.operation] = (opCount2[r.operation] || 0) + 1; });

  const allOps = new Set([...ops1, ...ops2]);
  const operationChanges = Array.from(allOps)
    .map((op) => {
      const c1 = opCount1[op] || 0;
      const c2 = opCount2[op] || 0;
      const pct = c1 > 0 ? Math.round(((c2 - c1) / c1) * 100) : c2 > 0 ? 100 : 0;
      return { operation: op, period1Count: c1, period2Count: c2, change: `${pct >= 0 ? "+" : ""}${pct}%` };
    })
    .sort((a, b) => Math.abs(b.period2Count - b.period1Count) - Math.abs(a.period2Count - a.period1Count))
    .slice(0, 20);

  const newOperations = Array.from(ops2).filter((o) => !ops1.has(o));
  const droppedOperations = Array.from(ops1).filter((o) => !ops2.has(o));
  const newUsers = Array.from(users2).filter((u) => !users1.has(u));
  const droppedUsers = Array.from(users1).filter((u) => !users2.has(u));

  const eventChange = period1Records.length > 0
    ? Math.round(((period2Records.length - period1Records.length) / period1Records.length) * 100)
    : 0;
  const userChange = users1.size > 0
    ? Math.round(((users2.size - users1.size) / users1.size) * 100)
    : 0;

  const alerts: string[] = [];
  if (eventChange > 50) alerts.push(`🔴 Event volume increased ${eventChange}% — investigate spike.`);
  if (newOperations.length > 5) alerts.push(`🟡 ${newOperations.length} new operation types appeared — review for anomalies.`);
  if (newUsers.length > 10) alerts.push(`🟡 ${newUsers.length} new users appeared — verify legitimate access.`);

  return {
    comparison: {
      period1: { label: period1Label, totalEvents: period1Records.length, uniqueUsers: users1.size, uniqueOps: ops1.size },
      period2: { label: period2Label, totalEvents: period2Records.length, uniqueUsers: users2.size, uniqueOps: ops2.size },
      change: { events: `${eventChange >= 0 ? "+" : ""}${eventChange}%`, users: `${userChange >= 0 ? "+" : ""}${userChange}%` },
    },
    newOperations,
    droppedOperations,
    newUsers: newUsers.slice(0, 20),
    droppedUsers: droppedUsers.slice(0, 20),
    operationChanges,
    alerts,
  };
}
