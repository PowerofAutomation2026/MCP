#!/usr/bin/env node
// ============================================================
// Microsoft Purview Audit Log MCP Server
// ============================================================
// Tools:
//   1.  search_audit_log           - Create & run audit log search
//   2.  get_audit_search_status    - Check search status
//   3.  list_audit_searches        - List all searches
//   4.  get_audit_results          - Get search results
//   5.  delete_audit_search        - Delete a search
//   6.  export_audit_results       - Export results to CSV/JSON file
//   7.  full_audit_pipeline        - Search → Wait → Export → Upload (all-in-one)
//   8.  upload_to_sharepoint       - Upload file to SharePoint doc library
//   9.  list_sharepoint_files      - List files in SharePoint folder
//  10.  list_document_libraries    - List doc libraries on a site
//  11.  create_sharepoint_folder   - Create folder in doc library
//  12.  schedule_daily_audit       - Schedule recurring audit search
//  13.  list_scheduled_audits      - List all schedules
//  14.  manage_schedule            - Enable/disable/delete schedule
//  15.  run_schedule_now           - Manually trigger a schedule
//  16.  setup_copilot_daily_audit  - Pre-configured daily Copilot usage audit
//  17.  send_notification          - Send Teams/email notification manually
// ============================================================

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";

import { initializeAuth } from "./auth.js";
import {
  createAuditSearch,
  getAuditSearch,
  listAuditSearches,
  deleteAuditSearch,
  getAllAuditSearchResults,
  waitForSearchCompletion,
  exportToCSV,
  exportToJSON,
  generateExportFilename,
} from "./audit.js";
import {
  uploadFileToSharePoint,
  listSharePointFiles,
  listDocumentLibraries,
  createSharePointFolder,
} from "./sharepoint.js";
import {
  initializeScheduler,
  createScheduledAudit,
  listScheduledAudits,
  toggleSchedule,
  deleteScheduledAudit,
  runScheduleNow,
} from "./scheduler.js";
import {
  notifyAuditComplete,
  sendTeamsNotification,
  sendEmailNotification,
  sendPowerAutomateNotification,
  sendCopilotStudioNotification,
  buildAuditReportEmailBody,
} from "./notifications.js";
import type { AuditReportPayload } from "./notifications.js";
import {
  analyzeRisks,
  generateExecutiveSummary,
  THREAT_HUNT_PRESETS,
  getThreatHuntPreset,
  analyzeCopilotAdoption,
  buildUserTimeline,
  compareAuditPeriods,
} from "./analytics.js";
import {
  listSites,
  getSiteInfo,
  createSite,
  getSiteAnalytics,
  getLists,
  createList,
  getListItems,
  addListItem,
  updateListItem,
  deleteListItem,
  getFileMetadata,
  downloadFileUrl,
  deleteFile,
  moveFile,
  copyFile,
  searchSharePoint,
  getSitePermissions,
  shareFile,
  createSharingLink,
  getRecycleBin,
  getSitePages,
  getSubsites,
  getSiteColumns,
  getContentTypes,
  getListColumns,
} from "./sharepoint-extended.js";
import {
  trackCopilotAgents,
  generateCopilotHTMLReport,
  analyzeCopilotTrends,
  exportCopilotCSV,
  generateCopilotDashboard,
} from "./copilot-tracking.js";
import {
  getSecurityAlerts, getSecurityAlert, updateSecurityAlert,
  getSecurityIncidents, getSecurityIncident, updateSecurityIncident,
  getSecureScores, getSecureScoreProfiles,
  listEdiscoveryCases, getEdiscoveryCase, createEdiscoveryCase, listEdiscoveryCustodians, listEdiscoverySearches,
  getRiskDetections, getRiskyUsers, getRiskySignIns,
  runAdvancedHunting, ADVANCED_HUNTING_QUERIES,
  listRetentionLabels, getRetentionLabel,
  searchThreatIntelligence, getThreatIntelArticles,
  listSubjectRightsRequests, createSubjectRightsRequest,
  detectShadowIT, scanDataExposure, getComplianceHealthDashboard,
  listSensitivityLabels, getSensitivityLabel, assignSensitivityLabelToFile,
  getSignInLogs, getDirectoryAuditLogs,
  getServiceHealth, getServiceHealthIssues, getServiceMessages,
  listConditionalAccessPolicies, getConditionalAccessPolicy,
  getM365ActiveUsers, getEmailActivityReport, getSharePointActivityReport,
  getTeamsActivityReport, getOneDriveActivityReport,
  removeSensitivityLabelFromFile, removeSiteSensitivityLabel, bulkRemoveLabelsFromLibrary,
  applySensitivityLabelToSite, applyLabelToAllFilesInLibrary, setDefaultLibraryLabel, extractFileLabels,
  WORKLOAD_AUDIT_PRESETS, analyzeCopilotAgentSecurity, generateCopilotSecurityReport,
} from "./purview-extended.js";
import { AUDIT_RECORD_TYPES, AUDIT_SERVICES } from "./types.js";

// ============================================================
// Server Setup
// ============================================================

export const server = new Server(
  {
    name: "purview-mcp-server",
    version: "1.0.0",
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

// ============================================================
// Tool Definitions
// ============================================================

export const listToolsHandler = async () => {
  return {
    tools: [
      // --- AUDIT SEARCH TOOLS ---
      {
        name: "search_audit_log",
        description:
          "Create and start a Microsoft Purview audit log search. " +
          "Returns search ID to track progress. Use get_audit_search_status to check completion.",
        inputSchema: {
          type: "object" as const,
          properties: {
            displayName: {
              type: "string",
              description: "Friendly name for this search (e.g., 'SharePoint File Access - March 2025')",
            },
            startDateTime: {
              type: "string",
              description: "Search start date/time in ISO 8601 format (e.g., '2025-03-01T00:00:00Z')",
            },
            endDateTime: {
              type: "string",
              description: "Search end date/time in ISO 8601 format (e.g., '2025-03-31T23:59:59Z')",
            },
            operationFilters: {
              type: "array",
              items: { type: "string" },
              description:
                "Filter by operations (e.g., ['FileAccessed', 'FileModified', 'FileDeleted', 'UserLoggedIn'])",
            },
            userPrincipalNameFilters: {
              type: "array",
              items: { type: "string" },
              description: "Filter by user UPN (e.g., ['user@contoso.com'])",
            },
            ipAddressFilters: {
              type: "array",
              items: { type: "string" },
              description: "Filter by IP address",
            },
            objectIdFilters: {
              type: "array",
              items: { type: "string" },
              description: "Filter by object ID (e.g., SharePoint site URL, file path)",
            },
            recordTypeFilters: {
              type: "array",
              items: { type: "string" },
              description: `Filter by record type. Common values: ${AUDIT_RECORD_TYPES.slice(0, 20).join(", ")}...`,
            },
            serviceFilters: {
              type: "array",
              items: { type: "string" },
              description: `Filter by service. Values: ${AUDIT_SERVICES.join(", ")}`,
            },
            keywordFilter: {
              type: "string",
              description: "Keyword to search within audit records",
            },
          },
          required: ["displayName", "startDateTime", "endDateTime"],
        },
      },
      {
        name: "get_audit_search_status",
        description:
          "Check the status of an audit log search. Returns status: notStarted, running, succeeded, failed, cancelled.",
        inputSchema: {
          type: "object" as const,
          properties: {
            searchId: {
              type: "string",
              description: "The audit search ID returned from search_audit_log",
            },
          },
          required: ["searchId"],
        },
      },
      {
        name: "list_audit_searches",
        description: "List all existing Purview audit log searches in the tenant.",
        inputSchema: {
          type: "object" as const,
          properties: {},
        },
      },
      {
        name: "get_audit_results",
        description:
          "Get results from a completed audit search. Returns audit records with user, operation, service, IP, and full audit data.",
        inputSchema: {
          type: "object" as const,
          properties: {
            searchId: {
              type: "string",
              description: "The audit search ID",
            },
            maxRecords: {
              type: "number",
              description: "Maximum records to return (default: 500, max: 10000)",
            },
          },
          required: ["searchId"],
        },
      },
      {
        name: "delete_audit_search",
        description: "Delete an audit log search by ID.",
        inputSchema: {
          type: "object" as const,
          properties: {
            searchId: {
              type: "string",
              description: "The audit search ID to delete",
            },
          },
          required: ["searchId"],
        },
      },
      {
        name: "export_audit_results",
        description:
          "Export audit search results to a CSV or JSON file on disk. Returns the file path.",
        inputSchema: {
          type: "object" as const,
          properties: {
            searchId: {
              type: "string",
              description: "The audit search ID (must be in 'succeeded' status)",
            },
            format: {
              type: "string",
              enum: ["csv", "json"],
              description: "Export format: 'csv' or 'json' (default: csv)",
            },
            maxRecords: {
              type: "number",
              description: "Maximum records to export (default: 10000)",
            },
          },
          required: ["searchId"],
        },
      },

      // --- FULL PIPELINE TOOL ---
      {
        name: "full_audit_pipeline",
        description:
          "All-in-one: Create audit search → Wait for completion → Export to CSV/JSON → Upload to SharePoint. " +
          "This is the primary workflow tool. Returns SharePoint file URL.",
        inputSchema: {
          type: "object" as const,
          properties: {
            displayName: {
              type: "string",
              description: "Friendly name for the search",
            },
            startDateTime: {
              type: "string",
              description: "Start date/time ISO 8601",
            },
            endDateTime: {
              type: "string",
              description: "End date/time ISO 8601",
            },
            operationFilters: {
              type: "array",
              items: { type: "string" },
              description: "Filter by operations",
            },
            userPrincipalNameFilters: {
              type: "array",
              items: { type: "string" },
              description: "Filter by user UPN",
            },
            recordTypeFilters: {
              type: "array",
              items: { type: "string" },
              description: "Filter by record type",
            },
            serviceFilters: {
              type: "array",
              items: { type: "string" },
              description: "Filter by service",
            },
            keywordFilter: {
              type: "string",
              description: "Keyword filter",
            },
            format: {
              type: "string",
              enum: ["csv", "json"],
              description: "Export format (default: csv)",
            },
            sharePointSiteUrl: {
              type: "string",
              description: "SharePoint site URL (e.g., 'https://contoso.sharepoint.com/sites/Audit')",
            },
            docLibrary: {
              type: "string",
              description: "Document library name (e.g., 'Documents', 'Audit Reports')",
            },
            targetFolder: {
              type: "string",
              description: "Target folder path within the doc library (optional)",
            },
          },
          required: ["displayName", "startDateTime", "endDateTime", "sharePointSiteUrl", "docLibrary"],
        },
      },

      // --- SHAREPOINT TOOLS ---
      {
        name: "upload_to_sharepoint",
        description:
          "Upload a local file to a SharePoint document library. Supports files up to 250MB.",
        inputSchema: {
          type: "object" as const,
          properties: {
            localFilePath: {
              type: "string",
              description: "Local path to the file to upload",
            },
            sharePointSiteUrl: {
              type: "string",
              description: "SharePoint site URL",
            },
            docLibrary: {
              type: "string",
              description: "Document library name",
            },
            targetFolder: {
              type: "string",
              description: "Target folder path (optional)",
            },
          },
          required: ["localFilePath", "sharePointSiteUrl", "docLibrary"],
        },
      },
      {
        name: "list_sharepoint_files",
        description: "List files in a SharePoint document library or folder.",
        inputSchema: {
          type: "object" as const,
          properties: {
            sharePointSiteUrl: {
              type: "string",
              description: "SharePoint site URL",
            },
            docLibrary: {
              type: "string",
              description: "Document library name",
            },
            folderPath: {
              type: "string",
              description: "Folder path to list (optional, lists root if omitted)",
            },
          },
          required: ["sharePointSiteUrl", "docLibrary"],
        },
      },
      {
        name: "list_document_libraries",
        description: "List all document libraries on a SharePoint site.",
        inputSchema: {
          type: "object" as const,
          properties: {
            sharePointSiteUrl: {
              type: "string",
              description: "SharePoint site URL",
            },
          },
          required: ["sharePointSiteUrl"],
        },
      },
      {
        name: "create_sharepoint_folder",
        description: "Create a new folder in a SharePoint document library.",
        inputSchema: {
          type: "object" as const,
          properties: {
            sharePointSiteUrl: {
              type: "string",
              description: "SharePoint site URL",
            },
            docLibrary: {
              type: "string",
              description: "Document library name",
            },
            folderName: {
              type: "string",
              description: "Name of the new folder",
            },
            parentFolder: {
              type: "string",
              description: "Parent folder path (optional, creates at root if omitted)",
            },
          },
          required: ["sharePointSiteUrl", "docLibrary", "folderName"],
        },
      },

      // --- SCHEDULER TOOLS ---
      {
        name: "schedule_daily_audit",
        description:
          "Schedule a recurring audit search that runs automatically, exports results, and uploads to SharePoint. " +
          "Uses cron syntax for scheduling. The search will cover the last 24 hours each run.",
        inputSchema: {
          type: "object" as const,
          properties: {
            name: {
              type: "string",
              description: "Schedule name (e.g., 'Daily SharePoint Audit')",
            },
            cronExpression: {
              type: "string",
              description:
                "Cron expression for schedule. Format: 'min hour day month weekday'. " +
                "Examples: '0 6 * * *' = daily 6AM UTC, '0 8 * * 1-5' = weekdays 8AM UTC, " +
                "'0 0 * * 0' = weekly Sunday midnight, '0 */6 * * *' = every 6 hours",
            },
            operationFilters: {
              type: "array",
              items: { type: "string" },
              description: "Operations to filter",
            },
            userPrincipalNameFilters: {
              type: "array",
              items: { type: "string" },
              description: "Users to filter",
            },
            recordTypeFilters: {
              type: "array",
              items: { type: "string" },
              description: "Record types to filter",
            },
            serviceFilters: {
              type: "array",
              items: { type: "string" },
              description: "Services to filter",
            },
            keywordFilter: {
              type: "string",
              description: "Keyword to filter",
            },
            sharePointSiteUrl: {
              type: "string",
              description: "SharePoint site URL for auto-upload",
            },
            sharePointDocLibrary: {
              type: "string",
              description: "Document library name for auto-upload",
            },
            sharePointFolder: {
              type: "string",
              description: "Folder within doc library (optional)",
            },
            teamsWebhookUrl: {
              type: "string",
              description:
                "Teams Incoming Webhook URL for notifications (legacy option).",
            },
            powerAutomateUrl: {
              type: "string",
              description:
                "Power Automate flow HTTP trigger URL. The flow receives a JSON payload with reportName, recordCount, " +
                "startDate, endDate, filters, sharePointUrl, fileName, status, timestamp. " +
                "RECOMMENDED: Use this instead of Teams webhook for enterprise notification workflows.",
            },
            copilotStudioUrl: {
              type: "string",
              description:
                "Copilot Studio agent HTTP trigger URL. The agent receives the same JSON payload and can post " +
                "Adaptive Cards to Teams, send emails, create tasks, or trigger other actions.",
            },
            emailRecipients: {
              type: "array",
              items: { type: "string" },
              description:
                "Email addresses to notify when report is uploaded (requires Mail.Send permission)",
            },
            emailSender: {
              type: "string",
              description: "Sender email address for notifications (must be a valid mailbox in your tenant)",
            },
          },
          required: ["name", "cronExpression", "sharePointSiteUrl", "sharePointDocLibrary"],
        },
      },
      {
        name: "list_scheduled_audits",
        description: "List all scheduled audit searches with their status and last run info.",
        inputSchema: {
          type: "object" as const,
          properties: {},
        },
      },
      {
        name: "manage_schedule",
        description: "Enable, disable, or delete a scheduled audit.",
        inputSchema: {
          type: "object" as const,
          properties: {
            scheduleId: {
              type: "string",
              description: "The schedule ID",
            },
            action: {
              type: "string",
              enum: ["enable", "disable", "delete"],
              description: "Action to perform",
            },
          },
          required: ["scheduleId", "action"],
        },
      },
      {
        name: "run_schedule_now",
        description:
          "Manually trigger a scheduled audit immediately (outside its normal cron schedule). " +
          "Runs the full pipeline: search → export → upload to SharePoint → send notification.",
        inputSchema: {
          type: "object" as const,
          properties: {
            scheduleId: {
              type: "string",
              description: "The schedule ID to trigger",
            },
          },
          required: ["scheduleId"],
        },
      },

      // --- COPILOT DAILY AUDIT (PRE-CONFIGURED) ---
      {
        name: "setup_copilot_daily_audit",
        description:
          "One-click setup: Creates a daily scheduled audit that searches for ALL Microsoft Copilot interactions " +
          "(CopilotInteraction operation) from the last 24 hours, exports results to CSV, uploads to SharePoint, " +
          "and triggers a Power Automate flow or Copilot Studio agent to post notification to Teams. " +
          "Pre-configured with the correct operation name and filters.",
        inputSchema: {
          type: "object" as const,
          properties: {
            sharePointSiteUrl: {
              type: "string",
              description: "SharePoint site URL to upload daily reports (e.g., 'https://contoso.sharepoint.com/sites/Audit')",
            },
            docLibrary: {
              type: "string",
              description: "Document library name (e.g., 'Documents', 'Copilot Audit Reports')",
            },
            targetFolder: {
              type: "string",
              description: "Folder in doc library for reports (default: 'Copilot Daily Audit')",
            },
            cronTime: {
              type: "string",
              description:
                "When to run daily. Options: '6am' = 6 AM UTC, '8am' = 8 AM UTC, '12am' = midnight UTC, " +
                "or custom cron expression. Default: '0 6 * * *' (6 AM UTC daily)",
            },
            powerAutomateUrl: {
              type: "string",
              description:
                "RECOMMENDED: Power Automate flow HTTP trigger URL. The flow receives JSON payload and can " +
                "post Adaptive Card to Teams, send email, create Planner task, log to SharePoint list, etc.",
            },
            copilotStudioUrl: {
              type: "string",
              description:
                "Copilot Studio agent HTTP trigger URL. The agent receives JSON payload and posts to Teams.",
            },
            teamsWebhookUrl: {
              type: "string",
              description: "Legacy: Teams Incoming Webhook URL (use Power Automate flow instead for more flexibility)",
            },
            emailRecipients: {
              type: "array",
              items: { type: "string" },
              description: "Email addresses for daily report notifications",
            },
            emailSender: {
              type: "string",
              description: "Sender email address for notifications",
            },
            userFilters: {
              type: "array",
              items: { type: "string" },
              description: "Optional: Filter to specific users (UPN). Leave empty for all users.",
            },
          },
          required: ["sharePointSiteUrl", "docLibrary"],
        },
      },

      // --- NOTIFICATION TOOLS ---
      {
        name: "send_notification",
        description:
          "Send a notification via Power Automate flow, Copilot Studio agent, Teams webhook, or email. " +
          "Use to notify about uploaded audit reports or any custom message.",
        inputSchema: {
          type: "object" as const,
          properties: {
            title: {
              type: "string",
              description: "Notification title",
            },
            message: {
              type: "string",
              description: "Notification body message",
            },
            sharePointUrl: {
              type: "string",
              description: "SharePoint file URL to link in the notification",
            },
            powerAutomateUrl: {
              type: "string",
              description: "Power Automate flow HTTP trigger URL (RECOMMENDED)",
            },
            copilotStudioUrl: {
              type: "string",
              description: "Copilot Studio agent HTTP trigger URL",
            },
            teamsWebhookUrl: {
              type: "string",
              description: "Teams Incoming Webhook URL (legacy)",
            },
            emailRecipients: {
              type: "array",
              items: { type: "string" },
              description: "Email addresses to notify",
            },
            emailSender: {
              type: "string",
              description: "Sender email address",
            },
            facts: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  value: { type: "string" },
                },
              },
              description: "Key-value facts to display in the notification card",
            },
          },
          required: ["title", "message"],
        },
      },

      // --- ANALYTICS & THREAT HUNTING TOOLS ---
      {
        name: "analyze_audit_risks",
        description:
          "Run risk scoring and anomaly detection on audit search results. Flags critical/high/medium/low risk events " +
          "based on operation type, off-hours activity, failed logins, external sharing, admin actions, permission changes, " +
          "and DLP events. Returns risk breakdown by user and operation.",
        inputSchema: {
          type: "object" as const,
          properties: {
            searchId: { type: "string", description: "Audit search ID (must be completed)" },
            maxRecords: { type: "number", description: "Max records to analyze (default: 5000)" },
          },
          required: ["searchId"],
        },
      },
      {
        name: "generate_executive_summary",
        description:
          "Generate a natural-language executive summary of audit search results. Includes key metrics, " +
          "service breakdown, top users, top operations, hourly distribution, and actionable recommendations.",
        inputSchema: {
          type: "object" as const,
          properties: {
            searchId: { type: "string", description: "Audit search ID (must be completed)" },
            maxRecords: { type: "number", description: "Max records to analyze (default: 5000)" },
          },
          required: ["searchId"],
        },
      },
      {
        name: "threat_hunting_search",
        description:
          "Run a pre-built threat hunting query based on MITRE ATT&CK tactics. " +
          "Presets: impossible_travel, brute_force, privilege_escalation, data_exfiltration, " +
          "mailbox_tampering, evasion_audit_tampering, oauth_abuse, teams_data_leak, " +
          "copilot_sensitive, off_hours_access. " +
          "Creates an audit search with the right filters and returns the search ID.",
        inputSchema: {
          type: "object" as const,
          properties: {
            preset: {
              type: "string",
              enum: [
                "impossible_travel", "brute_force", "privilege_escalation",
                "data_exfiltration", "mailbox_tampering", "evasion_audit_tampering",
                "oauth_abuse", "teams_data_leak", "copilot_sensitive", "off_hours_access",
              ],
              description: "Threat hunting preset ID",
            },
            startDateTime: { type: "string", description: "Start date/time ISO 8601" },
            endDateTime: { type: "string", description: "End date/time ISO 8601" },
            userFilters: {
              type: "array", items: { type: "string" },
              description: "Optional: limit to specific users",
            },
          },
          required: ["preset", "startDateTime", "endDateTime"],
        },
      },
      {
        name: "list_threat_hunts",
        description: "List all available threat hunting presets with MITRE ATT&CK mapping and descriptions.",
        inputSchema: { type: "object" as const, properties: {} },
      },
      {
        name: "copilot_adoption_analytics",
        description:
          "Analyze Copilot adoption from a completed CopilotInteraction audit search. Returns per-user usage, " +
          "daily/hourly/day-of-week trends, adoption trajectory, power users, and recommendations.",
        inputSchema: {
          type: "object" as const,
          properties: {
            searchId: { type: "string", description: "Audit search ID with CopilotInteraction results" },
            maxRecords: { type: "number", description: "Max records to analyze (default: 10000)" },
          },
          required: ["searchId"],
        },
      },
      {
        name: "user_activity_timeline",
        description:
          "Build a detailed activity timeline for a specific user from audit results. Shows every action, " +
          "session analysis, IP addresses, risk indicators, and activity gaps.",
        inputSchema: {
          type: "object" as const,
          properties: {
            searchId: { type: "string", description: "Audit search ID (must be completed)" },
            userUpn: { type: "string", description: "User principal name (e.g., user@contoso.com)" },
            maxRecords: { type: "number", description: "Max records to load (default: 5000)" },
          },
          required: ["searchId", "userUpn"],
        },
      },
      {
        name: "compare_audit_periods",
        description:
          "Compare two completed audit searches side by side. Highlights new/dropped operations, " +
          "new/dropped users, volume changes, and anomaly alerts. Great for week-over-week or month-over-month analysis.",
        inputSchema: {
          type: "object" as const,
          properties: {
            searchId1: { type: "string", description: "First audit search ID (baseline period)" },
            label1: { type: "string", description: "Label for first period (e.g., 'Last Week')" },
            searchId2: { type: "string", description: "Second audit search ID (comparison period)" },
            label2: { type: "string", description: "Label for second period (e.g., 'This Week')" },
            maxRecords: { type: "number", description: "Max records per period (default: 5000)" },
          },
          required: ["searchId1", "label1", "searchId2", "label2"],
        },
      },

      // --- SHAREPOINT EXTENDED TOOLS ---
      {
        name: "sp_search", description: "Search across all SharePoint content (files, lists, sites).",
        inputSchema: { type: "object" as const, properties: {
          query: { type: "string", description: "Search query" },
          entityTypes: { type: "array", items: { type: "string" }, description: "Entity types: driveItem, listItem, site (default: all)" },
        }, required: ["query"] },
      },
      {
        name: "sp_list_sites", description: "List/search SharePoint sites in the tenant.",
        inputSchema: { type: "object" as const, properties: {
          search: { type: "string", description: "Search term to filter sites (optional, lists all if empty)" },
        } },
      },
      {
        name: "sp_get_site", description: "Get full site info including drives and lists.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string", description: "SharePoint site URL" },
        }, required: ["siteUrl"] },
      },
      {
        name: "sp_create_site", description: "Create a new SharePoint team site (group-connected).",
        inputSchema: { type: "object" as const, properties: {
          displayName: { type: "string", description: "Site display name" },
          alias: { type: "string", description: "Site alias (URL-safe, no spaces)" },
          description: { type: "string", description: "Site description" },
          isPublic: { type: "boolean", description: "Public (true) or Private (false)" },
        }, required: ["displayName", "alias"] },
      },
      {
        name: "sp_site_analytics", description: "Get site usage analytics (views, visitors, storage).",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string", description: "SharePoint site URL" },
        }, required: ["siteUrl"] },
      },
      {
        name: "sp_get_lists", description: "List all SharePoint lists on a site.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string", description: "SharePoint site URL" },
        }, required: ["siteUrl"] },
      },
      {
        name: "sp_create_list", description: "Create a new SharePoint list with custom columns.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string", description: "SharePoint site URL" },
          displayName: { type: "string", description: "List name" },
          columns: { type: "array", items: { type: "object", properties: {
            name: { type: "string" }, type: { type: "string", description: "text, multiline, number, datetime, boolean, choice, person, currency" },
            required: { type: "boolean" },
          }}, description: "Column definitions" },
        }, required: ["siteUrl", "displayName", "columns"] },
      },
      {
        name: "sp_get_list_items", description: "Get items from a SharePoint list with optional filtering.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string", description: "SharePoint site URL" },
          listName: { type: "string", description: "List display name" },
          top: { type: "number", description: "Max items (default: 100)" },
          filter: { type: "string", description: "OData filter (e.g., \"fields/Status eq 'Active'\")" },
        }, required: ["siteUrl", "listName"] },
      },
      {
        name: "sp_add_list_item", description: "Add a new item to a SharePoint list.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string", description: "SharePoint site URL" },
          listName: { type: "string", description: "List display name" },
          fields: { type: "object", description: "Field values as key-value pairs (e.g., {\"Title\": \"My Item\", \"Status\": \"Active\"})" },
        }, required: ["siteUrl", "listName", "fields"] },
      },
      {
        name: "sp_update_list_item", description: "Update an existing SharePoint list item.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string", description: "SharePoint site URL" },
          listName: { type: "string", description: "List display name" },
          itemId: { type: "string", description: "Item ID to update" },
          fields: { type: "object", description: "Field values to update" },
        }, required: ["siteUrl", "listName", "itemId", "fields"] },
      },
      {
        name: "sp_delete_list_item", description: "Delete an item from a SharePoint list.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string", description: "SharePoint site URL" },
          listName: { type: "string", description: "List display name" },
          itemId: { type: "string", description: "Item ID to delete" },
        }, required: ["siteUrl", "listName", "itemId"] },
      },
      {
        name: "sp_get_list_columns", description: "Get column definitions for a SharePoint list.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string", description: "SharePoint site URL" },
          listName: { type: "string", description: "List display name" },
        }, required: ["siteUrl", "listName"] },
      },
      {
        name: "sp_file_info", description: "Get detailed metadata for a file in SharePoint.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string" }, docLibrary: { type: "string" }, filePath: { type: "string", description: "File path within library" },
        }, required: ["siteUrl", "docLibrary", "filePath"] },
      },
      {
        name: "sp_download_url", description: "Get a temporary download URL for a SharePoint file.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string" }, docLibrary: { type: "string" }, filePath: { type: "string" },
        }, required: ["siteUrl", "docLibrary", "filePath"] },
      },
      {
        name: "sp_delete_file", description: "Delete a file from SharePoint.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string" }, docLibrary: { type: "string" }, filePath: { type: "string" },
        }, required: ["siteUrl", "docLibrary", "filePath"] },
      },
      {
        name: "sp_move_file", description: "Move a file to a different folder in the same library.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string" }, docLibrary: { type: "string" },
          sourcePath: { type: "string", description: "Current file path" },
          destFolder: { type: "string", description: "Destination folder path" },
          newName: { type: "string", description: "Optional new filename" },
        }, required: ["siteUrl", "docLibrary", "sourcePath", "destFolder"] },
      },
      {
        name: "sp_copy_file", description: "Copy a file to another folder.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string" }, docLibrary: { type: "string" },
          sourcePath: { type: "string" }, destFolder: { type: "string" }, newName: { type: "string" },
        }, required: ["siteUrl", "docLibrary", "sourcePath", "destFolder"] },
      },
      {
        name: "sp_share_file", description: "Share a file/folder with specific users.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string" }, docLibrary: { type: "string" }, filePath: { type: "string" },
          recipients: { type: "array", items: { type: "string" }, description: "Email addresses" },
          role: { type: "string", enum: ["read", "write", "owner"], description: "Permission level (default: read)" },
          message: { type: "string", description: "Message to include in sharing invite" },
        }, required: ["siteUrl", "docLibrary", "filePath", "recipients"] },
      },
      {
        name: "sp_create_sharing_link", description: "Create a sharing link for a file.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string" }, docLibrary: { type: "string" }, filePath: { type: "string" },
          type: { type: "string", enum: ["view", "edit"], description: "Link type" },
          scope: { type: "string", enum: ["anonymous", "organization", "users"], description: "Link scope" },
        }, required: ["siteUrl", "docLibrary", "filePath"] },
      },
      {
        name: "sp_get_permissions", description: "Get site-level permissions.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string", description: "SharePoint site URL" },
        }, required: ["siteUrl"] },
      },
      {
        name: "sp_get_pages", description: "List SharePoint site pages.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string" },
        }, required: ["siteUrl"] },
      },
      {
        name: "sp_get_subsites", description: "List subsites under a SharePoint site.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string" },
        }, required: ["siteUrl"] },
      },
      {
        name: "sp_get_content_types", description: "List content types on a site.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string" },
        }, required: ["siteUrl"] },
      },
      {
        name: "sp_get_columns", description: "List site columns.",
        inputSchema: { type: "object" as const, properties: {
          siteUrl: { type: "string" },
        }, required: ["siteUrl"] },
      },

      // --- COPILOT TRACKING & REPORTING ---
      {
        name: "track_copilot_agents",
        description:
          "Track which Copilot agents and apps are being used, by whom, and how often. " +
          "Breaks down by agent, user, day, hour. Includes licensing insights.",
        inputSchema: { type: "object" as const, properties: {
          searchId: { type: "string", description: "Audit search ID with CopilotInteraction results" },
          maxRecords: { type: "number", description: "Max records (default: 10000)" },
        }, required: ["searchId"] },
      },
      {
        name: "generate_copilot_report",
        description:
          "Generate HTML report with charts, KPIs, agent breakdown, user rankings, trends, and recommendations. " +
          "Can auto-upload to SharePoint.",
        inputSchema: { type: "object" as const, properties: {
          searchId: { type: "string", description: "Audit search ID with CopilotInteraction results" },
          title: { type: "string", description: "Report title" },
          maxRecords: { type: "number", description: "Max records (default: 10000)" },
          uploadToSharePoint: { type: "boolean", description: "Auto-upload to SharePoint" },
          sharePointSiteUrl: { type: "string" }, docLibrary: { type: "string" }, targetFolder: { type: "string" },
        }, required: ["searchId"] },
      },
      {
        name: "copilot_trend_analysis",
        description:
          "Week-over-week comparison, user growth, agent adoption trends, peak times, forecast.",
        inputSchema: { type: "object" as const, properties: {
          searchId: { type: "string", description: "Audit search ID (ideally 2+ weeks data)" },
          maxRecords: { type: "number", description: "Max records (default: 10000)" },
        }, required: ["searchId"] },
      },
      {
        name: "schedule_copilot_report",
        description:
          "Schedule recurring Copilot report: search + HTML report + upload to SharePoint + notify. All in one.",
        inputSchema: { type: "object" as const, properties: {
          cronExpression: { type: "string", description: "Cron (e.g., '0 7 * * 1' = Monday 7 AM)" },
          sharePointSiteUrl: { type: "string" }, docLibrary: { type: "string" },
          targetFolder: { type: "string", description: "Folder (default: 'Copilot Reports')" },
          powerAutomateUrl: { type: "string" }, copilotStudioUrl: { type: "string" },
          reportTitle: { type: "string", description: "Title prefix" },
        }, required: ["sharePointSiteUrl", "docLibrary"] },
      },

      // --- PURVIEW EXTENDED: SECURITY ---
      { name: "pv_get_alerts", description: "Get security alerts (DLP, Insider Risk, Defender). Filter by service source.",
        inputSchema: { type: "object" as const, properties: { top: { type: "number" }, filter: { type: "string" }, serviceSource: { type: "string", description: "microsoftDataLossPrevention, microsoftPurview, microsoftDefenderForEndpoint, etc." } } } },
      { name: "pv_get_alert", description: "Get detailed security alert by ID.",
        inputSchema: { type: "object" as const, properties: { alertId: { type: "string" } }, required: ["alertId"] } },
      { name: "pv_update_alert", description: "Update alert status/classification/assignment.",
        inputSchema: { type: "object" as const, properties: { alertId: { type: "string" }, status: { type: "string", enum: ["new","inProgress","resolved"] }, classification: { type: "string", enum: ["truePositive","falsePositive","informationalExpectedActivity"] }, assignedTo: { type: "string" }, comment: { type: "string" } }, required: ["alertId","status"] } },
      { name: "pv_get_incidents", description: "Get security incidents.",
        inputSchema: { type: "object" as const, properties: { top: { type: "number" }, filter: { type: "string" } } } },
      { name: "pv_get_incident", description: "Get incident details by ID.",
        inputSchema: { type: "object" as const, properties: { incidentId: { type: "string" } }, required: ["incidentId"] } },
      { name: "pv_update_incident", description: "Update incident status/classification.",
        inputSchema: { type: "object" as const, properties: { incidentId: { type: "string" }, status: { type: "string", enum: ["active","resolved","redirected"] }, classification: { type: "string" }, assignedTo: { type: "string" } }, required: ["incidentId","status"] } },

      // --- SECURE SCORE ---
      { name: "pv_secure_score", description: "Get Microsoft Secure Score (compliance posture).",
        inputSchema: { type: "object" as const, properties: { top: { type: "number" } } } },
      { name: "pv_secure_score_controls", description: "Get Secure Score control profiles (improvement actions).",
        inputSchema: { type: "object" as const, properties: {} } },

      // --- eDISCOVERY ---
      { name: "pv_list_ediscovery_cases", description: "List all eDiscovery cases.",
        inputSchema: { type: "object" as const, properties: { top: { type: "number" } } } },
      { name: "pv_get_ediscovery_case", description: "Get eDiscovery case details.",
        inputSchema: { type: "object" as const, properties: { caseId: { type: "string" } }, required: ["caseId"] } },
      { name: "pv_create_ediscovery_case", description: "Create new eDiscovery case.",
        inputSchema: { type: "object" as const, properties: { displayName: { type: "string" }, description: { type: "string" }, externalId: { type: "string" } }, required: ["displayName"] } },
      { name: "pv_list_custodians", description: "List custodians in an eDiscovery case.",
        inputSchema: { type: "object" as const, properties: { caseId: { type: "string" } }, required: ["caseId"] } },
      { name: "pv_list_ediscovery_searches", description: "List searches in an eDiscovery case.",
        inputSchema: { type: "object" as const, properties: { caseId: { type: "string" } }, required: ["caseId"] } },

      // --- IDENTITY RISK ---
      { name: "pv_risk_detections", description: "Get identity risk detections (risky sign-ins, leaked credentials, etc.).",
        inputSchema: { type: "object" as const, properties: { top: { type: "number" }, filter: { type: "string" } } } },
      { name: "pv_risky_users", description: "Get users flagged as risky by Identity Protection.",
        inputSchema: { type: "object" as const, properties: { top: { type: "number" } } } },
      { name: "pv_risky_signins", description: "Get sign-ins flagged with risk by Identity Protection.",
        inputSchema: { type: "object" as const, properties: { top: { type: "number" } } } },

      // --- ADVANCED HUNTING ---
      { name: "pv_advanced_hunting", description: "Run a KQL advanced hunting query against security data. Returns raw results.",
        inputSchema: { type: "object" as const, properties: { query: { type: "string", description: "KQL query" } }, required: ["query"] } },
      { name: "pv_hunting_presets", description: "Run a pre-built advanced hunting query. Presets: suspicious_logins, mass_file_download, new_inbox_rules, external_sharing_spike, admin_role_changes, copilot_heavy_usage.",
        inputSchema: { type: "object" as const, properties: { preset: { type: "string", enum: ["suspicious_logins","mass_file_download","new_inbox_rules","external_sharing_spike","admin_role_changes","copilot_heavy_usage"] } }, required: ["preset"] } },

      // --- RETENTION LABELS ---
      { name: "pv_list_retention_labels", description: "List all retention labels in the tenant.",
        inputSchema: { type: "object" as const, properties: {} } },
      { name: "pv_get_retention_label", description: "Get retention label details.",
        inputSchema: { type: "object" as const, properties: { labelId: { type: "string" } }, required: ["labelId"] } },

      // --- THREAT INTELLIGENCE ---
      { name: "pv_threat_intel_articles", description: "Get latest threat intelligence articles.",
        inputSchema: { type: "object" as const, properties: { top: { type: "number" } } } },

      // --- SUBJECT RIGHTS REQUESTS (PRIVACY) ---
      { name: "pv_list_privacy_requests", description: "List subject rights requests (DSAR/privacy).",
        inputSchema: { type: "object" as const, properties: {} } },
      { name: "pv_create_privacy_request", description: "Create a new subject rights request (DSAR).",
        inputSchema: { type: "object" as const, properties: { displayName: { type: "string" }, type: { type: "string", enum: ["access","delete","export","tagForAction"] }, dataSubjectEmail: { type: "string" }, description: { type: "string" } }, required: ["displayName","type","dataSubjectEmail"] } },

      // --- CREATIVE ANALYSIS ---
      { name: "pv_detect_shadow_it", description: "Detect shadow IT — unknown or unauthorized apps accessing your tenant. Analyzes audit records for unrecognized application IDs.",
        inputSchema: { type: "object" as const, properties: { searchId: { type: "string" }, maxRecords: { type: "number" } }, required: ["searchId"] } },
      { name: "pv_scan_data_exposure", description: "Scan for data exposure — external sharing, anonymous links, sensitive file shares. Identifies top sharers and risk level.",
        inputSchema: { type: "object" as const, properties: { searchId: { type: "string" }, maxRecords: { type: "number" } }, required: ["searchId"] } },
      { name: "pv_compliance_dashboard", description: "Get a full compliance health dashboard: Secure Score + recent alerts + incidents + retention labels + identity risks in one call.",
        inputSchema: { type: "object" as const, properties: {} } },

      // --- SENSITIVITY LABELS ---
      { name: "pv_list_sensitivity_labels", description: "List all sensitivity labels in the tenant (Information Protection).",
        inputSchema: { type: "object" as const, properties: {} } },
      { name: "pv_get_sensitivity_label", description: "Get sensitivity label details by ID.",
        inputSchema: { type: "object" as const, properties: { labelId: { type: "string" } }, required: ["labelId"] } },
      { name: "pv_assign_sensitivity_label", description: "Apply a sensitivity label to a file in SharePoint (metered API).",
        inputSchema: { type: "object" as const, properties: { siteUrl: { type: "string" }, docLibrary: { type: "string" }, filePath: { type: "string" }, labelId: { type: "string", description: "Sensitivity label ID (get from pv_list_sensitivity_labels)" } }, required: ["siteUrl","docLibrary","filePath","labelId"] } },
      { name: "pv_remove_file_label", description: "Remove sensitivity label from a single file in SharePoint.",
        inputSchema: { type: "object" as const, properties: { siteUrl: { type: "string" }, docLibrary: { type: "string" }, filePath: { type: "string" } }, required: ["siteUrl","docLibrary","filePath"] } },
      { name: "pv_remove_site_label", description: "Remove sensitivity label from a SharePoint site itself.",
        inputSchema: { type: "object" as const, properties: { siteUrl: { type: "string" } }, required: ["siteUrl"] } },
      { name: "pv_bulk_remove_labels", description: "Remove sensitivity labels from ALL files in a document library (or specific folder). Recursively processes all files including subfolders. Use with caution!",
        inputSchema: { type: "object" as const, properties: { siteUrl: { type: "string" }, docLibrary: { type: "string" }, folderPath: { type: "string", description: "Folder path to scope (optional — if empty, processes entire library)" } }, required: ["siteUrl","docLibrary"] } },
      { name: "pv_apply_label_to_site", description: "Apply a sensitivity label to a SharePoint site (container-level label for the entire site).",
        inputSchema: { type: "object" as const, properties: { siteUrl: { type: "string" }, labelId: { type: "string", description: "Sensitivity label ID (get from pv_list_sensitivity_labels)" } }, required: ["siteUrl","labelId"] } },
      { name: "pv_apply_label_to_library", description: "Apply a sensitivity label to ALL supported files (docx, xlsx, pptx, pdf) in a document library. Recursively processes subfolders.",
        inputSchema: { type: "object" as const, properties: { siteUrl: { type: "string" }, docLibrary: { type: "string" }, labelId: { type: "string" }, folderPath: { type: "string", description: "Optional folder to scope" } }, required: ["siteUrl","docLibrary","labelId"] } },
      { name: "pv_set_default_library_label", description: "Set a default sensitivity label for a document library. New files uploaded will automatically get this label.",
        inputSchema: { type: "object" as const, properties: { siteUrl: { type: "string" }, docLibrary: { type: "string" }, labelId: { type: "string" } }, required: ["siteUrl","docLibrary","labelId"] } },
      { name: "pv_extract_file_labels", description: "Scan a document library and extract the sensitivity label from every supported file. Returns label name + ID for each file.",
        inputSchema: { type: "object" as const, properties: { siteUrl: { type: "string" }, docLibrary: { type: "string" }, folderPath: { type: "string" } }, required: ["siteUrl","docLibrary"] } },

      // --- SIGN-IN & DIRECTORY AUDIT LOGS ---
      { name: "pv_signin_logs", description: "Get Entra ID sign-in logs. Filter by user, app, status, risk level, location.",
        inputSchema: { type: "object" as const, properties: { top: { type: "number" }, filter: { type: "string", description: "OData filter (e.g., \"userPrincipalName eq 'user@contoso.com'\" or \"status/errorCode ne 0\")" } } } },
      { name: "pv_directory_audits", description: "Get Entra ID directory audit logs (user/group/role changes, app registrations, policy changes).",
        inputSchema: { type: "object" as const, properties: { top: { type: "number" }, filter: { type: "string", description: "OData filter (e.g., \"activityDisplayName eq 'Add member to role'\")" } } } },

      // --- SERVICE HEALTH ---
      { name: "pv_service_health", description: "Get M365 service health overview for all services.",
        inputSchema: { type: "object" as const, properties: {} } },
      { name: "pv_service_issues", description: "Get current and recent M365 service health issues/outages.",
        inputSchema: { type: "object" as const, properties: { top: { type: "number" } } } },
      { name: "pv_service_messages", description: "Get M365 Message Center announcements (upcoming changes, new features).",
        inputSchema: { type: "object" as const, properties: { top: { type: "number" } } } },

      // --- CONDITIONAL ACCESS ---
      { name: "pv_list_ca_policies", description: "List all Conditional Access policies in the tenant.",
        inputSchema: { type: "object" as const, properties: {} } },
      { name: "pv_get_ca_policy", description: "Get Conditional Access policy details.",
        inputSchema: { type: "object" as const, properties: { policyId: { type: "string" } }, required: ["policyId"] } },

      // --- M365 USAGE REPORTS ---
      { name: "pv_m365_active_users", description: "Get M365 active users report (who's using what services).",
        inputSchema: { type: "object" as const, properties: { period: { type: "string", enum: ["D7","D30","D90","D180"], description: "Reporting period (default: D7)" } } } },
      { name: "pv_email_activity", description: "Get Exchange email activity report per user.",
        inputSchema: { type: "object" as const, properties: { period: { type: "string", enum: ["D7","D30","D90","D180"] } } } },
      { name: "pv_sharepoint_activity", description: "Get SharePoint activity report per user.",
        inputSchema: { type: "object" as const, properties: { period: { type: "string", enum: ["D7","D30","D90","D180"] } } } },
      { name: "pv_teams_activity", description: "Get Teams activity report per user.",
        inputSchema: { type: "object" as const, properties: { period: { type: "string", enum: ["D7","D30","D90","D180"] } } } },
      { name: "pv_onedrive_activity", description: "Get OneDrive activity report per user.",
        inputSchema: { type: "object" as const, properties: { period: { type: "string", enum: ["D7","D30","D90","D180"] } } } },

      // --- WORKLOAD AUDIT PRESETS ---
      { name: "pv_list_workload_presets", description: "List all available audit search presets for every M365 workload: Exchange, SharePoint, OneDrive, Teams, Entra ID, Power Platform, Copilot, Compliance, DLP, Security, and more.",
        inputSchema: { type: "object" as const, properties: {} } },
      { name: "pv_workload_audit", description: "Create an audit search using a pre-built workload preset. Presets: copilot_all, copilot_agents, exchange_all, exchange_inbox_rules, exchange_forwarding, sharepoint_all, sharepoint_sharing, sharepoint_file_access, sharepoint_dlp, onedrive_all, teams_all, teams_meetings, teams_messaging, teams_apps, teams_guest, entra_all, entra_user_admin, entra_group_changes, entra_role_changes, entra_app_consent, entra_conditional_access, powerplatform_all, compliance_all, dlp_all, sensitivity_label_changes, security_alerts, sign_in_failures, all_admin, all_activity, and more.",
        inputSchema: { type: "object" as const, properties: {
          preset: { type: "string", description: "Workload preset name (use pv_list_workload_presets to see all)" },
          startDateTime: { type: "string", description: "ISO 8601 start date" },
          endDateTime: { type: "string", description: "ISO 8601 end date" },
          userPrincipalNameFilters: { type: "array", items: { type: "string" }, description: "Optional: filter to specific users" },
        }, required: ["preset","startDateTime","endDateTime"] } },

      // --- COPILOT AGENT SECURITY ---
      { name: "pv_copilot_agent_security", description: "Analyze Copilot agent security from audit records. Detects risky agent configurations, auth changes, unauthorized sharing, sensitive data access, and agent deletions. Returns risk score and recommendations.",
        inputSchema: { type: "object" as const, properties: { searchId: { type: "string" }, maxRecords: { type: "number" } }, required: ["searchId"] } },
      { name: "pv_copilot_security_report", description: "Generate comprehensive Copilot security report: agent inventory, data access summary (sensitive files, web search usage), per-user risk profiles, and oversharing detection.",
        inputSchema: { type: "object" as const, properties: { searchId: { type: "string" }, maxRecords: { type: "number" } }, required: ["searchId"] } },
      { name: "pv_copilot_full_security_scan", description: "One-shot full Copilot security scan: creates audit search for ALL Copilot + agent events for the specified period, waits for completion, then runs both security analysis and security report. Returns everything.",
        inputSchema: { type: "object" as const, properties: {
          startDateTime: { type: "string", description: "ISO 8601 start" },
          endDateTime: { type: "string", description: "ISO 8601 end" },
        }, required: ["startDateTime","endDateTime"] } },

      // --- COPILOT USAGE PIPELINE (all-in-one) ---
      { name: "pv_copilot_usage_pipeline", description: "All-in-one Copilot usage report: searches CopilotInteraction audit for chosen period (3/6/9/12 months), exports clean CSV with agent names + users + environment, generates fancy HTML dashboard with KPIs + charts + top agents + top users + licensing insights, uploads BOTH files to user's chosen SharePoint location.",
        inputSchema: { type: "object" as const, properties: {
          period: { type: "string", enum: ["3months","6months","9months","12months"], description: "Audit period to search" },
          sharePointSiteUrl: { type: "string", description: "SharePoint site URL (e.g. https://company.sharepoint.com/sites/Audit)" },
          docLibrary: { type: "string", description: "Document library name (e.g. Documents)" },
          targetFolder: { type: "string", description: "Folder path in library (e.g. Copilot Reports)" },
        }, required: ["period","sharePointSiteUrl","docLibrary"] } },
    ],
  };
};

// Register on the module-level server (for stdio/Claude Desktop)
server.setRequestHandler(ListToolsRequestSchema, listToolsHandler);

// ============================================================
// Tool Handlers
// ============================================================

export const callToolHandler = async (request: any) => {
  const { name, arguments: args } = request.params;

  try {
    switch (name) {
      // ========== AUDIT SEARCH ==========

      case "search_audit_log": {
        const result = await createAuditSearch({
          displayName: args!.displayName as string,
          filterStartDateTime: args!.startDateTime as string,
          filterEndDateTime: args!.endDateTime as string,
          operationFilters: args!.operationFilters as string[] | undefined,
          userPrincipalNameFilters: args!.userPrincipalNameFilters as string[] | undefined,
          ipAddressFilters: args!.ipAddressFilters as string[] | undefined,
          objectIdFilters: args!.objectIdFilters as string[] | undefined,
          recordTypeFilters: args!.recordTypeFilters as string[] | undefined,
          serviceFilters: args!.serviceFilters as string[] | undefined,
          keywordFilter: args!.keywordFilter as string | undefined,
        });
        return {
          content: [
            {
              type: "text" as const,
              text: JSON.stringify(
                {
                  success: true,
                  message: `Audit search created: "${result.displayName}"`,
                  searchId: result.id,
                  status: result.status,
                  startDateTime: result.filterStartDateTime,
                  endDateTime: result.filterEndDateTime,
                  hint: "Use get_audit_search_status to check when it completes, then get_audit_results to retrieve records.",
                },
                null,
                2
              ),
            },
          ],
        };
      }

      case "get_audit_search_status": {
        const result = await getAuditSearch(args!.searchId as string);
        return {
          content: [
            {
              type: "text" as const,
              text: JSON.stringify(
                {
                  searchId: result.id,
                  displayName: result.displayName,
                  status: result.status,
                  created: result.createdDateTime,
                  startDateTime: result.filterStartDateTime,
                  endDateTime: result.filterEndDateTime,
                  filters: {
                    operations: result.operationFilters,
                    users: result.userPrincipalNameFilters,
                    recordTypes: result.recordTypeFilters,
                    services: result.serviceFilters,
                  },
                },
                null,
                2
              ),
            },
          ],
        };
      }

      case "list_audit_searches": {
        const searches = await listAuditSearches();
        return {
          content: [
            {
              type: "text" as const,
              text: JSON.stringify(
                {
                  totalSearches: searches.length,
                  searches: searches.map((s) => ({
                    id: s.id,
                    name: s.displayName,
                    status: s.status,
                    created: s.createdDateTime,
                    range: `${s.filterStartDateTime} → ${s.filterEndDateTime}`,
                  })),
                },
                null,
                2
              ),
            },
          ],
        };
      }

      case "get_audit_results": {
        const maxRecords = Math.min((args!.maxRecords as number) || 500, 10000);
        const records = await getAllAuditSearchResults(args!.searchId as string, maxRecords);
        return {
          content: [
            {
              type: "text" as const,
              text: JSON.stringify(
                {
                  totalRecords: records.length,
                  records: records.slice(0, 100).map((r) => ({
                    timestamp: r.createdDateTime,
                    user: r.userPrincipalName,
                    operation: r.operation,
                    service: r.service,
                    clientIp: r.clientIp,
                    objectId: r.objectId,
                    details: r.auditData,
                  })),
                  note:
                    records.length > 100
                      ? `Showing first 100 of ${records.length} records. Use export_audit_results for the full dataset.`
                      : undefined,
                },
                null,
                2
              ),
            },
          ],
        };
      }

      case "delete_audit_search": {
        await deleteAuditSearch(args!.searchId as string);
        return {
          content: [
            {
              type: "text" as const,
              text: `Audit search ${args!.searchId} deleted successfully.`,
            },
          ],
        };
      }

      case "export_audit_results": {
        const format = (args!.format as "csv" | "json") || "csv";
        const max = Math.min((args!.maxRecords as number) || 10000, 10000);
        const records = await getAllAuditSearchResults(args!.searchId as string, max);

        const search = await getAuditSearch(args!.searchId as string);
        const filePath = generateExportFilename(search.displayName, format);

        if (format === "json") {
          exportToJSON(records, filePath);
        } else {
          exportToCSV(records, filePath);
        }

        return {
          content: [
            {
              type: "text" as const,
              text: JSON.stringify(
                {
                  success: true,
                  totalRecords: records.length,
                  format,
                  filePath,
                  hint: "Use upload_to_sharepoint to upload this file to SharePoint.",
                },
                null,
                2
              ),
            },
          ],
        };
      }

      // ========== FULL PIPELINE ==========

      case "full_audit_pipeline": {
        const format = (args!.format as "csv" | "json") || "csv";

        // Step 1: Create search
        const search = await createAuditSearch({
          displayName: args!.displayName as string,
          filterStartDateTime: args!.startDateTime as string,
          filterEndDateTime: args!.endDateTime as string,
          operationFilters: args!.operationFilters as string[] | undefined,
          userPrincipalNameFilters: args!.userPrincipalNameFilters as string[] | undefined,
          recordTypeFilters: args!.recordTypeFilters as string[] | undefined,
          serviceFilters: args!.serviceFilters as string[] | undefined,
          keywordFilter: args!.keywordFilter as string | undefined,
        });

        // Step 2: Wait for completion
        await waitForSearchCompletion(search.id);

        // Step 3: Get results
        const records = await getAllAuditSearchResults(search.id);

        // Step 4: Export
        const filePath = generateExportFilename(args!.displayName as string, format);
        if (format === "json") {
          exportToJSON(records, filePath);
        } else {
          exportToCSV(records, filePath);
        }

        // Step 5: Upload to SharePoint
        const uploaded = await uploadFileToSharePoint(
          args!.sharePointSiteUrl as string,
          args!.docLibrary as string,
          filePath,
          args!.targetFolder as string | undefined
        );

        return {
          content: [
            {
              type: "text" as const,
              text: JSON.stringify(
                {
                  success: true,
                  pipeline: "search → export → upload",
                  searchId: search.id,
                  totalRecords: records.length,
                  exportFormat: format,
                  localFile: filePath,
                  sharePoint: {
                    fileName: uploaded.name,
                    webUrl: uploaded.webUrl,
                    size: uploaded.size,
                    uploaded: uploaded.createdDateTime,
                  },
                },
                null,
                2
              ),
            },
          ],
        };
      }

      // ========== SHAREPOINT ==========

      case "upload_to_sharepoint": {
        const uploaded = await uploadFileToSharePoint(
          args!.sharePointSiteUrl as string,
          args!.docLibrary as string,
          args!.localFilePath as string,
          args!.targetFolder as string | undefined
        );
        return {
          content: [
            {
              type: "text" as const,
              text: JSON.stringify(
                {
                  success: true,
                  fileName: uploaded.name,
                  webUrl: uploaded.webUrl,
                  size: uploaded.size,
                  uploaded: uploaded.createdDateTime,
                },
                null,
                2
              ),
            },
          ],
        };
      }

      case "list_sharepoint_files": {
        const files = await listSharePointFiles(
          args!.sharePointSiteUrl as string,
          args!.docLibrary as string,
          args!.folderPath as string | undefined
        );
        return {
          content: [
            {
              type: "text" as const,
              text: JSON.stringify(
                {
                  totalFiles: files.length,
                  files: files.map((f) => ({
                    name: f.name,
                    webUrl: f.webUrl,
                    size: f.size,
                    created: f.createdDateTime,
                    type: f.file?.mimeType || "folder",
                  })),
                },
                null,
                2
              ),
            },
          ],
        };
      }

      case "list_document_libraries": {
        const drives = await listDocumentLibraries(args!.sharePointSiteUrl as string);
        return {
          content: [
            {
              type: "text" as const,
              text: JSON.stringify(
                {
                  totalLibraries: drives.length,
                  libraries: drives.map((d) => ({
                    name: d.name,
                    driveType: d.driveType,
                    webUrl: d.webUrl,
                    driveId: d.id,
                  })),
                },
                null,
                2
              ),
            },
          ],
        };
      }

      case "create_sharepoint_folder": {
        const folder = await createSharePointFolder(
          args!.sharePointSiteUrl as string,
          args!.docLibrary as string,
          args!.folderName as string,
          args!.parentFolder as string | undefined
        );
        return {
          content: [
            {
              type: "text" as const,
              text: JSON.stringify(
                {
                  success: true,
                  folderName: folder.name,
                  webUrl: folder.webUrl,
                  created: folder.createdDateTime,
                },
                null,
                2
              ),
            },
          ],
        };
      }

      // ========== SCHEDULER ==========

      case "schedule_daily_audit": {
        const schedule = createScheduledAudit({
          name: args!.name as string,
          cronExpression: args!.cronExpression as string,
          searchParams: {
            operationFilters: args!.operationFilters as string[] | undefined,
            userPrincipalNameFilters: args!.userPrincipalNameFilters as string[] | undefined,
            recordTypeFilters: args!.recordTypeFilters as string[] | undefined,
            serviceFilters: args!.serviceFilters as string[] | undefined,
            keywordFilter: args!.keywordFilter as string | undefined,
          },
          sharePointSiteUrl: args!.sharePointSiteUrl as string,
          sharePointDocLibrary: args!.sharePointDocLibrary as string,
          sharePointFolder: args!.sharePointFolder as string | undefined,
          powerAutomateUrl: args!.powerAutomateUrl as string | undefined,
          copilotStudioUrl: args!.copilotStudioUrl as string | undefined,
          teamsWebhookUrl: args!.teamsWebhookUrl as string | undefined,
          emailRecipients: args!.emailRecipients as string[] | undefined,
          emailSender: args!.emailSender as string | undefined,
        });
        return {
          content: [
            {
              type: "text" as const,
              text: JSON.stringify(
                {
                  success: true,
                  message: `Schedule created: "${schedule.name}"`,
                  scheduleId: schedule.id,
                  cronExpression: schedule.cronExpression,
                  enabled: schedule.enabled,
                  sharePointTarget: `${schedule.sharePointSiteUrl} → ${schedule.sharePointDocLibrary}/${schedule.sharePointFolder || ""}`,
                  notifications: {
                    powerAutomate: schedule.powerAutomateUrl ? "✅ enabled" : "disabled",
                    copilotStudio: schedule.copilotStudioUrl ? "✅ enabled" : "disabled",
                    teamsWebhook: schedule.teamsWebhookUrl ? "✅ enabled" : "disabled",
                    email: schedule.emailRecipients?.length ? `✅ ${schedule.emailRecipients.join(", ")}` : "disabled",
                  },
                  note: "The schedule will search the last 24 hours of audit logs at each run, auto-upload to SharePoint, and send notifications.",
                },
                null,
                2
              ),
            },
          ],
        };
      }

      case "list_scheduled_audits": {
        const schedules = listScheduledAudits();
        return {
          content: [
            {
              type: "text" as const,
              text: JSON.stringify(
                {
                  totalSchedules: schedules.length,
                  schedules: schedules.map((s) => ({
                    id: s.id,
                    name: s.name,
                    cron: s.cronExpression,
                    enabled: s.enabled,
                    lastRun: s.lastRun || "never",
                    lastStatus: s.lastStatus || "n/a",
                    sharePoint: `${s.sharePointSiteUrl} → ${s.sharePointDocLibrary}/${s.sharePointFolder || ""}`,
                    notifications: {
                      teams: s.teamsWebhookUrl ? "enabled" : "disabled",
                      email: s.emailRecipients?.length ? "enabled" : "disabled",
                    },
                    created: s.createdAt,
                  })),
                },
                null,
                2
              ),
            },
          ],
        };
      }

      case "manage_schedule": {
        const action = args!.action as string;
        const scheduleId = args!.scheduleId as string;

        if (action === "delete") {
          deleteScheduledAudit(scheduleId);
          return {
            content: [{ type: "text" as const, text: `Schedule ${scheduleId} deleted.` }],
          };
        }

        const enabled = action === "enable";
        const schedule = toggleSchedule(scheduleId, enabled);
        return {
          content: [
            {
              type: "text" as const,
              text: JSON.stringify(
                {
                  success: true,
                  scheduleId: schedule.id,
                  name: schedule.name,
                  enabled: schedule.enabled,
                  message: `Schedule ${enabled ? "enabled" : "disabled"}.`,
                },
                null,
                2
              ),
            },
          ],
        };
      }

      case "run_schedule_now": {
        const result = await runScheduleNow(args!.scheduleId as string);
        return {
          content: [
            {
              type: "text" as const,
              text: result,
            },
          ],
        };
      }

      // ========== COPILOT DAILY AUDIT (PRE-CONFIGURED) ==========

      case "setup_copilot_daily_audit": {
        // Map friendly time to cron
        const cronMap: Record<string, string> = {
          "6am": "0 6 * * *",
          "7am": "0 7 * * *",
          "8am": "0 8 * * *",
          "9am": "0 9 * * *",
          "12am": "0 0 * * *",
          "12pm": "0 12 * * *",
        };
        const cronInput = (args!.cronTime as string) || "6am";
        const cronExpression = cronMap[cronInput.toLowerCase()] || cronInput;
        const folder = (args!.targetFolder as string) || "Copilot Daily Audit";

        const schedule = createScheduledAudit({
          name: "Copilot Usage Daily Audit",
          cronExpression,
          searchParams: {
            operationFilters: ["CopilotInteraction"],
            userPrincipalNameFilters: args!.userFilters as string[] | undefined,
          },
          sharePointSiteUrl: args!.sharePointSiteUrl as string,
          sharePointDocLibrary: args!.docLibrary as string,
          sharePointFolder: folder,
          powerAutomateUrl: args!.powerAutomateUrl as string | undefined,
          copilotStudioUrl: args!.copilotStudioUrl as string | undefined,
          teamsWebhookUrl: args!.teamsWebhookUrl as string | undefined,
          emailRecipients: args!.emailRecipients as string[] | undefined,
          emailSender: args!.emailSender as string | undefined,
        });

        return {
          content: [
            {
              type: "text" as const,
              text: JSON.stringify(
                {
                  success: true,
                  message: "🤖 Copilot Daily Audit schedule created!",
                  scheduleId: schedule.id,
                  configuration: {
                    name: "Copilot Usage Daily Audit",
                    operation: "CopilotInteraction",
                    schedule: cronExpression,
                    coverage: "Last 24 hours of Copilot interactions",
                    sharePointTarget: `${args!.sharePointSiteUrl} → ${args!.docLibrary}/${folder}`,
                    notifications: {
                      powerAutomate: schedule.powerAutomateUrl ? "✅ Enabled" : "❌ Not configured",
                      copilotStudio: schedule.copilotStudioUrl ? "✅ Enabled" : "❌ Not configured",
                      teamsWebhook: schedule.teamsWebhookUrl ? "✅ Enabled" : "❌ Not configured",
                      email: schedule.emailRecipients?.length
                        ? `✅ ${schedule.emailRecipients.join(", ")}`
                        : "❌ Not configured",
                    },
                    userFilter: (args!.userFilters as string[])?.length
                      ? (args!.userFilters as string[]).join(", ")
                      : "All users",
                  },
                  workflow: [
                    "1. Daily at scheduled time → Search Purview for CopilotInteraction events (last 24h)",
                    "2. Export results to CSV",
                    "3. Upload CSV to SharePoint doc library",
                    "4. Trigger Power Automate flow / Copilot Studio agent → Post notification to Teams",
                  ],
                  hint: "Use run_schedule_now to test it immediately, or list_scheduled_audits to view all schedules.",
                },
                null,
                2
              ),
            },
          ],
        };
      }

      // ========== NOTIFICATIONS ==========

      case "send_notification": {
        const results: string[] = [];
        const errors: string[] = [];

        const payload: AuditReportPayload = {
          reportName: args!.title as string,
          recordCount: 0,
          startDate: new Date().toISOString(),
          endDate: new Date().toISOString(),
          filters: args!.message as string,
          sharePointUrl: (args!.sharePointUrl as string) || "",
          fileName: "Manual notification",
          status: "success",
          timestamp: new Date().toISOString(),
        };

        // Power Automate
        if (args!.powerAutomateUrl) {
          try {
            await sendPowerAutomateNotification(args!.powerAutomateUrl as string, payload);
            results.push("Power Automate flow triggered");
          } catch (err: unknown) {
            errors.push(`Power Automate: ${err instanceof Error ? err.message : String(err)}`);
          }
        }

        // Copilot Studio
        if (args!.copilotStudioUrl) {
          try {
            await sendCopilotStudioNotification(args!.copilotStudioUrl as string, payload);
            results.push("Copilot Studio agent triggered");
          } catch (err: unknown) {
            errors.push(`Copilot Studio: ${err instanceof Error ? err.message : String(err)}`);
          }
        }

        // Teams webhook
        if (args!.teamsWebhookUrl) {
          try {
            await sendTeamsNotification(
              args!.teamsWebhookUrl as string,
              args!.title as string,
              args!.message as string,
              args!.sharePointUrl as string | undefined,
              args!.facts as Array<{ name: string; value: string }> | undefined
            );
            results.push("Teams webhook sent");
          } catch (err: unknown) {
            errors.push(`Teams: ${err instanceof Error ? err.message : String(err)}`);
          }
        }

        // Email
        if ((args!.emailRecipients as string[])?.length) {
          try {
            const htmlBody = buildAuditReportEmailBody({
              reportName: args!.title as string,
              recordCount: 0,
              dateRange: new Date().toISOString().slice(0, 10),
              filters: args!.message as string,
              sharePointUrl: (args!.sharePointUrl as string) || "#",
              fileName: "Manual notification",
            });
            await sendEmailNotification(
              args!.emailRecipients as string[],
              args!.title as string,
              htmlBody,
              args!.emailSender as string | undefined
            );
            results.push(`Email sent to ${(args!.emailRecipients as string[]).join(", ")}`);
          } catch (err: unknown) {
            errors.push(`Email: ${err instanceof Error ? err.message : String(err)}`);
          }
        }

        return {
          content: [
            {
              type: "text" as const,
              text: JSON.stringify(
                {
                  success: errors.length === 0,
                  sent: results,
                  errors: errors.length ? errors : undefined,
                },
                null,
                2
              ),
            },
          ],
        };
      }

      // ========== ANALYTICS & THREAT HUNTING ==========

      case "analyze_audit_risks": {
        const max = Math.min((args!.maxRecords as number) || 5000, 10000);
        const records = await getAllAuditSearchResults(args!.searchId as string, max);
        const analysis = analyzeRisks(records);
        return {
          content: [{
            type: "text" as const,
            text: JSON.stringify(analysis, null, 2),
          }],
        };
      }

      case "generate_executive_summary": {
        const max = Math.min((args!.maxRecords as number) || 5000, 10000);
        const records = await getAllAuditSearchResults(args!.searchId as string, max);
        const summary = generateExecutiveSummary(records);
        return {
          content: [{
            type: "text" as const,
            text: JSON.stringify(summary, null, 2),
          }],
        };
      }

      case "threat_hunting_search": {
        const preset = getThreatHuntPreset(args!.preset as string);
        if (!preset) {
          return {
            content: [{
              type: "text" as const,
              text: JSON.stringify({
                error: `Unknown preset: ${args!.preset}`,
                available: THREAT_HUNT_PRESETS.map((p) => `${p.id}: ${p.name}`),
              }, null, 2),
            }],
            isError: true,
          };
        }

        const searchResult = await createAuditSearch({
          displayName: `[Threat Hunt] ${preset.name}`,
          filterStartDateTime: args!.startDateTime as string,
          filterEndDateTime: args!.endDateTime as string,
          operationFilters: preset.operationFilters,
          serviceFilters: preset.serviceFilters,
          recordTypeFilters: preset.recordTypeFilters,
          keywordFilter: preset.keywordFilter,
          userPrincipalNameFilters: args!.userFilters as string[] | undefined,
        });

        return {
          content: [{
            type: "text" as const,
            text: JSON.stringify({
              success: true,
              threatHunt: {
                preset: preset.id,
                name: preset.name,
                description: preset.description,
                mitreTactic: preset.mitreTactic,
                riskLevel: preset.riskLevel,
              },
              searchId: searchResult.id,
              status: searchResult.status,
              filters: {
                operations: preset.operationFilters,
                services: preset.serviceFilters,
                recordTypes: preset.recordTypeFilters,
              },
              nextSteps: [
                "1. Use get_audit_search_status to check when the search completes",
                "2. Use get_audit_results to view the findings",
                "3. Use analyze_audit_risks to run risk scoring on the results",
                "4. Use generate_executive_summary for a summary report",
              ],
            }, null, 2),
          }],
        };
      }

      case "list_threat_hunts": {
        return {
          content: [{
            type: "text" as const,
            text: JSON.stringify({
              totalPresets: THREAT_HUNT_PRESETS.length,
              presets: THREAT_HUNT_PRESETS.map((p) => ({
                id: p.id,
                name: p.name,
                description: p.description,
                mitreTactic: p.mitreTactic,
                riskLevel: p.riskLevel,
                filters: {
                  operations: p.operationFilters,
                  services: p.serviceFilters,
                },
              })),
            }, null, 2),
          }],
        };
      }

      case "copilot_adoption_analytics": {
        const max = Math.min((args!.maxRecords as number) || 10000, 10000);
        const records = await getAllAuditSearchResults(args!.searchId as string, max);
        const analytics = analyzeCopilotAdoption(records);
        return {
          content: [{
            type: "text" as const,
            text: JSON.stringify(analytics, null, 2),
          }],
        };
      }

      case "user_activity_timeline": {
        const max = Math.min((args!.maxRecords as number) || 5000, 10000);
        const records = await getAllAuditSearchResults(args!.searchId as string, max);
        const timeline = buildUserTimeline(records, args!.userUpn as string);
        return {
          content: [{
            type: "text" as const,
            text: JSON.stringify(timeline, null, 2),
          }],
        };
      }

      case "compare_audit_periods": {
        const max = Math.min((args!.maxRecords as number) || 5000, 10000);
        const [records1, records2] = await Promise.all([
          getAllAuditSearchResults(args!.searchId1 as string, max),
          getAllAuditSearchResults(args!.searchId2 as string, max),
        ]);
        const comparison = compareAuditPeriods(
          records1, records2,
          args!.label1 as string,
          args!.label2 as string
        );
        return {
          content: [{
            type: "text" as const,
            text: JSON.stringify(comparison, null, 2),
          }],
        };
      }

      // ========== SHAREPOINT EXTENDED ==========

      case "sp_search": {
        const result = await searchSharePoint(args!.query as string, args!.entityTypes as string[] | undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }
      case "sp_list_sites": {
        const result = await listSites(args!.search as string | undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }
      case "sp_get_site": {
        const result = await getSiteInfo(args!.siteUrl as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }
      case "sp_create_site": {
        const result = await createSite(args!.displayName as string, args!.alias as string, args!.description as string | undefined, args!.isPublic as boolean | undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }
      case "sp_site_analytics": {
        const result = await getSiteAnalytics(args!.siteUrl as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }
      case "sp_get_lists": {
        const result = await getLists(args!.siteUrl as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }
      case "sp_create_list": {
        const result = await createList(args!.siteUrl as string, args!.displayName as string, args!.columns as Array<{ name: string; type: string; required?: boolean }>);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }
      case "sp_get_list_items": {
        const result = await getListItems(args!.siteUrl as string, args!.listName as string, args!.top as number | undefined, args!.filter as string | undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }
      case "sp_add_list_item": {
        const result = await addListItem(args!.siteUrl as string, args!.listName as string, args!.fields as Record<string, unknown>);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }
      case "sp_update_list_item": {
        const result = await updateListItem(args!.siteUrl as string, args!.listName as string, args!.itemId as string, args!.fields as Record<string, unknown>);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }
      case "sp_delete_list_item": {
        await deleteListItem(args!.siteUrl as string, args!.listName as string, args!.itemId as string);
        return { content: [{ type: "text" as const, text: "List item deleted." }] };
      }
      case "sp_get_list_columns": {
        const result = await getListColumns(args!.siteUrl as string, args!.listName as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }
      case "sp_file_info": {
        const result = await getFileMetadata(args!.siteUrl as string, args!.docLibrary as string, args!.filePath as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }
      case "sp_download_url": {
        const url = await downloadFileUrl(args!.siteUrl as string, args!.docLibrary as string, args!.filePath as string);
        return { content: [{ type: "text" as const, text: JSON.stringify({ downloadUrl: url }, null, 2) }] };
      }
      case "sp_delete_file": {
        await deleteFile(args!.siteUrl as string, args!.docLibrary as string, args!.filePath as string);
        return { content: [{ type: "text" as const, text: "File deleted." }] };
      }
      case "sp_move_file": {
        const result = await moveFile(args!.siteUrl as string, args!.docLibrary as string, args!.sourcePath as string, args!.destFolder as string, args!.newName as string | undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }
      case "sp_copy_file": {
        const result = await copyFile(args!.siteUrl as string, args!.docLibrary as string, args!.sourcePath as string, args!.destFolder as string, args!.newName as string | undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify({ success: true, message: "Copy initiated." }, null, 2) }] };
      }
      case "sp_share_file": {
        const result = await shareFile(args!.siteUrl as string, args!.docLibrary as string, args!.filePath as string, args!.recipients as string[], args!.message as string | undefined, args!.role as string | undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }
      case "sp_create_sharing_link": {
        const result = await createSharingLink(args!.siteUrl as string, args!.docLibrary as string, args!.filePath as string, args!.type as string, args!.scope as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }
      case "sp_get_permissions": {
        const result = await getSitePermissions(args!.siteUrl as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }
      case "sp_get_pages": {
        const result = await getSitePages(args!.siteUrl as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }
      case "sp_get_subsites": {
        const result = await getSubsites(args!.siteUrl as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }
      case "sp_get_content_types": {
        const result = await getContentTypes(args!.siteUrl as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }
      case "sp_get_columns": {
        const result = await getSiteColumns(args!.siteUrl as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(result, null, 2) }] };
      }

      // ========== COPILOT TRACKING & REPORTING ==========

      case "track_copilot_agents": {
        const max = Math.min((args!.maxRecords as number) || 10000, 10000);
        const records = await getAllAuditSearchResults(args!.searchId as string, max);
        const tracking = trackCopilotAgents(records);
        return { content: [{ type: "text" as const, text: JSON.stringify(tracking, null, 2) }] };
      }

      case "generate_copilot_report": {
        const max = Math.min((args!.maxRecords as number) || 10000, 10000);
        const records = await getAllAuditSearchResults(args!.searchId as string, max);
        const tracking = trackCopilotAgents(records);
        const reportPath = generateCopilotHTMLReport(tracking, args!.title as string | undefined);

        let sharePointResult;
        if (args!.uploadToSharePoint && args!.sharePointSiteUrl && args!.docLibrary) {
          sharePointResult = await uploadFileToSharePoint(
            args!.sharePointSiteUrl as string,
            args!.docLibrary as string,
            reportPath,
            args!.targetFolder as string | undefined
          );
        }

        return {
          content: [{
            type: "text" as const,
            text: JSON.stringify({
              success: true,
              report: {
                localPath: reportPath,
                totalInteractions: tracking.summary.totalInteractions,
                uniqueUsers: tracking.summary.uniqueUsers,
                agents: tracking.summary.uniqueAgents,
                dateRange: tracking.summary.dateRange,
              },
              sharePoint: sharePointResult ? {
                webUrl: (sharePointResult as { webUrl: string }).webUrl,
                fileName: (sharePointResult as { name: string }).name,
              } : "Not uploaded (set uploadToSharePoint=true)",
            }, null, 2),
          }],
        };
      }

      case "copilot_trend_analysis": {
        const max = Math.min((args!.maxRecords as number) || 10000, 10000);
        const records = await getAllAuditSearchResults(args!.searchId as string, max);
        const trends = analyzeCopilotTrends(records);
        return { content: [{ type: "text" as const, text: JSON.stringify(trends, null, 2) }] };
      }

      case "schedule_copilot_report": {
        const cron = (args!.cronExpression as string) || "0 7 * * 1";
        const folder = (args!.targetFolder as string) || "Copilot Reports";
        const titlePrefix = (args!.reportTitle as string) || "Copilot Usage Report";

        const schedule = createScheduledAudit({
          name: `${titlePrefix} (Scheduled)`,
          cronExpression: cron,
          searchParams: {
            operationFilters: ["CopilotInteraction"],
          },
          sharePointSiteUrl: args!.sharePointSiteUrl as string,
          sharePointDocLibrary: args!.docLibrary as string,
          sharePointFolder: folder,
          powerAutomateUrl: args!.powerAutomateUrl as string | undefined,
          copilotStudioUrl: args!.copilotStudioUrl as string | undefined,
        });

        return {
          content: [{
            type: "text" as const,
            text: JSON.stringify({
              success: true,
              message: `📊 Copilot Report schedule created!`,
              scheduleId: schedule.id,
              configuration: {
                name: schedule.name,
                schedule: cron,
                operation: "CopilotInteraction",
                sharePoint: `${args!.sharePointSiteUrl} → ${args!.docLibrary}/${folder}`,
                notifications: {
                  powerAutomate: schedule.powerAutomateUrl ? "✅ Enabled" : "❌ Not set",
                  copilotStudio: schedule.copilotStudioUrl ? "✅ Enabled" : "❌ Not set",
                },
              },
              workflow: [
                "1. Cron fires → Search Purview for CopilotInteraction (last 24h)",
                "2. Export results to CSV",
                "3. Upload CSV to SharePoint",
                "4. Trigger notification (Power Automate / Copilot Studio)",
                "TIP: After CSV uploads, use generate_copilot_report to create HTML dashboard report",
              ],
              hint: "Use run_schedule_now to test immediately. Use generate_copilot_report on results for the full HTML dashboard.",
            }, null, 2),
          }],
        };
      }

      // ========== PURVIEW EXTENDED ==========

      case "pv_get_alerts": {
        const r = await getSecurityAlerts(args!.top as number|undefined, args!.filter as string|undefined, args!.serviceSource as string|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_get_alert": {
        const r = await getSecurityAlert(args!.alertId as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_update_alert": {
        const r = await updateSecurityAlert(args!.alertId as string, args!.status as string, args!.classification as string|undefined, args!.assignedTo as string|undefined, args!.comment as string|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_get_incidents": {
        const r = await getSecurityIncidents(args!.top as number|undefined, args!.filter as string|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_get_incident": {
        const r = await getSecurityIncident(args!.incidentId as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_update_incident": {
        const r = await updateSecurityIncident(args!.incidentId as string, args!.status as string, args!.classification as string|undefined, args!.assignedTo as string|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_secure_score": {
        const r = await getSecureScores(args!.top as number|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_secure_score_controls": {
        const r = await getSecureScoreProfiles();
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_list_ediscovery_cases": {
        const r = await listEdiscoveryCases(args!.top as number|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_get_ediscovery_case": {
        const r = await getEdiscoveryCase(args!.caseId as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_create_ediscovery_case": {
        const r = await createEdiscoveryCase(args!.displayName as string, args!.description as string|undefined, args!.externalId as string|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_list_custodians": {
        const r = await listEdiscoveryCustodians(args!.caseId as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_list_ediscovery_searches": {
        const r = await listEdiscoverySearches(args!.caseId as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_risk_detections": {
        const r = await getRiskDetections(args!.top as number|undefined, args!.filter as string|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_risky_users": {
        const r = await getRiskyUsers(args!.top as number|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_risky_signins": {
        const r = await getRiskySignIns(args!.top as number|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_advanced_hunting": {
        const r = await runAdvancedHunting(args!.query as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_hunting_presets": {
        const preset = ADVANCED_HUNTING_QUERIES[args!.preset as string];
        if (!preset) return { content: [{ type: "text" as const, text: `Unknown preset. Available: ${Object.keys(ADVANCED_HUNTING_QUERIES).join(", ")}` }], isError: true };
        const r = await runAdvancedHunting(preset.query);
        return { content: [{ type: "text" as const, text: JSON.stringify({ preset: preset.name, description: preset.description, results: r }, null, 2) }] };
      }
      case "pv_list_retention_labels": {
        const r = await listRetentionLabels();
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_get_retention_label": {
        const r = await getRetentionLabel(args!.labelId as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_threat_intel_articles": {
        const r = await getThreatIntelArticles(args!.top as number|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_list_privacy_requests": {
        const r = await listSubjectRightsRequests();
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_create_privacy_request": {
        const r = await createSubjectRightsRequest(args!.displayName as string, args!.type as string, args!.dataSubjectEmail as string, args!.description as string|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_detect_shadow_it": {
        const max = Math.min((args!.maxRecords as number) || 5000, 10000);
        const records = await getAllAuditSearchResults(args!.searchId as string, max);
        const r = detectShadowIT(records);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_scan_data_exposure": {
        const max = Math.min((args!.maxRecords as number) || 5000, 10000);
        const records = await getAllAuditSearchResults(args!.searchId as string, max);
        const r = scanDataExposure(records);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_compliance_dashboard": {
        const r = await getComplianceHealthDashboard();
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }

      // ========== MOST REQUESTED FEATURES ==========

      case "pv_list_sensitivity_labels": {
        const r = await listSensitivityLabels();
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_get_sensitivity_label": {
        const r = await getSensitivityLabel(args!.labelId as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_assign_sensitivity_label": {
        const r = await assignSensitivityLabelToFile(args!.siteUrl as string, args!.docLibrary as string, args!.filePath as string, args!.labelId as string);
        return { content: [{ type: "text" as const, text: JSON.stringify({ success: true, message: "Sensitivity label assignment initiated.", result: r }, null, 2) }] };
      }
      case "pv_remove_file_label": {
        const r = await removeSensitivityLabelFromFile(args!.siteUrl as string, args!.docLibrary as string, args!.filePath as string);
        return { content: [{ type: "text" as const, text: JSON.stringify({ success: true, message: "Sensitivity label removal initiated.", result: r }, null, 2) }] };
      }
      case "pv_remove_site_label": {
        const r = await removeSiteSensitivityLabel(args!.siteUrl as string);
        return { content: [{ type: "text" as const, text: JSON.stringify({ success: true, message: "Site sensitivity label removed.", result: r }, null, 2) }] };
      }
      case "pv_bulk_remove_labels": {
        const r = await bulkRemoveLabelsFromLibrary(args!.siteUrl as string, args!.docLibrary as string, args!.folderPath as string | undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify({
          success: r.failed === 0,
          message: `Bulk label removal complete: ${r.succeeded}/${r.total} files processed successfully.`,
          ...r,
        }, null, 2) }] };
      }
      case "pv_apply_label_to_site": {
        const r = await applySensitivityLabelToSite(args!.siteUrl as string, args!.labelId as string);
        return { content: [{ type: "text" as const, text: JSON.stringify({ success: true, message: "Sensitivity label applied to site.", result: r }, null, 2) }] };
      }
      case "pv_apply_label_to_library": {
        const r = await applyLabelToAllFilesInLibrary(args!.siteUrl as string, args!.docLibrary as string, args!.labelId as string, args!.folderPath as string | undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify({
          success: r.failed === 0,
          message: `Bulk label applied: ${r.succeeded} labeled, ${r.skipped} skipped (unsupported type), ${r.failed} failed.`,
          ...r,
        }, null, 2) }] };
      }
      case "pv_set_default_library_label": {
        const r = await setDefaultLibraryLabel(args!.siteUrl as string, args!.docLibrary as string, args!.labelId as string);
        return { content: [{ type: "text" as const, text: JSON.stringify({ success: true, message: "Default sensitivity label set for library. New uploads will auto-receive this label.", result: r }, null, 2) }] };
      }
      case "pv_extract_file_labels": {
        const r = await extractFileLabels(args!.siteUrl as string, args!.docLibrary as string, args!.folderPath as string | undefined);
        const labeled = r.filter(f => f.labelId);
        const unlabeled = r.filter(f => !f.labelId && f.labelName !== "unsupported type");
        return { content: [{ type: "text" as const, text: JSON.stringify({
          totalFiles: r.length,
          labeled: labeled.length,
          unlabeled: unlabeled.length,
          files: r,
        }, null, 2) }] };
      }
      case "pv_signin_logs": {
        const r = await getSignInLogs(args!.top as number|undefined, args!.filter as string|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_directory_audits": {
        const r = await getDirectoryAuditLogs(args!.top as number|undefined, args!.filter as string|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_service_health": {
        const r = await getServiceHealth();
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_service_issues": {
        const r = await getServiceHealthIssues(args!.top as number|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_service_messages": {
        const r = await getServiceMessages(args!.top as number|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_list_ca_policies": {
        const r = await listConditionalAccessPolicies();
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_get_ca_policy": {
        const r = await getConditionalAccessPolicy(args!.policyId as string);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_m365_active_users": {
        const r = await getM365ActiveUsers(args!.period as string|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_email_activity": {
        const r = await getEmailActivityReport(args!.period as string|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_sharepoint_activity": {
        const r = await getSharePointActivityReport(args!.period as string|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_teams_activity": {
        const r = await getTeamsActivityReport(args!.period as string|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_onedrive_activity": {
        const r = await getOneDriveActivityReport(args!.period as string|undefined);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }

      // ========== WORKLOAD AUDIT PRESETS ==========

      case "pv_list_workload_presets": {
        const presets = Object.entries(WORKLOAD_AUDIT_PRESETS).map(([key, p]) => ({
          preset: key, name: p.name, description: p.description,
          filters: { operations: p.operationFilters?.length || 0, services: p.serviceFilters?.length || 0 },
        }));
        const categories: Record<string, typeof presets> = {};
        for (const p of presets) {
          const cat = p.preset.split("_")[0];
          if (!categories[cat]) categories[cat] = [];
          categories[cat].push(p);
        }
        return { content: [{ type: "text" as const, text: JSON.stringify({ totalPresets: presets.length, categories }, null, 2) }] };
      }

      case "pv_workload_audit": {
        const preset = WORKLOAD_AUDIT_PRESETS[args!.preset as string];
        if (!preset) {
          return { content: [{ type: "text" as const, text: `Unknown preset "${args!.preset}". Use pv_list_workload_presets to see all ${Object.keys(WORKLOAD_AUDIT_PRESETS).length} available presets.` }], isError: true };
        }
        const searchParams: Record<string, unknown> = {
          displayName: `${preset.name} — ${new Date().toISOString().slice(0, 10)}`,
          filterStartDateTime: args!.startDateTime as string,
          filterEndDateTime: args!.endDateTime as string,
        };
        if (preset.operationFilters?.length) searchParams.operationFilters = preset.operationFilters;
        if (preset.serviceFilters?.length) searchParams.serviceFilters = preset.serviceFilters;
        if (preset.recordTypeFilters?.length) searchParams.recordTypeFilters = preset.recordTypeFilters;
        if (args!.userPrincipalNameFilters) searchParams.userPrincipalNameFilters = args!.userPrincipalNameFilters;
        const search = await createAuditSearch(searchParams as unknown as Parameters<typeof createAuditSearch>[0]);
        return { content: [{ type: "text" as const, text: JSON.stringify({
          success: true, preset: args!.preset, presetName: preset.name,
          searchId: search.id, status: search.status,
          filters: { operations: preset.operationFilters, services: preset.serviceFilters },
          hint: "Use get_audit_search_status to check completion (2-15 min), then get_audit_results.",
        }, null, 2) }] };
      }

      // ========== COPILOT AGENT SECURITY ==========

      case "pv_copilot_agent_security": {
        const max = Math.min((args!.maxRecords as number) || 5000, 10000);
        const records = await getAllAuditSearchResults(args!.searchId as string, max);
        const r = analyzeCopilotAgentSecurity(records);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_copilot_security_report": {
        const max = Math.min((args!.maxRecords as number) || 5000, 10000);
        const records = await getAllAuditSearchResults(args!.searchId as string, max);
        const r = generateCopilotSecurityReport(records);
        return { content: [{ type: "text" as const, text: JSON.stringify(r, null, 2) }] };
      }
      case "pv_copilot_full_security_scan": {
        // Step 1: Create search for all Copilot + agent events
        const scan1 = await createAuditSearch({
          displayName: `Copilot Security Scan — ${new Date().toISOString().slice(0, 10)}`,
          filterStartDateTime: args!.startDateTime as string,
          filterEndDateTime: args!.endDateTime as string,
          operationFilters: ["CopilotInteraction"],
        });
        const scan2 = await createAuditSearch({
          displayName: `Agent Security Scan — ${new Date().toISOString().slice(0, 10)}`,
          filterStartDateTime: args!.startDateTime as string,
          filterEndDateTime: args!.endDateTime as string,
          serviceFilters: ["CopilotStudio"],
        });

        // Step 2: Wait for both
        const [completed1, completed2] = await Promise.all([
          waitForSearchCompletion(scan1.id),
          waitForSearchCompletion(scan2.id),
        ]);

        // Step 3: Get all records from both
        const [records1, records2] = await Promise.all([
          getAllAuditSearchResults(scan1.id, 10000),
          getAllAuditSearchResults(scan2.id, 10000),
        ]);
        const allRecords = [...records1, ...records2];

        // Step 4: Run both analyses
        const security = analyzeCopilotAgentSecurity(allRecords);
        const report = generateCopilotSecurityReport(allRecords);

        return { content: [{ type: "text" as const, text: JSON.stringify({
          scanComplete: true,
          copilotSearch: { id: scan1.id, status: completed1.status, records: records1.length },
          agentSearch: { id: scan2.id, status: completed2.status, records: records2.length },
          totalRecords: allRecords.length,
          securityAnalysis: security,
          securityReport: report,
        }, null, 2) }] };
      }

      // ========== COPILOT USAGE PIPELINE ==========

      case "pv_copilot_usage_pipeline": {
        const periodMap: Record<string, number> = {
          "3months": 3, "6months": 6, "9months": 9, "12months": 12,
        };
        const months = periodMap[args!.period as string] || 3;
        const endDate = new Date();
        const startDate = new Date();
        startDate.setMonth(startDate.getMonth() - months);
        const periodLabel = `Last ${months} months (${startDate.toISOString().slice(0, 10)} to ${endDate.toISOString().slice(0, 10)})`;

        console.error(`[Pipeline] Starting Copilot usage pipeline: ${periodLabel}`);

        // Step 1: Create audit search
        console.error("[Pipeline] Step 1/6: Creating audit search...");
        const search = await createAuditSearch({
          displayName: `Copilot Usage Report — ${periodLabel}`,
          filterStartDateTime: startDate.toISOString(),
          filterEndDateTime: endDate.toISOString(),
          operationFilters: ["CopilotInteraction"],
        });
        console.error(`[Pipeline] Search created: ${search.id}`);

        // Step 2: Wait for completion
        console.error("[Pipeline] Step 2/6: Waiting for search to complete (2-15 min)...");
        await waitForSearchCompletion(search.id);
        console.error("[Pipeline] Search completed!");

        // Step 3: Get all results
        console.error("[Pipeline] Step 3/6: Retrieving results...");
        const records = await getAllAuditSearchResults(search.id, 50000);
        console.error(`[Pipeline] Got ${records.length} records`);

        if (records.length === 0) {
          return { content: [{ type: "text" as const, text: JSON.stringify({
            success: true, pipeline: "complete", totalRecords: 0,
            message: `No CopilotInteraction events found for ${periodLabel}. This could mean: (1) No Copilot licenses assigned, (2) Copilot not used in this period, (3) Audit logging was not enabled.`,
          }, null, 2) }] };
        }

        // Step 4: Export enhanced CSV
        console.error("[Pipeline] Step 4/6: Exporting CSV...");
        const exportDir = process.env.PURVIEW_EXPORT_PATH || "./exports";
        const timestamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
        const csvPath = `${exportDir}/Copilot_Usage_${months}mo_${timestamp}.csv`;
        const csvResult = exportCopilotCSV(records, csvPath);

        // Step 5: Generate HTML dashboard
        console.error("[Pipeline] Step 5/6: Generating dashboard...");
        const tracking = trackCopilotAgents(records);
        const dashboardPath = generateCopilotDashboard(tracking, `Copilot Usage Report — ${periodLabel}`, periodLabel);

        // Step 6: Upload both to SharePoint
        console.error("[Pipeline] Step 6/6: Uploading to SharePoint...");
        const uploadedCSV = await uploadFileToSharePoint(
          args!.sharePointSiteUrl as string,
          args!.docLibrary as string,
          csvPath,
          args!.targetFolder as string | undefined
        );
        const uploadedDashboard = await uploadFileToSharePoint(
          args!.sharePointSiteUrl as string,
          args!.docLibrary as string,
          dashboardPath,
          args!.targetFolder as string | undefined
        );

        console.error("[Pipeline] ✓ Complete!");

        return { content: [{ type: "text" as const, text: JSON.stringify({
          success: true,
          pipeline: "search → export CSV → dashboard → upload",
          period: periodLabel,
          searchId: search.id,
          totalRecords: records.length,
          summary: {
            totalInteractions: tracking.summary.totalInteractions,
            uniqueUsers: tracking.summary.uniqueUsers,
            copilotApps: tracking.summary.uniqueAgents,
            topAgent: tracking.summary.topAgent,
            topUser: tracking.summary.topUser,
          },
          files: {
            csv: { name: uploadedCSV.name, url: uploadedCSV.webUrl, rows: csvResult.rows },
            dashboard: { name: uploadedDashboard.name, url: uploadedDashboard.webUrl },
          },
          sharePoint: {
            site: args!.sharePointSiteUrl,
            library: args!.docLibrary,
            folder: args!.targetFolder || "(root)",
          },
        }, null, 2) }] };
      }

      default:
        return {
          content: [{ type: "text" as const, text: `Unknown tool: ${name}` }],
          isError: true,
        };
    }
  } catch (error: unknown) {
    const errMsg = error instanceof Error ? error.message : String(error);
    return {
      content: [
        {
          type: "text" as const,
          text: JSON.stringify({ error: errMsg }, null, 2),
        },
      ],
      isError: true,
    };
  }
};

// Register on the module-level server (for stdio/Claude Desktop)
server.setRequestHandler(CallToolRequestSchema, callToolHandler);

// ============================================================
// Server Startup
// ============================================================

// --- Shared init function (used by both stdio and web modes) ---
export function initPurviewMCP() {
  const tenantId = process.env.PURVIEW_TENANT_ID;
  const clientId = process.env.PURVIEW_CLIENT_ID;
  const clientSecret = process.env.PURVIEW_CLIENT_SECRET;

  if (!tenantId || !clientId || !clientSecret) {
    throw new Error("Missing PURVIEW_TENANT_ID, PURVIEW_CLIENT_ID, or PURVIEW_CLIENT_SECRET");
  }

  initializeAuth({ tenantId, clientId, clientSecret });
  initializeScheduler();
  console.error("[Purview MCP] Initialized with 96 tools");
}

// --- Stdio mode (Claude Desktop) ---
async function main() {
  const tenantId = process.env.PURVIEW_TENANT_ID;
  const clientId = process.env.PURVIEW_CLIENT_ID;
  const clientSecret = process.env.PURVIEW_CLIENT_SECRET;

  if (!tenantId || !clientId || !clientSecret) {
    console.error(
      "╔══════════════════════════════════════════════════════════════╗\n" +
      "║  Microsoft Purview MCP Server v1.0                          ║\n" +
      "║                                                              ║\n" +
      "║  Required environment variables:                             ║\n" +
      "║    PURVIEW_TENANT_ID     - Azure AD Tenant ID                ║\n" +
      "║    PURVIEW_CLIENT_ID     - App Registration Client ID        ║\n" +
      "║    PURVIEW_CLIENT_SECRET - App Registration Client Secret    ║\n" +
      "║                                                              ║\n" +
      "║  Optional:                                                   ║\n" +
      "║    PURVIEW_EXPORT_PATH   - Local export directory            ║\n" +
      "║                                                              ║\n" +
      "║  Azure App Permissions Required (Application):               ║\n" +
      "║    • AuditLogsQuery.Read.All  (Purview audit search)         ║\n" +
      "║    • Sites.ReadWrite.All      (SharePoint upload)            ║\n" +
      "║    • Files.ReadWrite.All      (SharePoint files)             ║\n" +
      "║    • Mail.Send                (Email notifications)          ║\n" +
      "╚══════════════════════════════════════════════════════════════╝"
    );
    process.exit(1);
  }

  initPurviewMCP();

  // Start MCP server (stdio for Claude Desktop)
  const transport = new StdioServerTransport();
  await server.connect(transport);

  console.error("[Purview MCP] Server started successfully");
}

// Only run stdio mode if this file is the entry point (not imported by web.ts)
const isDirectRun = process.argv[1]?.includes("index.js") || process.argv[1]?.includes("index");
if (isDirectRun) {
  main().catch((error) => {
    console.error("[Purview MCP] Fatal error:", error);
    process.exit(1);
  });
}
