// ============================================================
// Microsoft Purview MCP Server - Copilot Tracking Module
// Track Copilot agent usage, generate HTML reports, trends
// ============================================================

import { AuditRecord } from "./types.js";
import * as fs from "fs";
import * as path from "path";

// ============================================================
// 1. COPILOT AGENT TRACKER
// ============================================================

export interface CopilotAgentData {
  agentName: string;
  appHost: string;
  interactions: number;
  uniqueUsers: number;
  users: string[];
  firstSeen: string;
  lastSeen: string;
}

export interface CopilotTrackingResult {
  summary: {
    totalInteractions: number;
    uniqueUsers: number;
    uniqueAgents: number;
    dateRange: string;
    topAgent: string;
    topUser: string;
  };
  agents: CopilotAgentData[];
  byApp: Record<string, { interactions: number; uniqueUsers: number }>;
  byUser: Array<{
    user: string;
    totalInteractions: number;
    agentsUsed: string[];
    appsUsed: string[];
    firstActivity: string;
    lastActivity: string;
    avgDailyUsage: number;
  }>;
  byDay: Record<string, { total: number; byAgent: Record<string, number> }>;
  byHour: Record<string, number>;
  licensingInsights: {
    activeUsers: number;
    heavyUsers: number;
    lightUsers: number;
    inactiveEstimate: string;
  };
}

export function trackCopilotAgents(records: AuditRecord[]): CopilotTrackingResult {
  const agentMap: Record<string, { users: Set<string>; count: number; app: string; first: string; last: string }> = {};
  const appMap: Record<string, { users: Set<string>; count: number }> = {};
  const userMap: Record<string, { count: number; agents: Set<string>; apps: Set<string>; first: string; last: string; days: Set<string> }> = {};
  const dayMap: Record<string, { total: number; byAgent: Record<string, number> }> = {};
  const hourMap: Record<string, number> = {};

  for (const r of records) {
    const user = r.userPrincipalName || "Unknown";
    const dt = new Date(r.createdDateTime);
    const day = r.createdDateTime.slice(0, 10);
    const hour = `${dt.getUTCHours().toString().padStart(2, "0")}:00`;
    const audit = (r.auditData || {}) as Record<string, unknown>;

    // Extract agent/app info from audit data
    const appHost = extractAppHost(audit, r.service);
    const agentName = extractAgentName(audit, appHost);

    // Agent tracking
    if (!agentMap[agentName]) agentMap[agentName] = { users: new Set(), count: 0, app: appHost, first: r.createdDateTime, last: r.createdDateTime };
    agentMap[agentName].users.add(user);
    agentMap[agentName].count++;
    if (r.createdDateTime < agentMap[agentName].first) agentMap[agentName].first = r.createdDateTime;
    if (r.createdDateTime > agentMap[agentName].last) agentMap[agentName].last = r.createdDateTime;

    // App tracking
    if (!appMap[appHost]) appMap[appHost] = { users: new Set(), count: 0 };
    appMap[appHost].users.add(user);
    appMap[appHost].count++;

    // User tracking
    if (!userMap[user]) userMap[user] = { count: 0, agents: new Set(), apps: new Set(), first: r.createdDateTime, last: r.createdDateTime, days: new Set() };
    userMap[user].count++;
    userMap[user].agents.add(agentName);
    userMap[user].apps.add(appHost);
    userMap[user].days.add(day);
    if (r.createdDateTime < userMap[user].first) userMap[user].first = r.createdDateTime;
    if (r.createdDateTime > userMap[user].last) userMap[user].last = r.createdDateTime;

    // Day tracking
    if (!dayMap[day]) dayMap[day] = { total: 0, byAgent: {} };
    dayMap[day].total++;
    dayMap[day].byAgent[agentName] = (dayMap[day].byAgent[agentName] || 0) + 1;

    // Hour tracking
    hourMap[hour] = (hourMap[hour] || 0) + 1;
  }

  // Build agents array
  const agents: CopilotAgentData[] = Object.entries(agentMap)
    .map(([name, data]) => ({
      agentName: name,
      appHost: data.app,
      interactions: data.count,
      uniqueUsers: data.users.size,
      users: Array.from(data.users).slice(0, 20),
      firstSeen: data.first.slice(0, 10),
      lastSeen: data.last.slice(0, 10),
    }))
    .sort((a, b) => b.interactions - a.interactions);

  // Build app breakdown
  const byApp: Record<string, { interactions: number; uniqueUsers: number }> = {};
  for (const [app, data] of Object.entries(appMap)) {
    byApp[app] = { interactions: data.count, uniqueUsers: data.users.size };
  }

  // Build user array
  const byUser = Object.entries(userMap)
    .map(([user, data]) => ({
      user,
      totalInteractions: data.count,
      agentsUsed: Array.from(data.agents),
      appsUsed: Array.from(data.apps),
      firstActivity: data.first.slice(0, 10),
      lastActivity: data.last.slice(0, 10),
      avgDailyUsage: data.days.size > 0 ? Math.round(data.count / data.days.size) : 0,
    }))
    .sort((a, b) => b.totalInteractions - a.totalInteractions);

  const uniqueUsers = Object.keys(userMap).length;
  const heavyUsers = byUser.filter((u) => u.totalInteractions > 20).length;
  const lightUsers = byUser.filter((u) => u.totalInteractions <= 5).length;

  const days = Object.keys(dayMap).sort();
  const dateRange = days.length ? `${days[0]} → ${days[days.length - 1]}` : "N/A";

  return {
    summary: {
      totalInteractions: records.length,
      uniqueUsers,
      uniqueAgents: agents.length,
      dateRange,
      topAgent: agents[0]?.agentName || "N/A",
      topUser: byUser[0]?.user || "N/A",
    },
    agents,
    byApp,
    byUser: byUser.slice(0, 50),
    byDay: dayMap,
    byHour: hourMap,
    licensingInsights: {
      activeUsers: uniqueUsers,
      heavyUsers,
      lightUsers,
      inactiveEstimate: `Users with Copilot license not appearing in audit data are not using Copilot`,
    },
  };
}

function extractAppHost(audit: Record<string, unknown>, service: string): string {
  const workload = (audit.Workload as string) || service || "";
  const appContext = audit.AppAccessContext as Record<string, unknown> | undefined;
  const appName = appContext?.ClientAppName as string || appContext?.AADOperationType as string || "";

  if (appName) return appName;
  if (workload.includes("Teams")) return "Microsoft Teams";
  if (workload.includes("Exchange") || workload.includes("Outlook")) return "Outlook";
  if (workload.includes("SharePoint") || workload.includes("OneDrive")) return "SharePoint/OneDrive";
  if (workload.includes("Word") || workload.includes("OneNote")) return "Word";
  if (workload.includes("Excel")) return "Excel";
  if (workload.includes("PowerPoint")) return "PowerPoint";
  if (workload.includes("Copilot")) return "Microsoft 365 Copilot Chat";
  return workload || "Microsoft 365";
}

function extractAgentName(audit: Record<string, unknown>, appHost: string): string {
  const copilotData = audit.CopilotEventData as Record<string, unknown> | undefined;
  const agentId = copilotData?.AgentId as string || copilotData?.PluginName as string || copilotData?.SkillName as string || "";
  const contextType = copilotData?.ContextType as string || copilotData?.Type as string || "";

  if (agentId) return agentId;
  if (contextType) return `${appHost} - ${contextType}`;
  return `${appHost} Copilot`;
}

// ============================================================
// 2. HTML REPORT GENERATOR
// ============================================================

export function generateCopilotHTMLReport(
  tracking: CopilotTrackingResult,
  title?: string,
  exportDir?: string
): string {
  const reportTitle = title || `Copilot Usage Report — ${tracking.summary.dateRange}`;
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const filename = `Copilot_Report_${timestamp}.html`;
  const dir = exportDir || process.env.PURVIEW_EXPORT_PATH || "./exports";
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const filePath = path.join(dir, filename);

  // Build daily chart data
  const days = Object.keys(tracking.byDay).sort();
  const dailyData = days.map((d) => ({ date: d, count: tracking.byDay[d].total }));
  const hourlyData = Object.entries(tracking.byHour).sort((a, b) => a[0].localeCompare(b[0]));

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${reportTitle}</title>
<style>
  *{margin:0;padding:0;box-sizing:border-box}
  body{font-family:'Segoe UI',system-ui,sans-serif;background:#f8f9fa;color:#1a1a2e;line-height:1.6;padding:40px 20px}
  .container{max-width:1100px;margin:0 auto}
  .header{background:linear-gradient(135deg,#0078d4,#5c2d91);color:white;padding:40px;border-radius:16px;margin-bottom:32px}
  .header h1{font-size:28px;font-weight:700;margin-bottom:8px}
  .header p{font-size:16px;opacity:0.9}
  .kpi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:32px}
  .kpi{background:white;border-radius:12px;padding:24px;box-shadow:0 1px 3px rgba(0,0,0,0.08)}
  .kpi-value{font-size:36px;font-weight:700;color:#0078d4}
  .kpi-label{font-size:14px;color:#666;margin-top:4px}
  .card{background:white;border-radius:12px;padding:28px;box-shadow:0 1px 3px rgba(0,0,0,0.08);margin-bottom:24px}
  .card h2{font-size:20px;font-weight:600;margin-bottom:16px;color:#1a1a2e;border-bottom:2px solid #0078d4;padding-bottom:8px}
  table{width:100%;border-collapse:collapse;font-size:14px}
  th{background:#f0f6ff;padding:12px 16px;text-align:left;font-weight:600;color:#0078d4;border-bottom:2px solid #ddd}
  td{padding:10px 16px;border-bottom:1px solid #eee}
  tr:hover td{background:#f8f9ff}
  .bar{height:24px;background:linear-gradient(90deg,#0078d4,#5c2d91);border-radius:4px;min-width:4px;transition:width 0.3s}
  .badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600}
  .badge-green{background:#e6f9ee;color:#0d7a3e}
  .badge-blue{background:#e6f1fb;color:#0078d4}
  .badge-amber{background:#fff8e6;color:#8a6914}
  .chart-container{display:flex;align-items:flex-end;gap:4px;height:200px;padding:20px 0}
  .chart-bar{flex:1;background:linear-gradient(180deg,#0078d4,#5c2d91);border-radius:4px 4px 0 0;min-height:4px;position:relative}
  .chart-bar:hover{opacity:0.85}
  .chart-bar span{position:absolute;bottom:-20px;left:50%;transform:translateX(-50%);font-size:10px;color:#666;white-space:nowrap}
  .chart-bar .val{position:absolute;top:-18px;left:50%;transform:translateX(-50%);font-size:11px;color:#333;font-weight:600}
  .footer{text-align:center;padding:24px;color:#999;font-size:13px}
  .rec{padding:12px 16px;margin:8px 0;background:#f0f6ff;border-left:4px solid #0078d4;border-radius:0 8px 8px 0;font-size:14px}
  @media print{body{padding:10px}.header{page-break-after:avoid}}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>🤖 ${reportTitle}</h1>
    <p>Generated ${new Date().toLocaleString("en-US", { dateStyle: "full", timeStyle: "short" })} · Microsoft Purview Audit Data</p>
  </div>

  <div class="kpi-grid">
    <div class="kpi"><div class="kpi-value">${tracking.summary.totalInteractions.toLocaleString()}</div><div class="kpi-label">Total Interactions</div></div>
    <div class="kpi"><div class="kpi-value">${tracking.summary.uniqueUsers}</div><div class="kpi-label">Active Users</div></div>
    <div class="kpi"><div class="kpi-value">${tracking.summary.uniqueAgents}</div><div class="kpi-label">Agents / Apps</div></div>
    <div class="kpi"><div class="kpi-value">${tracking.licensingInsights.heavyUsers}</div><div class="kpi-label">Power Users (20+)</div></div>
    <div class="kpi"><div class="kpi-value">${Math.round(tracking.summary.totalInteractions / Math.max(days.length, 1))}</div><div class="kpi-label">Avg / Day</div></div>
    <div class="kpi"><div class="kpi-value">${Math.round(tracking.summary.totalInteractions / Math.max(tracking.summary.uniqueUsers, 1))}</div><div class="kpi-label">Avg / User</div></div>
  </div>

  <div class="card">
    <h2>📊 Daily Usage Trend</h2>
    <div class="chart-container">
      ${dailyData.map((d) => {
        const maxCount = Math.max(...dailyData.map((x) => x.count), 1);
        const pct = Math.round((d.count / maxCount) * 100);
        return `<div class="chart-bar" style="height:${Math.max(pct, 3)}%" title="${d.date}: ${d.count}"><span>${d.date.slice(5)}</span><div class="val">${d.count}</div></div>`;
      }).join("")}
    </div>
  </div>

  <div class="card">
    <h2>🤖 Copilot Agents / Apps</h2>
    <table>
      <tr><th>Agent / App</th><th>Host</th><th>Interactions</th><th>Users</th><th>Usage</th></tr>
      ${tracking.agents.slice(0, 15).map((a) => {
        const maxInt = Math.max(...tracking.agents.map((x) => x.interactions), 1);
        const pct = Math.round((a.interactions / maxInt) * 100);
        return `<tr><td><strong>${a.agentName}</strong></td><td>${a.appHost}</td><td>${a.interactions.toLocaleString()}</td><td>${a.uniqueUsers}</td><td><div class="bar" style="width:${pct}%"></div></td></tr>`;
      }).join("")}
    </table>
  </div>

  <div class="card">
    <h2>👥 Top Users</h2>
    <table>
      <tr><th>User</th><th>Interactions</th><th>Agents Used</th><th>Apps</th><th>Avg/Day</th><th>Usage</th></tr>
      ${tracking.byUser.slice(0, 20).map((u) => {
        const maxInt = Math.max(...tracking.byUser.map((x) => x.totalInteractions), 1);
        const pct = Math.round((u.totalInteractions / maxInt) * 100);
        const badge = u.totalInteractions > 20 ? '<span class="badge badge-green">Power User</span>' : u.totalInteractions > 5 ? '<span class="badge badge-blue">Active</span>' : '<span class="badge badge-amber">Light</span>';
        return `<tr><td><strong>${u.user}</strong> ${badge}</td><td>${u.totalInteractions.toLocaleString()}</td><td>${u.agentsUsed.length}</td><td>${u.appsUsed.join(", ")}</td><td>${u.avgDailyUsage}</td><td><div class="bar" style="width:${pct}%"></div></td></tr>`;
      }).join("")}
    </table>
  </div>

  <div class="card">
    <h2>⏰ Hourly Distribution</h2>
    <div class="chart-container">
      ${hourlyData.map(([hour, count]) => {
        const maxH = Math.max(...hourlyData.map(([, c]) => c), 1);
        const pct = Math.round((count / maxH) * 100);
        return `<div class="chart-bar" style="height:${Math.max(pct, 3)}%" title="${hour}: ${count}"><span>${hour.slice(0, 2)}</span><div class="val">${count}</div></div>`;
      }).join("")}
    </div>
  </div>

  <div class="card">
    <h2>📋 Licensing Insights</h2>
    <table>
      <tr><td><strong>Active Copilot Users</strong></td><td>${tracking.licensingInsights.activeUsers}</td></tr>
      <tr><td><strong>Power Users (20+ interactions)</strong></td><td>${tracking.licensingInsights.heavyUsers}</td></tr>
      <tr><td><strong>Light Users (≤5 interactions)</strong></td><td>${tracking.licensingInsights.lightUsers}</td></tr>
    </table>
  </div>

  <div class="card">
    <h2>💡 Recommendations</h2>
    ${tracking.byUser.length < 5 ? '<div class="rec">📈 Low adoption — consider Copilot training sessions and identifying champions.</div>' : ''}
    ${tracking.licensingInsights.lightUsers > tracking.licensingInsights.heavyUsers * 2 ? '<div class="rec">🔄 Many light users detected — review if Copilot licenses are optimally allocated.</div>' : ''}
    ${tracking.licensingInsights.heavyUsers > 0 ? `<div class="rec">⭐ ${tracking.licensingInsights.heavyUsers} power user(s) identified — leverage them as Copilot champions for peer training.</div>` : ''}
    ${tracking.agents.length > 3 ? `<div class="rec">🤖 ${tracking.agents.length} different agents/apps in use — healthy diversity across the Microsoft 365 suite.</div>` : ''}
    <div class="rec">✅ Report generated from Microsoft Purview audit logs — CopilotInteraction events.</div>
  </div>

  <div class="footer">
    <p>Generated by Microsoft Purview MCP Server · Power of Automation</p>
    <p>Data source: Microsoft Purview Unified Audit Log · ${tracking.summary.dateRange}</p>
  </div>
</div>
</body>
</html>`;

  fs.writeFileSync(filePath, html, "utf-8");
  return filePath;
}

// ============================================================
// 3. COPILOT TREND ANALYSIS
// ============================================================

export interface CopilotTrendResult {
  weekOverWeek: {
    thisWeek: number;
    lastWeek: number;
    change: string;
    trend: "increasing" | "declining" | "stable";
  };
  userGrowth: {
    newUsersThisPeriod: number;
    returningUsers: number;
    churnedUsers: number;
  };
  agentTrends: Array<{
    agent: string;
    trend: "increasing" | "declining" | "stable" | "new";
    recentCount: number;
    previousCount: number;
  }>;
  peakUsage: {
    peakDay: string;
    peakDayCount: number;
    peakHour: string;
    peakHourCount: number;
  };
  forecast: string;
}

export function analyzeCopilotTrends(records: AuditRecord[]): CopilotTrendResult {
  const now = new Date();
  const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const twoWeeksAgo = new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000);

  const thisWeek = records.filter((r) => new Date(r.createdDateTime) >= oneWeekAgo);
  const lastWeek = records.filter((r) => {
    const dt = new Date(r.createdDateTime);
    return dt >= twoWeeksAgo && dt < oneWeekAgo;
  });

  const thisWeekUsers = new Set(thisWeek.map((r) => r.userPrincipalName));
  const lastWeekUsers = new Set(lastWeek.map((r) => r.userPrincipalName));

  const newUsers = Array.from(thisWeekUsers).filter((u) => !lastWeekUsers.has(u));
  const returningUsers = Array.from(thisWeekUsers).filter((u) => lastWeekUsers.has(u));
  const churnedUsers = Array.from(lastWeekUsers).filter((u) => !thisWeekUsers.has(u));

  const weekChange = lastWeek.length > 0
    ? Math.round(((thisWeek.length - lastWeek.length) / lastWeek.length) * 100)
    : thisWeek.length > 0 ? 100 : 0;
  const trend = weekChange > 10 ? "increasing" : weekChange < -10 ? "declining" : "stable";

  // Agent trends
  const agentThisWeek: Record<string, number> = {};
  const agentLastWeek: Record<string, number> = {};
  for (const r of thisWeek) {
    const audit = (r.auditData || {}) as Record<string, unknown>;
    const app = extractAppHost(audit, r.service);
    const agent = extractAgentName(audit, app);
    agentThisWeek[agent] = (agentThisWeek[agent] || 0) + 1;
  }
  for (const r of lastWeek) {
    const audit = (r.auditData || {}) as Record<string, unknown>;
    const app = extractAppHost(audit, r.service);
    const agent = extractAgentName(audit, app);
    agentLastWeek[agent] = (agentLastWeek[agent] || 0) + 1;
  }

  const allAgents = new Set([...Object.keys(agentThisWeek), ...Object.keys(agentLastWeek)]);
  const agentTrends = Array.from(allAgents).map((agent) => {
    const recent = agentThisWeek[agent] || 0;
    const previous = agentLastWeek[agent] || 0;
    let agentTrend: "increasing" | "declining" | "stable" | "new" = "stable";
    if (previous === 0 && recent > 0) agentTrend = "new";
    else if (recent > previous * 1.2) agentTrend = "increasing";
    else if (recent < previous * 0.8) agentTrend = "declining";
    return { agent, trend: agentTrend, recentCount: recent, previousCount: previous };
  }).sort((a, b) => b.recentCount - a.recentCount);

  // Peak usage
  const dayCount: Record<string, number> = {};
  const hourCount: Record<string, number> = {};
  for (const r of records) {
    const day = r.createdDateTime.slice(0, 10);
    const hour = `${new Date(r.createdDateTime).getUTCHours().toString().padStart(2, "0")}:00`;
    dayCount[day] = (dayCount[day] || 0) + 1;
    hourCount[hour] = (hourCount[hour] || 0) + 1;
  }
  const peakDay = Object.entries(dayCount).sort((a, b) => b[1] - a[1])[0] || ["N/A", 0];
  const peakHour = Object.entries(hourCount).sort((a, b) => b[1] - a[1])[0] || ["N/A", 0];

  const forecast = trend === "increasing"
    ? `At current growth rate (+${weekChange}%), expect ~${Math.round(thisWeek.length * 1.1)} interactions next week.`
    : trend === "declining"
    ? `Usage declining ${Math.abs(weekChange)}% week-over-week. Consider engagement initiatives.`
    : `Stable usage pattern. Expect similar volume (~${thisWeek.length}) next week.`;

  return {
    weekOverWeek: {
      thisWeek: thisWeek.length,
      lastWeek: lastWeek.length,
      change: `${weekChange >= 0 ? "+" : ""}${weekChange}%`,
      trend,
    },
    userGrowth: {
      newUsersThisPeriod: newUsers.length,
      returningUsers: returningUsers.length,
      churnedUsers: churnedUsers.length,
    },
    agentTrends: agentTrends.slice(0, 15),
    peakUsage: {
      peakDay: peakDay[0] as string,
      peakDayCount: peakDay[1] as number,
      peakHour: peakHour[0] as string,
      peakHourCount: peakHour[1] as number,
    },
    forecast,
  };
}

// ============================================================
// ENHANCED COPILOT CSV EXPORT — extracts agent names, users, env
// ============================================================

export function exportCopilotCSV(records: AuditRecord[], filePath: string): { path: string; rows: number } {
  const headers = [
    "DateTime", "User", "Operation", "AgentApp", "AgentName",
    "ThreadId", "AccessedResources", "SensitivityLabels",
    "WebSearchUsed", "ClientIP", "OrganizationId",
  ];

  const csvLines: string[] = [headers.join(",")];

  for (const r of records) {
    if (r.operation !== "CopilotInteraction") continue;
    const audit = (r.auditData || {}) as Record<string, unknown>;
    const copilot = audit.CopilotEventData as Record<string, unknown> | undefined;

    const appHost = (copilot?.AppHost as string) || "";
    const threadId = (copilot?.ThreadId as string) || "";
    const resources = copilot?.AccessedResources as Array<{ Name?: string; SensitivityLabelId?: string }> | undefined;
    const plugins = copilot?.AISystemPlugin as Array<{ Id?: string }> | undefined;
    const webSearch = plugins?.some(p => p.Id === "BingWebSearch") ? "Yes" : "No";

    const resourceNames = resources?.map(r => r.Name || "").filter(Boolean).join("; ") || "";
    const labels = resources?.map(r => r.SensitivityLabelId || "").filter(Boolean).join("; ") || "";

    csvLines.push([
      esc(r.createdDateTime || ""),
      esc(r.userPrincipalName || ""),
      esc(r.operation),
      esc(appHost),
      esc(appHost), // agent name = app host for M365 Copilot
      esc(threadId),
      esc(resourceNames),
      esc(labels),
      webSearch,
      esc(r.clientIp || ""),
      esc(r.organizationId || ""),
    ].join(","));
  }

  fs.writeFileSync(filePath, csvLines.join("\n"), "utf-8");
  return { path: filePath, rows: csvLines.length - 1 };
}

function esc(v: string): string {
  if (v.includes(",") || v.includes('"') || v.includes("\n")) return `"${v.replace(/"/g, '""')}"`;
  return v;
}

// ============================================================
// FANCY HTML DASHBOARD — KPIs, charts, agent table, user table
// ============================================================

export function generateCopilotDashboard(
  tracking: CopilotTrackingResult,
  title: string,
  periodLabel: string
): string {
  const { summary, agents, byUser, byDay, byHour } = tracking;

  // Daily trend data for chart
  const sortedDays = Object.entries(byDay).sort(([a], [b]) => a.localeCompare(b));
  const dayLabels = sortedDays.map(([d]) => d.slice(5)); // MM-DD
  const dayValues = sortedDays.map(([, v]) => v.total);

  // Hourly distribution
  const hours = Array.from({ length: 24 }, (_, i) => byHour[String(i)] || 0);
  const peakHour = hours.indexOf(Math.max(...hours));

  // Top 10 agents
  const topAgents = agents.slice(0, 10);
  // Top 15 users
  const topUsers = byUser.slice(0, 15);

  // User badges
  const powerUsers = byUser.filter(u => u.totalInteractions >= 20).length;
  const activeUsers = byUser.filter(u => u.totalInteractions >= 5 && u.totalInteractions < 20).length;
  const lightUsers = byUser.filter(u => u.totalInteractions < 5).length;

  const html = `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${title}</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',system-ui,sans-serif;background:#0d1117;color:#e6edf3;padding:24px}
.hdr{text-align:center;padding:32px 0 24px;border-bottom:2px solid #30363d;margin-bottom:32px}
.hdr h1{font-size:28px;font-weight:700;background:linear-gradient(135deg,#fff,#8b5cf6,#22d3ee);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.hdr p{color:#8b949e;font-size:14px;margin-top:8px}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-bottom:28px}
.kpi{background:#161b22;border:1px solid #30363d;border-radius:12px;padding:18px;text-align:center}
.kpi .v{font-size:32px;font-weight:800;color:#58a6ff}.kpi .v.p{color:#8b5cf6}.kpi .v.g{color:#34d399}.kpi .v.o{color:#f59e0b}.kpi .v.r{color:#f87171}
.kpi .l{font-size:11px;color:#8b949e;text-transform:uppercase;letter-spacing:1px;margin-top:4px}
.card{background:#161b22;border:1px solid #30363d;border-radius:12px;padding:20px;margin-bottom:20px}
.card h2{font-size:16px;font-weight:700;margin-bottom:14px;color:#58a6ff}
table{width:100%;border-collapse:collapse;font-size:13px}
th{background:#21262d;padding:8px 10px;text-align:left;color:#8b5cf6;font-size:11px;text-transform:uppercase;letter-spacing:.5px;border-bottom:2px solid #30363d}
td{padding:8px 10px;border-bottom:1px solid #21262d}
tr:hover{background:#1c2128}
.badge{display:inline-block;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:700}
.b-power{background:rgba(139,92,246,.2);color:#a78bfa}.b-active{background:rgba(52,211,153,.2);color:#6ee7b7}.b-light{background:rgba(245,158,11,.2);color:#fbbf24}
.chart{display:flex;align-items:flex-end;gap:2px;height:120px;margin:10px 0}
.bar{flex:1;background:linear-gradient(180deg,#8b5cf6,#3b82f6);border-radius:3px 3px 0 0;min-width:4px;transition:all .2s;position:relative}
.bar:hover{opacity:.8}.bar:hover::after{content:attr(data-v);position:absolute;top:-20px;left:50%;transform:translateX(-50%);font-size:10px;color:#fff;background:#21262d;padding:2px 6px;border-radius:4px;white-space:nowrap}
.hbar{display:flex;align-items:flex-end;gap:1px;height:80px}
.hb{flex:1;background:#30363d;border-radius:2px 2px 0 0;position:relative}
.hb.peak{background:#f59e0b}
.ft{text-align:center;padding:20px;color:#484f58;font-size:12px;margin-top:20px}
</style></head><body>
<div class="hdr">
<h1>${title}</h1>
<p>${periodLabel} | Generated ${new Date().toISOString().slice(0, 16).replace("T", " ")} UTC | Power of Automation</p>
</div>

<div class="kpis">
<div class="kpi"><div class="v">${summary.totalInteractions.toLocaleString()}</div><div class="l">Total Interactions</div></div>
<div class="kpi"><div class="v p">${summary.uniqueUsers}</div><div class="l">Unique Users</div></div>
<div class="kpi"><div class="v g">${summary.uniqueAgents}</div><div class="l">Copilot Apps</div></div>
<div class="kpi"><div class="v o">${powerUsers}</div><div class="l">Power Users (20+)</div></div>
<div class="kpi"><div class="v">${activeUsers}</div><div class="l">Active Users (5-19)</div></div>
<div class="kpi"><div class="v r">${lightUsers}</div><div class="l">Light Users (&lt;5)</div></div>
<div class="kpi"><div class="v g">${peakHour}:00</div><div class="l">Peak Hour</div></div>
<div class="kpi"><div class="v">${sortedDays.length}</div><div class="l">Active Days</div></div>
</div>

<div class="card">
<h2>📈 Daily Usage Trend</h2>
<div class="chart">${dayValues.length > 0 ? dayValues.map((v, i) => {
    const maxV = Math.max(...dayValues, 1);
    const h = Math.max(4, (v / maxV) * 100);
    return `<div class="bar" style="height:${h}%" data-v="${dayLabels[i]}: ${v}"></div>`;
  }).join("") : "<p style='color:#8b949e'>No daily data</p>"}</div>
<div style="display:flex;justify-content:space-between;font-size:10px;color:#484f58;margin-top:4px">
<span>${dayLabels[0] || ""}</span><span>${dayLabels[Math.floor(dayLabels.length / 2)] || ""}</span><span>${dayLabels[dayLabels.length - 1] || ""}</span>
</div>
</div>

<div class="card">
<h2>🤖 Top Copilot Apps / Agents</h2>
<table><tr><th>#</th><th>App / Agent</th><th>Interactions</th><th>Users</th><th>Share</th></tr>
${topAgents.map((a, i) => {
    const pct = summary.totalInteractions > 0 ? ((a.interactions / summary.totalInteractions) * 100).toFixed(1) : "0";
    return `<tr><td>${i + 1}</td><td><strong>${a.appHost || a.agentName}</strong></td><td>${a.interactions.toLocaleString()}</td><td>${a.uniqueUsers}</td><td>${pct}%</td></tr>`;
  }).join("")}
</table></div>

<div class="card">
<h2>👥 Top Users by Copilot Usage</h2>
<table><tr><th>#</th><th>User</th><th>Interactions</th><th>Apps Used</th><th>Avg/Day</th><th>Badge</th></tr>
${topUsers.map((u, i) => {
    const badge = u.totalInteractions >= 20 ? '<span class="badge b-power">Power</span>' :
      u.totalInteractions >= 5 ? '<span class="badge b-active">Active</span>' :
      '<span class="badge b-light">Light</span>';
    return `<tr><td>${i + 1}</td><td>${u.user}</td><td>${u.totalInteractions}</td><td>${u.appsUsed.join(", ")}</td><td>${u.avgDailyUsage.toFixed(1)}</td><td>${badge}</td></tr>`;
  }).join("")}
</table></div>

<div class="card">
<h2>⏰ Hourly Distribution</h2>
<div class="hbar">${hours.map((v, i) => {
    const maxH = Math.max(...hours, 1);
    const h = Math.max(2, (v / maxH) * 100);
    const isPeak = i === peakHour;
    return `<div class="hb${isPeak ? " peak" : ""}" style="height:${h}%" title="${i}:00 — ${v} interactions"></div>`;
  }).join("")}</div>
<div style="display:flex;justify-content:space-between;font-size:10px;color:#484f58;margin-top:4px">
<span>12AM</span><span>6AM</span><span>12PM</span><span>6PM</span><span>11PM</span>
</div>
</div>

<div class="card">
<h2>💡 Licensing Insights</h2>
<table><tr><th>Category</th><th>Count</th><th>Recommendation</th></tr>
<tr><td>🟣 Power Users (20+ interactions)</td><td>${powerUsers}</td><td>Core Copilot ROI — ensure they have premium features</td></tr>
<tr><td>🟢 Active Users (5-19)</td><td>${activeUsers}</td><td>Growing adoption — provide tips & training</td></tr>
<tr><td>🟡 Light Users (&lt;5)</td><td>${lightUsers}</td><td>Low adoption — consider training or license reallocation</td></tr>
</table></div>

<div class="ft">Purview MCP Server v6.0 · 105 Tools · Power of Automation</div>
</body></html>`;

  const exportDir = process.env.PURVIEW_EXPORT_PATH || "./exports";
  if (!fs.existsSync(exportDir)) fs.mkdirSync(exportDir, { recursive: true });
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const outPath = path.join(exportDir, `Copilot_Dashboard_${timestamp}.html`);
  fs.writeFileSync(outPath, html, "utf-8");
  return outPath;
}
