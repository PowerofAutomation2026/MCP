// ============================================================
// Microsoft Purview MCP Server - Authentication Module
// Uses MSAL for client credentials flow (app-only auth)
// ============================================================

import { ConfidentialClientApplication, Configuration } from "@azure/msal-node";
import { PurviewConfig } from "./types.js";

let msalClient: ConfidentialClientApplication | null = null;
let cachedToken: { token: string; expiresOn: number } | null = null;

const GRAPH_SCOPE = "https://graph.microsoft.com/.default";

export function initializeAuth(config: PurviewConfig): void {
  const msalConfig: Configuration = {
    auth: {
      clientId: config.clientId,
      authority: `https://login.microsoftonline.com/${config.tenantId}`,
      clientSecret: config.clientSecret,
    },
    system: {
      loggerOptions: {
        loggerCallback: () => {},
        piiLoggingEnabled: false,
        logLevel: 0,
      },
    },
  };

  msalClient = new ConfidentialClientApplication(msalConfig);
  cachedToken = null;
}

export async function getAccessToken(): Promise<string> {
  if (!msalClient) {
    throw new Error(
      "Auth not initialized. Set PURVIEW_TENANT_ID, PURVIEW_CLIENT_ID, PURVIEW_CLIENT_SECRET environment variables."
    );
  }

  // Return cached token if still valid (with 5 min buffer)
  if (cachedToken && cachedToken.expiresOn > Date.now() + 300000) {
    return cachedToken.token;
  }

  try {
    const result = await msalClient.acquireTokenByClientCredential({
      scopes: [GRAPH_SCOPE],
    });

    if (!result || !result.accessToken) {
      throw new Error("Failed to acquire access token - no token returned");
    }

    cachedToken = {
      token: result.accessToken,
      expiresOn: result.expiresOn ? result.expiresOn.getTime() : Date.now() + 3600000,
    };

    return cachedToken.token;
  } catch (error: unknown) {
    const errMsg = error instanceof Error ? error.message : String(error);
    throw new Error(`Authentication failed: ${errMsg}`);
  }
}

export async function graphRequest(
  method: string,
  endpoint: string,
  body?: unknown,
  headers?: Record<string, string>
): Promise<unknown> {
  const token = await getAccessToken();

  const url = endpoint.startsWith("https://")
    ? endpoint
    : `https://graph.microsoft.com/v1.0${endpoint}`;

  console.error(`[Graph] ${method} ${url}`);

  const requestHeaders: Record<string, string> = {
    Authorization: `Bearer ${token}`,
    "Content-Type": "application/json",
    ...headers,
  };

  const options: RequestInit = {
    method,
    headers: requestHeaders,
  };

  if (body && (method === "POST" || method === "PUT" || method === "PATCH")) {
    options.body = typeof body === "string" ? body : JSON.stringify(body);
  }

  const response = await fetch(url, options);

  console.error(`[Graph] Response: ${response.status} ${response.statusText}`);

  if (response.status === 204) {
    return { success: true };
  }

  const contentType = response.headers.get("content-type") || "";

  if (!response.ok) {
    let errorBody: string;
    try {
      errorBody = await response.text();
    } catch {
      errorBody = `HTTP ${response.status} ${response.statusText}`;
    }
    throw new Error(`Graph API error ${response.status}: ${errorBody}`);
  }

  if (contentType.includes("application/json")) {
    return await response.json();
  }

  return await response.text();
}

/**
 * Upload binary content to Graph API (for SharePoint file uploads)
 */
export async function graphUpload(
  endpoint: string,
  content: Buffer | string,
  contentType: string = "application/octet-stream"
): Promise<unknown> {
  const token = await getAccessToken();

  const url = endpoint.startsWith("https://")
    ? endpoint
    : `https://graph.microsoft.com/v1.0${endpoint}`;

  const body = typeof content === "string" ? content : new Uint8Array(content);
  const response = await fetch(url, {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": contentType,
    },
    body,
  });

  if (!response.ok) {
    const errorBody = await response.text();
    throw new Error(`Graph upload error ${response.status}: ${errorBody}`);
  }

  return await response.json();
}
