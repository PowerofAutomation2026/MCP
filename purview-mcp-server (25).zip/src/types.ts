// ============================================================
// Microsoft Purview MCP Server - Type Definitions
// ============================================================

export interface PurviewConfig {
  tenantId: string;
  clientId: string;
  clientSecret: string;
  sharePointSiteUrl?: string;
  sharePointDocLibrary?: string;
  exportPath?: string;
}

// --- Audit Search Types ---

export interface AuditSearchRequest {
  displayName: string;
  filterStartDateTime: string;
  filterEndDateTime: string;
  operationFilters?: string[];
  userPrincipalNameFilters?: string[];
  ipAddressFilters?: string[];
  objectIdFilters?: string[];
  administrativeUnitIdFilters?: string[];
  recordTypeFilters?: string[];
  serviceFilters?: string[];
  keywordFilter?: string;
}

export interface AuditSearchResponse {
  id: string;
  displayName: string;
  createdDateTime: string;
  filterStartDateTime: string;
  filterEndDateTime: string;
  status: "notStarted" | "running" | "succeeded" | "failed" | "cancelled";
  operationFilters?: string[];
  userPrincipalNameFilters?: string[];
  recordTypeFilters?: string[];
  serviceFilters?: string[];
}

export interface AuditRecord {
  id: string;
  createdDateTime: string;
  userPrincipalName: string;
  operation: string;
  organizationId: string;
  clientIp: string;
  service: string;
  objectId?: string;
  userId?: string;
  auditData: Record<string, unknown>;
  administrativeUnits?: string[];
}

export interface AuditSearchResultsPage {
  "@odata.count"?: number;
  "@odata.nextLink"?: string;
  value: AuditRecord[];
}

// --- SharePoint Types ---

export interface SharePointSite {
  id: string;
  name: string;
  displayName: string;
  webUrl: string;
}

export interface SharePointDrive {
  id: string;
  name: string;
  driveType: string;
  webUrl: string;
}

export interface SharePointDriveItem {
  id: string;
  name: string;
  webUrl: string;
  size: number;
  createdDateTime: string;
  file?: {
    mimeType: string;
  };
}

// --- Scheduler Types ---

export interface ScheduledAudit {
  id: string;
  name: string;
  cronExpression: string;
  searchParams: AuditSearchRequest;
  sharePointSiteUrl: string;
  sharePointDocLibrary: string;
  sharePointFolder?: string;
  powerAutomateUrl?: string;
  copilotStudioUrl?: string;
  teamsWebhookUrl?: string;
  emailRecipients?: string[];
  emailSender?: string;
  lastRun?: string;
  lastStatus?: string;
  enabled: boolean;
  createdAt: string;
}

export interface SchedulerState {
  schedules: Map<string, ScheduledAudit>;
}

// --- Graph API Response Types ---

export interface GraphBatchRequest {
  requests: Array<{
    id: string;
    method: string;
    url: string;
    headers?: Record<string, string>;
    body?: unknown;
  }>;
}

export interface GraphErrorResponse {
  error: {
    code: string;
    message: string;
    innerError?: {
      code: string;
      message: string;
    };
  };
}

// --- Record Type Enum ---
export const AUDIT_RECORD_TYPES = [
  "ExchangeAdmin",
  "ExchangeItem",
  "ExchangeItemGroup",
  "SharePoint",
  "SyntheticProbe",
  "SharePointFileOperation",
  "OneDrive",
  "AzureActiveDirectory",
  "AzureActiveDirectoryAccountLogon",
  "DataCenterSecurityCmdlet",
  "ComplianceDLPSharePoint",
  "Sway",
  "ComplianceDLPExchange",
  "SharePointSharingOperation",
  "AzureActiveDirectoryStsLogon",
  "SkypeForBusinessPSTNUsage",
  "SkypeForBusinessUsersBlocked",
  "SecurityComplianceCenterEOPCmdlet",
  "ExchangeAggregatedOperation",
  "PowerBIAudit",
  "CRM",
  "Yammer",
  "SkypeForBusinessCmdlets",
  "Discovery",
  "MicrosoftTeams",
  "ThreatIntelligence",
  "MailSubmission",
  "MicrosoftFlow",
  "AeD",
  "MicrosoftStream",
  "ComplianceDLPSharePointClassification",
  "ThreatFinder",
  "Project",
  "SharePointListOperation",
  "DataGovernance",
  "SecurityComplianceAlerts",
  "ThreatIntelligenceUrl",
  "SecurityComplianceInsights",
  "MIPLabel",
  "WorkplaceAnalytics",
  "PowerAppsApp",
  "PowerAppsPlan",
  "ThreatIntelligenceAtpContent",
  "LabelContentExplorer",
  "TeamsHealthcare",
  "ExchangeItemAggregated",
  "HygieneEvent",
  "DataInsightsRestApiAudit",
  "InformationBarrierPolicyApplication",
  "SharePointListItemOperation",
  "SharePointContentTypeOperation",
  "SharePointFieldOperation",
  "MicrosoftTeamsAdmin",
  "HRSignal",
  "MicrosoftTeamsDevice",
  "MicrosoftTeamsAnalytics",
  "InformationWorkerProtection",
  "Campaign",
  "DLPEndpoint",
  "AirInvestigation",
  "Quarantine",
  "MicrosoftForms",
  "ApplicationAudit",
  "ComplianceSupervisionExchange",
  "CustomerKeyServiceEncryption",
  "OfficeNative",
  "MipAutoLabelSharePointItem",
  "MipAutoLabelSharePointPolicyLocation",
  "MicrosoftTeamsShifts",
  "MipAutoLabelExchangeItem",
  "CortanaBriefing",
  "Search",
  "WDATPAlerts",
  "MDATPAudit",
  "PowerPlatformAdminDlp",
  "PowerPlatformAdminEnvironment",
  "MDATPAudit",
  "SensitivityLabelPolicyMatch",
  "SensitivityLabelAction",
  "SensitivityLabeledFileAction",
  "AttackSim",
  "AirManualInvestigation",
  "SecurityComplianceRBAC",
  "UserTraining",
  "AirAdminActionInvestigation",
  "MSTIC",
  "PhysicalBadgingSignal",
  "AipDiscover",
  "AipSensitivityLabelAction",
  "AipProtectionAction",
  "AipFileDeleted",
  "AipHeartBeat",
  "MCASAlerts",
  "OnPremisesFileShareScannerDlp",
  "OnPremisesSharePointScannerDlp",
  "ExchangeSearch",
  "SharePointSearch",
  "PrivacyFolderEmail",
  "PrivacyDataMinimization",
  "LabelAnalyticsAggregate",
  "MyAnalyticsSettings",
  "SecurityComplianceUserChange",
  "ComplianceDLPExchangeClassification",
  "MipExactDataMatch",
  "MS365DCustomDetection",
  "CoreReportingSettings",
  "ComplianceConnector",
  "PowerPlatformLockboxResourceAccessRequest",
  "PowerPlatformLockboxResourceCommand",
  "CdpDlpSensitive",
  "EHRConnector",
  "FilteringDocMetadata",
  "FilteringEmailFeatures",
  "FilteringUrlInfo",
  "FilteringAttachmentInfo",
  "CdpCompliancePolicyExecution"
] as const;

// --- Service Filters ---
export const AUDIT_SERVICES = [
  "AzureActiveDirectory",
  "Exchange",
  "SharePoint",
  "OneDrive",
  "SecurityComplianceCenter",
  "Sway",
  "PowerBI",
  "CRM",
  "Yammer",
  "MicrosoftTeams",
  "ThreatIntelligence",
  "MicrosoftFlow",
  "MicrosoftStream",
  "Project",
  "PowerApps",
  "Workplace Analytics",
  "Dynamics365",
  "SkypeForBusiness",
  "MicrosoftForms",
  "MicrosoftPurview",
  "Defender"
] as const;
