// ============================================================
// Microsoft Purview MCP Server - Scheduler Module
// Schedule daily audit searches with auto-export to SharePoint
// Uses node-cron for scheduling
// ============================================================

import cron from "node-cron";
import * as fs from "fs";
import * as path from "path";
import { ScheduledAudit, AuditSearchRequest } from "./types.js";
import {
  createAuditSearch,
  waitForSearchCompletion,
  getAllAuditSearchResults,
  exportToCSV,
  exportToJSON,
  generateExportFilename,
} from "./audit.js";
import { uploadFileToSharePoint } from "./sharepoint.js";
import { notifyAuditComplete } from "./notifications.js";
import { trackCopilotAgents, generateCopilotHTMLReport } from "./copilot-tracking.js";

// In-memory schedule store + persisted to disk
const schedules = new Map<string, ScheduledAudit>();
const cronJobs = new Map<string, cron.ScheduledTask>();
const SCHEDULES_FILE = path.join(
  process.env.PURVIEW_EXPORT_PATH || "./exports",
  ".purview_schedules.json"
);

// --- Initialize scheduler (load persisted schedules) ---
export function initializeScheduler(): void {
  loadSchedules();

  // Re-activate enabled schedules
  let activeCount = 0;
  for (const [id, schedule] of schedules) {
    if (schedule.enabled) {
      activateCronJob(id, schedule);
      activeCount++;
      console.error(`[Scheduler]   → "${schedule.name}" cron: ${schedule.cronExpression} (lastRun: ${schedule.lastRun || "never"})`);
    }
  }

  console.error(
    `[Scheduler] Initialized with ${schedules.size} schedule(s), ${activeCount} active`
  );

  // Heartbeat — log every 10 minutes to confirm scheduler is alive
  setInterval(() => {
    const activeJobs = Array.from(cronJobs.keys()).length;
    console.error(`[Scheduler] ♥ Heartbeat — ${activeJobs} active cron jobs, ${schedules.size} total schedules`);
  }, 600000); // 10 minutes
}

// --- Create a new scheduled audit ---
export function createScheduledAudit(params: {
  name: string;
  cronExpression: string;
  searchParams: Omit<AuditSearchRequest, "filterStartDateTime" | "filterEndDateTime" | "displayName">;
  sharePointSiteUrl: string;
  sharePointDocLibrary: string;
  sharePointFolder?: string;
  powerAutomateUrl?: string;
  copilotStudioUrl?: string;
  teamsWebhookUrl?: string;
  emailRecipients?: string[];
  emailSender?: string;
  operationFilters?: string[];
  userPrincipalNameFilters?: string[];
  recordTypeFilters?: string[];
  serviceFilters?: string[];
  keywordFilter?: string;
}): ScheduledAudit {
  // Validate cron expression
  if (!cron.validate(params.cronExpression)) {
    throw new Error(
      `Invalid cron expression: "${params.cronExpression}". ` +
        `Use standard cron format: "minute hour day month weekday". ` +
        `Example: "0 6 * * *" for daily at 6 AM UTC.`
    );
  }

  const id = `sched_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

  const schedule: ScheduledAudit = {
    id,
    name: params.name,
    cronExpression: params.cronExpression,
    searchParams: {
      displayName: `[Scheduled] ${params.name}`,
      filterStartDateTime: "", // Will be computed at runtime
      filterEndDateTime: "",
      ...params.searchParams,
    },
    sharePointSiteUrl: params.sharePointSiteUrl,
    sharePointDocLibrary: params.sharePointDocLibrary,
    sharePointFolder: params.sharePointFolder,
    powerAutomateUrl: params.powerAutomateUrl,
    copilotStudioUrl: params.copilotStudioUrl,
    teamsWebhookUrl: params.teamsWebhookUrl,
    emailRecipients: params.emailRecipients,
    emailSender: params.emailSender,
    enabled: true,
    createdAt: new Date().toISOString(),
  };

  schedules.set(id, schedule);
  activateCronJob(id, schedule);
  saveSchedules();

  return schedule;
}

// --- Activate cron job ---
function activateCronJob(id: string, schedule: ScheduledAudit): void {
  // Kill existing job if any
  if (cronJobs.has(id)) {
    cronJobs.get(id)!.stop();
  }

  // Validate cron expression
  if (!cron.validate(schedule.cronExpression)) {
    console.error(`[Scheduler] Invalid cron expression for "${schedule.name}": ${schedule.cronExpression}`);
    return;
  }

  const job = cron.schedule(schedule.cronExpression, async () => {
    console.error(`[Scheduler] ⏰ CRON FIRED: "${schedule.name}" at ${new Date().toISOString()}`);
    try {
      const result = await executeScheduledAudit(id);
      console.error(`[Scheduler] ✓ Completed: ${result}`);
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : String(err);
      console.error(`[Scheduler] ✗ Failed: ${errMsg}`);
      // Update status even on error so lastRun is recorded
      const sched = schedules.get(id);
      if (sched) {
        sched.lastRun = new Date().toISOString();
        sched.lastStatus = `Failed: ${errMsg}`;
        saveSchedules();
      }
    }
  });

  // Explicitly start the job (ensures it fires at cron time)
  job.start();

  cronJobs.set(id, job);
  console.error(`[Scheduler] Activated: "${schedule.name}" — cron: ${schedule.cronExpression} (next fire in UTC)`);
}

// --- Execute a scheduled audit ---
export async function executeScheduledAudit(scheduleId: string): Promise<string> {
  const schedule = schedules.get(scheduleId);
  if (!schedule) {
    throw new Error(`Schedule not found: ${scheduleId}`);
  }

  try {
    // Compute time range: last 24 hours
    const endTime = new Date();
    const startTime = new Date(endTime.getTime() - 24 * 60 * 60 * 1000);

    const searchParams: AuditSearchRequest = {
      ...schedule.searchParams,
      displayName: `[Scheduled] ${schedule.name} - ${endTime.toISOString().slice(0, 10)}`,
      filterStartDateTime: startTime.toISOString(),
      filterEndDateTime: endTime.toISOString(),
    };

    // 1. Create audit search
    console.error(`[Scheduler] Creating audit search: ${searchParams.displayName}`);
    const search = await createAuditSearch(searchParams);

    // 2. Wait for completion
    console.error(`[Scheduler] Waiting for search ${search.id} to complete...`);
    await waitForSearchCompletion(search.id, 600000); // 10 min timeout

    // 3. Get all results
    console.error(`[Scheduler] Fetching results...`);
    const records = await getAllAuditSearchResults(search.id);

    // 4. Export to CSV
    const exportPath = generateExportFilename(schedule.name, "csv");
    exportToCSV(records, exportPath);
    console.error(`[Scheduler] Exported ${records.length} records to ${exportPath}`);

    // 5. Generate HTML analytics report (if CopilotInteraction search)
    let htmlReportPath: string | undefined;
    const isCopilotSearch = schedule.searchParams.operationFilters?.includes("CopilotInteraction");
    if (records.length > 0) {
      try {
        const tracking = trackCopilotAgents(records);
        const reportTitle = isCopilotSearch
          ? `Copilot Usage Report — ${endTime.toISOString().slice(0, 10)}`
          : `Purview Audit Analytics — ${endTime.toISOString().slice(0, 10)}`;
        htmlReportPath = generateCopilotHTMLReport(tracking, reportTitle);
        console.error(`[Scheduler] Generated HTML report: ${htmlReportPath}`);
      } catch (err) {
        console.error(`[Scheduler] HTML report generation failed:`, err);
      }
    }

    // 6. Upload CSV to SharePoint
    console.error(
      `[Scheduler] Uploading to SharePoint: ${schedule.sharePointSiteUrl} / ${schedule.sharePointDocLibrary}`
    );
    const uploaded = await uploadFileToSharePoint(
      schedule.sharePointSiteUrl,
      schedule.sharePointDocLibrary,
      exportPath,
      schedule.sharePointFolder
    );

    // 7. Upload HTML analytics report to same SharePoint folder
    let uploadedReport;
    if (htmlReportPath) {
      try {
        uploadedReport = await uploadFileToSharePoint(
          schedule.sharePointSiteUrl,
          schedule.sharePointDocLibrary,
          htmlReportPath,
          schedule.sharePointFolder
        );
        console.error(`[Scheduler] ✓ HTML report uploaded: ${(uploadedReport as { webUrl: string }).webUrl}`);
      } catch (err) {
        console.error(`[Scheduler] HTML report upload failed:`, err);
      }
    }

    // 8. Send notifications (Teams webhook + email)
    const filters = [
      schedule.searchParams.operationFilters?.length
        ? `Operations: ${schedule.searchParams.operationFilters.join(", ")}`
        : null,
      schedule.searchParams.serviceFilters?.length
        ? `Services: ${schedule.searchParams.serviceFilters.join(", ")}`
        : null,
      schedule.searchParams.userPrincipalNameFilters?.length
        ? `Users: ${schedule.searchParams.userPrincipalNameFilters.join(", ")}`
        : null,
      schedule.searchParams.recordTypeFilters?.length
        ? `Record Types: ${schedule.searchParams.recordTypeFilters.join(", ")}`
        : null,
    ]
      .filter(Boolean)
      .join(" | ");

    if (schedule.powerAutomateUrl || schedule.copilotStudioUrl || schedule.teamsWebhookUrl || schedule.emailRecipients?.length) {
      console.error(`[Scheduler] Sending notifications...`);
      const notifyResult = await notifyAuditComplete({
        reportName: searchParams.displayName,
        recordCount: records.length,
        startDate: startTime.toISOString(),
        endDate: endTime.toISOString(),
        filters,
        sharePointUrl: uploaded.webUrl,
        fileName: uploaded.name,
        powerAutomateUrl: schedule.powerAutomateUrl,
        copilotStudioUrl: schedule.copilotStudioUrl,
        teamsWebhookUrl: schedule.teamsWebhookUrl,
        emailRecipients: schedule.emailRecipients,
        emailSender: schedule.emailSender,
      });

      if (notifyResult.errors.length) {
        console.error(`[Scheduler] Notification errors:`, notifyResult.errors);
      }
      if (notifyResult.powerAutomateNotified) {
        console.error(`[Scheduler] ✓ Power Automate flow triggered`);
      }
      if (notifyResult.copilotStudioNotified) {
        console.error(`[Scheduler] ✓ Copilot Studio agent notified`);
      }
      if (notifyResult.teamsNotified) {
        console.error(`[Scheduler] ✓ Teams webhook sent`);
      }
      if (notifyResult.emailNotified) {
        console.error(`[Scheduler] ✓ Email notification sent`);
      }
    }

    // 9. Update schedule status
    const reportUrl = uploadedReport ? (uploadedReport as { webUrl: string }).webUrl : "";
    schedule.lastRun = new Date().toISOString();
    schedule.lastStatus = `Success: ${records.length} records → CSV: ${uploaded.webUrl}${reportUrl ? ` | Report: ${reportUrl}` : ""}`;
    saveSchedules();

    console.error(`[Scheduler] ✓ Completed: ${uploaded.webUrl}`);
    return `Scheduled audit completed: ${records.length} records. CSV: ${uploaded.webUrl}${reportUrl ? ` | Analytics Report: ${reportUrl}` : ""}`;
  } catch (error: unknown) {
    const errMsg = error instanceof Error ? error.message : String(error);
    schedule.lastRun = new Date().toISOString();
    schedule.lastStatus = `Failed: ${errMsg}`;
    saveSchedules();
    console.error(`[Scheduler] ✗ Failed: ${errMsg}`);
    throw error;
  }
}

// --- List all schedules (with active cron status) ---
export function listScheduledAudits(): Array<ScheduledAudit & { cronActive: boolean }> {
  return Array.from(schedules.entries()).map(([id, s]) => ({
    ...s,
    cronActive: cronJobs.has(id),
  }));
}

// --- Get a specific schedule ---
export function getScheduledAudit(id: string): ScheduledAudit | undefined {
  return schedules.get(id);
}

// --- Enable/disable schedule ---
export function toggleSchedule(id: string, enabled: boolean): ScheduledAudit {
  const schedule = schedules.get(id);
  if (!schedule) {
    throw new Error(`Schedule not found: ${id}`);
  }

  schedule.enabled = enabled;

  if (enabled) {
    activateCronJob(id, schedule);
  } else {
    if (cronJobs.has(id)) {
      cronJobs.get(id)!.stop();
      cronJobs.delete(id);
    }
  }

  saveSchedules();
  return schedule;
}

// --- Delete schedule ---
export function deleteScheduledAudit(id: string): void {
  if (cronJobs.has(id)) {
    cronJobs.get(id)!.stop();
    cronJobs.delete(id);
  }
  schedules.delete(id);
  saveSchedules();
}

// --- Run a schedule immediately (manual trigger) ---
export async function runScheduleNow(id: string): Promise<string> {
  const schedule = schedules.get(id);
  if (!schedule) {
    throw new Error(`Schedule not found: ${id}`);
  }
  return await executeScheduledAudit(id);
}

// --- Persist schedules to disk ---
function saveSchedules(): void {
  try {
    const dir = path.dirname(SCHEDULES_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    const data = JSON.stringify(Array.from(schedules.entries()), null, 2);
    fs.writeFileSync(SCHEDULES_FILE, data, "utf-8");
  } catch (error) {
    console.error("[Scheduler] Failed to save schedules:", error);
  }
}

// --- Load schedules from disk ---
function loadSchedules(): void {
  try {
    if (fs.existsSync(SCHEDULES_FILE)) {
      const data = fs.readFileSync(SCHEDULES_FILE, "utf-8");
      const entries = JSON.parse(data) as [string, ScheduledAudit][];
      for (const [id, schedule] of entries) {
        schedules.set(id, schedule);
      }
    }
  } catch (error) {
    console.error("[Scheduler] Failed to load schedules:", error);
  }
}
