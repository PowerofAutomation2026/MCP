// ============================================================
// Microsoft Purview MCP Server - Audit Search Module
// Uses Microsoft Graph API: /security/auditLog/queries
// ============================================================

import { graphRequest } from "./auth.js";
import {
  AuditSearchRequest,
  AuditSearchResponse,
  AuditRecord,
  AuditSearchResultsPage,
} from "./types.js";
import * as fs from "fs";
import * as path from "path";

// --- Create a new audit search ---
export async function createAuditSearch(
  params: AuditSearchRequest
): Promise<AuditSearchResponse> {
  const body: Record<string, unknown> = {
    displayName: params.displayName,
    filterStartDateTime: params.filterStartDateTime,
    filterEndDateTime: params.filterEndDateTime,
  };

  if (params.operationFilters?.length) body.operationFilters = params.operationFilters;
  if (params.userPrincipalNameFilters?.length) body.userPrincipalNameFilters = params.userPrincipalNameFilters;
  if (params.ipAddressFilters?.length) body.ipAddressFilters = params.ipAddressFilters;
  if (params.objectIdFilters?.length) body.objectIdFilters = params.objectIdFilters;
  if (params.administrativeUnitIdFilters?.length) body.administrativeUnitIdFilters = params.administrativeUnitIdFilters;
  if (params.recordTypeFilters?.length) body.recordTypeFilters = params.recordTypeFilters;
  if (params.serviceFilters?.length) body.serviceFilters = params.serviceFilters;
  if (params.keywordFilter) body.keywordFilter = params.keywordFilter;

  // Try v1.0 first, then beta endpoint as fallback
  try {
    console.error("[Audit] Trying v1.0: POST /security/auditLog/queries");
    const result = await graphRequest("POST", "/security/auditLog/queries", body);
    return result as AuditSearchResponse;
  } catch (err: unknown) {
    const errMsg = err instanceof Error ? err.message : String(err);
    console.error(`[Audit] v1.0 failed: ${errMsg}`);

    // If "segment not found" or 400/404, try beta
    if (errMsg.includes("not found") || errMsg.includes("400") || errMsg.includes("404") || errMsg.includes("segment")) {
      console.error("[Audit] Trying beta: POST https://graph.microsoft.com/beta/security/auditLog/queries");
      try {
        const result = await graphRequest("POST", "https://graph.microsoft.com/beta/security/auditLog/queries", body);
        return result as AuditSearchResponse;
      } catch (betaErr: unknown) {
        const betaMsg = betaErr instanceof Error ? betaErr.message : String(betaErr);
        console.error(`[Audit] Beta also failed: ${betaMsg}`);
        throw new Error(
          `Audit search failed on both v1.0 and beta endpoints.\n` +
          `v1.0 error: ${errMsg}\n` +
          `Beta error: ${betaMsg}\n\n` +
          `Troubleshooting:\n` +
          `1. Verify AuditLogsQuery.Read.All permission (not AuditLog.Read.All) is granted with admin consent\n` +
          `2. Go to purview.microsoft.com → Audit → verify audit search works in the portal\n` +
          `3. Check if audit logging is turned ON in your tenant\n` +
          `4. Your tenant may need M365 E3/E5 or Purview Audit license`
        );
      }
    }
    throw err;
  }
}

// --- Get audit search by ID ---
export async function getAuditSearch(searchId: string): Promise<AuditSearchResponse> {
  try {
    return (await graphRequest("GET", `/security/auditLog/queries/${searchId}`)) as AuditSearchResponse;
  } catch {
    return (await graphRequest("GET", `https://graph.microsoft.com/beta/security/auditLog/queries/${searchId}`)) as AuditSearchResponse;
  }
}

// --- List all audit searches ---
export async function listAuditSearches(): Promise<AuditSearchResponse[]> {
  try {
    const result = (await graphRequest("GET", "/security/auditLog/queries")) as { value: AuditSearchResponse[] };
    return result.value || [];
  } catch {
    const result = (await graphRequest("GET", "https://graph.microsoft.com/beta/security/auditLog/queries")) as { value: AuditSearchResponse[] };
    return result.value || [];
  }
}

// --- Delete an audit search ---
export async function deleteAuditSearch(searchId: string): Promise<void> {
  try {
    await graphRequest("DELETE", `/security/auditLog/queries/${searchId}`);
  } catch {
    await graphRequest("DELETE", `https://graph.microsoft.com/beta/security/auditLog/queries/${searchId}`);
  }
}

// --- Get audit search results (paginated) ---
export async function getAuditSearchResults(
  searchId: string,
  top: number = 100,
  skipToken?: string
): Promise<AuditSearchResultsPage> {
  let url = `/security/auditLog/queries/${searchId}/records?$top=${top}`;
  if (skipToken) url += `&$skipToken=${skipToken}`;
  try {
    return (await graphRequest("GET", url)) as AuditSearchResultsPage;
  } catch {
    const betaUrl = `https://graph.microsoft.com/beta${url}`;
    return (await graphRequest("GET", betaUrl)) as AuditSearchResultsPage;
  }
}

// --- Get ALL results (auto-paginate) ---
export async function getAllAuditSearchResults(
  searchId: string,
  maxRecords: number = 10000
): Promise<AuditRecord[]> {
  const allRecords: AuditRecord[] = [];
  let nextLink: string | undefined;
  let page = 0;

  do {
    let result: AuditSearchResultsPage;

    if (nextLink) {
      result = (await graphRequest("GET", nextLink)) as AuditSearchResultsPage;
    } else {
      result = await getAuditSearchResults(searchId, 200);
    }

    if (result.value?.length) {
      allRecords.push(...result.value);
    }

    nextLink = result["@odata.nextLink"];
    page++;

    // Safety limit
    if (allRecords.length >= maxRecords) {
      break;
    }
  } while (nextLink);

  return allRecords;
}

// --- Poll until search completes ---
export async function waitForSearchCompletion(
  searchId: string,
  timeoutMs: number = 900000,  // 15 minutes (3-month searches can take 10+ min)
  pollIntervalMs: number = 15000  // 15 seconds between polls
): Promise<AuditSearchResponse> {
  const startTime = Date.now();
  let pollCount = 0;

  while (Date.now() - startTime < timeoutMs) {
    pollCount++;
    const elapsed = Math.round((Date.now() - startTime) / 1000);
    console.error(`[Audit] Poll #${pollCount} (${elapsed}s elapsed) — checking search ${searchId}...`);

    const search = await getAuditSearch(searchId);
    console.error(`[Audit] Status: ${search.status}`);

    if (search.status === "succeeded") {
      console.error(`[Audit] ✓ Search completed after ${elapsed}s`);
      return search;
    }

    if (search.status === "failed" || search.status === "cancelled") {
      throw new Error(`Audit search ${search.status}: ${search.displayName}`);
    }

    // Status is "notStarted" or "running" — keep waiting
    if (pollCount === 1) {
      console.error(`[Audit] Search queued. Purview audit searches can take 2-15 minutes. Polling every ${pollIntervalMs / 1000}s...`);
    }

    // Wait before next poll — use longer interval after first few checks
    const interval = pollCount > 4 ? 30000 : pollIntervalMs;
    await new Promise((resolve) => setTimeout(resolve, interval));
  }

  // Timed out but search may still be running
  const finalStatus = await getAuditSearch(searchId);
  throw new Error(
    `Audit search timed out after ${Math.round(timeoutMs / 60000)} minutes. ` +
    `Current status: ${finalStatus.status}. ` +
    `Search ID: ${searchId}. ` +
    `The search may still be running — try checking status again in a few minutes with: get_audit_search_status`
  );
}

// --- Export results to CSV ---
export function exportToCSV(records: AuditRecord[], filePath: string): string {
  if (!records.length) {
    fs.writeFileSync(filePath, "No records found", "utf-8");
    return filePath;
  }

  // Build CSV headers from first record + common fields
  const headers = [
    "CreatedDateTime",
    "UserPrincipalName",
    "Operation",
    "Service",
    "ClientIP",
    "ObjectId",
    "OrganizationId",
    "AuditData",
  ];

  const csvLines: string[] = [headers.join(",")];

  for (const record of records) {
    const row = [
      escapeCSV(record.createdDateTime || ""),
      escapeCSV(record.userPrincipalName || ""),
      escapeCSV(record.operation || ""),
      escapeCSV(record.service || ""),
      escapeCSV(record.clientIp || ""),
      escapeCSV(record.objectId || ""),
      escapeCSV(record.organizationId || ""),
      escapeCSV(JSON.stringify(record.auditData || {})),
    ];
    csvLines.push(row.join(","));
  }

  fs.writeFileSync(filePath, csvLines.join("\n"), "utf-8");
  return filePath;
}

// --- Export results to JSON ---
export function exportToJSON(records: AuditRecord[], filePath: string): string {
  const exportData = {
    exportedAt: new Date().toISOString(),
    totalRecords: records.length,
    records: records,
  };

  fs.writeFileSync(filePath, JSON.stringify(exportData, null, 2), "utf-8");
  return filePath;
}

// --- CSV escape helper ---
function escapeCSV(value: string): string {
  if (value.includes(",") || value.includes('"') || value.includes("\n")) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}

// --- Generate export filename ---
export function generateExportFilename(
  searchName: string,
  format: "csv" | "json",
  exportDir?: string
): string {
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const safeName = searchName.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 50);
  const filename = `Purview_Audit_${safeName}_${timestamp}.${format}`;
  const dir = exportDir || process.env.PURVIEW_EXPORT_PATH || "./exports";

  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  return path.join(dir, filename);
}
