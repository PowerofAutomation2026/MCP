// ============================================================
// Microsoft Purview MCP Server - Purview Extended Module
// Security Alerts, DLP, eDiscovery, Secure Score, Identity Risk,
// Advanced Hunting, Retention Labels, Shadow IT Detection
// ============================================================

import { graphRequest } from "./auth.js";
import { AuditRecord } from "./types.js";

// ============================================================
// 1. SECURITY ALERTS (DLP, Insider Risk, Defender)
// ============================================================

export async function getSecurityAlerts(
  top?: number,
  filter?: string,
  serviceSource?: string
): Promise<unknown> {
  let endpoint = `/security/alerts_v2?$top=${top || 50}&$orderby=createdDateTime desc`;
  if (filter) endpoint += `&$filter=${encodeURIComponent(filter)}`;
  if (serviceSource) endpoint += `&$filter=serviceSource eq '${serviceSource}'`;
  return await graphRequest("GET", endpoint);
}

export async function getSecurityAlert(alertId: string): Promise<unknown> {
  return await graphRequest("GET", `/security/alerts_v2/${alertId}`);
}

export async function updateSecurityAlert(
  alertId: string,
  status: string,
  classification?: string,
  assignedTo?: string,
  comment?: string
): Promise<unknown> {
  const body: Record<string, unknown> = { status };
  if (classification) body.classification = classification;
  if (assignedTo) body.assignedTo = assignedTo;
  if (comment) {
    body.comments = [{ comment, createdByDisplayName: "Purview MCP Server" }];
  }
  return await graphRequest("PATCH", `/security/alerts_v2/${alertId}`, body);
}

// ============================================================
// 2. SECURITY INCIDENTS
// ============================================================

export async function getSecurityIncidents(top?: number, filter?: string): Promise<unknown> {
  let endpoint = `/security/incidents?$top=${top || 50}&$orderby=createdDateTime desc`;
  if (filter) endpoint += `&$filter=${encodeURIComponent(filter)}`;
  return await graphRequest("GET", endpoint);
}

export async function getSecurityIncident(incidentId: string): Promise<unknown> {
  return await graphRequest("GET", `/security/incidents/${incidentId}`);
}

export async function updateSecurityIncident(
  incidentId: string,
  status: string,
  classification?: string,
  assignedTo?: string
): Promise<unknown> {
  const body: Record<string, unknown> = { status };
  if (classification) body.classification = classification;
  if (assignedTo) body.assignedTo = assignedTo;
  return await graphRequest("PATCH", `/security/incidents/${incidentId}`, body);
}

// ============================================================
// 3. SECURE SCORE (Compliance Posture)
// ============================================================

export async function getSecureScores(top?: number): Promise<unknown> {
  return await graphRequest("GET", `/security/secureScores?$top=${top || 5}`);
}

export async function getSecureScoreProfiles(): Promise<unknown> {
  return await graphRequest("GET", `/security/secureScoreControlProfiles?$top=100`);
}

// ============================================================
// 4. eDISCOVERY
// ============================================================

export async function listEdiscoveryCases(top?: number): Promise<unknown> {
  return await graphRequest("GET", `/security/cases/ediscoveryCases?$top=${top || 50}`);
}

export async function getEdiscoveryCase(caseId: string): Promise<unknown> {
  return await graphRequest("GET", `/security/cases/ediscoveryCases/${caseId}`);
}

export async function createEdiscoveryCase(
  displayName: string,
  description?: string,
  externalId?: string
): Promise<unknown> {
  const body: Record<string, unknown> = { displayName };
  if (description) body.description = description;
  if (externalId) body.externalId = externalId;
  return await graphRequest("POST", "/security/cases/ediscoveryCases", body);
}

export async function listEdiscoveryCustodians(caseId: string): Promise<unknown> {
  return await graphRequest("GET", `/security/cases/ediscoveryCases/${caseId}/custodians`);
}

export async function listEdiscoverySearches(caseId: string): Promise<unknown> {
  return await graphRequest("GET", `/security/cases/ediscoveryCases/${caseId}/searches`);
}

// ============================================================
// 5. IDENTITY RISK DETECTIONS
// ============================================================

export async function getRiskDetections(top?: number, filter?: string): Promise<unknown> {
  let endpoint = `/identityProtection/riskDetections?$top=${top || 50}&$orderby=detectedDateTime desc`;
  if (filter) endpoint += `&$filter=${encodeURIComponent(filter)}`;
  return await graphRequest("GET", endpoint);
}

export async function getRiskyUsers(top?: number): Promise<unknown> {
  return await graphRequest("GET", `/identityProtection/riskyUsers?$top=${top || 50}&$orderby=riskLastUpdatedDateTime desc`);
}

export async function getRiskySignIns(top?: number): Promise<unknown> {
  return await graphRequest("GET", `/auditLogs/signIns?$top=${top || 50}&$filter=riskLevelDuringSignIn ne 'none'&$orderby=createdDateTime desc`);
}

// ============================================================
// 6. ADVANCED HUNTING (KQL)
// ============================================================

export async function runAdvancedHunting(query: string): Promise<unknown> {
  return await graphRequest("POST", "/security/runHuntingQuery", { Query: query });
}

// Pre-built KQL queries
export const ADVANCED_HUNTING_QUERIES: Record<string, { name: string; description: string; query: string }> = {
  suspicious_logins: {
    name: "Suspicious Sign-ins (Last 24h)",
    description: "Failed sign-ins followed by successful sign-ins from different IPs",
    query: `AADSignInEventsBeta
| where Timestamp > ago(24h)
| where ErrorCode != 0
| summarize FailedAttempts=count(), DistinctIPs=dcount(IPAddress) by AccountUpn
| where FailedAttempts > 5 and DistinctIPs > 2
| sort by FailedAttempts desc`,
  },
  mass_file_download: {
    name: "Mass File Downloads",
    description: "Users downloading unusually large numbers of files",
    query: `CloudAppEvents
| where Timestamp > ago(24h)
| where ActionType == "FileDownloaded"
| summarize DownloadCount=count(), UniqueFiles=dcount(ObjectName) by AccountDisplayName
| where DownloadCount > 50
| sort by DownloadCount desc`,
  },
  new_inbox_rules: {
    name: "New Inbox Rules (Potential BEC)",
    description: "Recently created inbox rules that could indicate business email compromise",
    query: `CloudAppEvents
| where Timestamp > ago(7d)
| where ActionType in ("New-InboxRule", "Set-InboxRule", "UpdateInboxRules")
| project Timestamp, AccountDisplayName, ActionType, RawEventData
| sort by Timestamp desc`,
  },
  external_sharing_spike: {
    name: "External Sharing Spike",
    description: "Unusual increase in external file sharing",
    query: `CloudAppEvents
| where Timestamp > ago(24h)
| where ActionType in ("AnonymousLinkCreated", "SharingInvitationCreated", "CompanyLinkCreated")
| summarize ShareCount=count() by AccountDisplayName
| where ShareCount > 10
| sort by ShareCount desc`,
  },
  admin_role_changes: {
    name: "Admin Role Assignments",
    description: "Recent changes to admin role assignments",
    query: `CloudAppEvents
| where Timestamp > ago(7d)
| where ActionType has "role" or ActionType has "admin"
| project Timestamp, AccountDisplayName, ActionType, ObjectName
| sort by Timestamp desc`,
  },
  copilot_heavy_usage: {
    name: "Copilot Heavy Usage",
    description: "Users with highest Copilot interaction volume",
    query: `CloudAppEvents
| where Timestamp > ago(7d)
| where ActionType == "CopilotInteraction"
| summarize InteractionCount=count() by AccountDisplayName
| sort by InteractionCount desc
| take 20`,
  },
};

// ============================================================
// 7. RETENTION LABELS
// ============================================================

export async function listRetentionLabels(): Promise<unknown> {
  return await graphRequest("GET", "/security/labels/retentionLabels?$top=100");
}

export async function getRetentionLabel(labelId: string): Promise<unknown> {
  return await graphRequest("GET", `/security/labels/retentionLabels/${labelId}`);
}

// ============================================================
// 8. THREAT INTELLIGENCE
// ============================================================

export async function searchThreatIntelligence(query: string, type?: string): Promise<unknown> {
  const entityType = type || "host";
  return await graphRequest("GET", `/security/threatIntelligence/${entityType}s?$filter=contains(id,'${query}')&$top=20`);
}

export async function getThreatIntelArticles(top?: number): Promise<unknown> {
  return await graphRequest("GET", `/security/threatIntelligence/articles?$top=${top || 20}&$orderby=createdDateTime desc`);
}

// ============================================================
// 9. SUBJECT RIGHTS REQUESTS (Privacy/DSAR)
// ============================================================

export async function listSubjectRightsRequests(): Promise<unknown> {
  return await graphRequest("GET", "/privacy/subjectRightsRequests?$top=50");
}

export async function createSubjectRightsRequest(
  displayName: string,
  type: string,
  dataSubjectEmail: string,
  description?: string
): Promise<unknown> {
  const body = {
    displayName,
    type,
    description: description || "",
    dataSubject: { email: dataSubjectEmail },
    internalDueDateTime: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
  };
  return await graphRequest("POST", "/privacy/subjectRightsRequests", body);
}

// ============================================================
// 10. CREATIVE: SHADOW IT DETECTION
// ============================================================

export function detectShadowIT(records: AuditRecord[]): {
  summary: { totalApps: number; unknownApps: number; riskyApps: number };
  apps: Array<{
    appName: string;
    category: "known" | "unknown" | "risky";
    users: number;
    events: number;
    firstSeen: string;
    lastSeen: string;
    operations: string[];
  }>;
  recommendations: string[];
} {
  const KNOWN_APPS = new Set([
    "Microsoft Teams", "SharePoint", "OneDrive", "Exchange", "Outlook",
    "Word", "Excel", "PowerPoint", "OneNote", "Planner", "Power BI",
    "Power Automate", "Power Apps", "Dynamics 365", "Yammer", "Stream",
    "Forms", "Sway", "Whiteboard", "Loop", "Viva", "Copilot",
    "Azure Active Directory", "AzureActiveDirectory", "SecurityComplianceCenter",
    "MicrosoftTeams", "MicrosoftFlow", "PowerApps",
  ]);

  const appMap: Record<string, { users: Set<string>; events: number; first: string; last: string; ops: Set<string> }> = {};

  for (const r of records) {
    const audit = (r.auditData || {}) as Record<string, unknown>;
    const appName = (audit.ApplicationId as string) ||
      (audit.ClientAppId as string) ||
      (audit.Application as string) ||
      r.service || "Unknown";

    if (!appMap[appName]) appMap[appName] = { users: new Set(), events: 0, first: r.createdDateTime, last: r.createdDateTime, ops: new Set() };
    appMap[appName].users.add(r.userPrincipalName || "unknown");
    appMap[appName].events++;
    appMap[appName].ops.add(r.operation);
    if (r.createdDateTime < appMap[appName].first) appMap[appName].first = r.createdDateTime;
    if (r.createdDateTime > appMap[appName].last) appMap[appName].last = r.createdDateTime;
  }

  const apps = Object.entries(appMap).map(([name, data]) => {
    const isKnown = KNOWN_APPS.has(name) || Array.from(KNOWN_APPS).some((k) => name.toLowerCase().includes(k.toLowerCase()));
    const hasRiskyOps = data.ops.has("Consent to application.") || data.ops.has("Add service principal.") || data.ops.has("Add OAuth2PermissionGrant.");
    return {
      appName: name,
      category: (hasRiskyOps ? "risky" : isKnown ? "known" : "unknown") as "known" | "unknown" | "risky",
      users: data.users.size,
      events: data.events,
      firstSeen: data.first.slice(0, 10),
      lastSeen: data.last.slice(0, 10),
      operations: Array.from(data.ops).slice(0, 10),
    };
  }).sort((a, b) => b.events - a.events);

  const unknownApps = apps.filter((a) => a.category === "unknown");
  const riskyApps = apps.filter((a) => a.category === "risky");

  const recommendations: string[] = [];
  if (riskyApps.length > 0) recommendations.push(`🔴 ${riskyApps.length} risky app(s) detected with OAuth consent grants — review immediately.`);
  if (unknownApps.length > 5) recommendations.push(`🟡 ${unknownApps.length} unknown/unrecognized apps — review for shadow IT.`);
  if (unknownApps.length === 0 && riskyApps.length === 0) recommendations.push("✅ No shadow IT detected — all apps are recognized.");

  return {
    summary: { totalApps: apps.length, unknownApps: unknownApps.length, riskyApps: riskyApps.length },
    apps,
    recommendations,
  };
}

// ============================================================
// 11. CREATIVE: DATA EXPOSURE SCANNER
// ============================================================

export function scanDataExposure(records: AuditRecord[]): {
  summary: { totalSharingEvents: number; externalShares: number; anonymousLinks: number; sensitiveFileShares: number };
  externalShares: Array<{ user: string; operation: string; target: string; timestamp: string }>;
  anonymousLinks: Array<{ user: string; file: string; timestamp: string }>;
  topSharers: Array<{ user: string; shareCount: number }>;
  riskLevel: string;
  recommendations: string[];
} {
  const externalShares: Array<{ user: string; operation: string; target: string; timestamp: string }> = [];
  const anonymousLinks: Array<{ user: string; file: string; timestamp: string }> = [];
  const sharerCounts: Record<string, number> = {};
  let sensitiveCount = 0;

  const sharingOps = records.filter((r) =>
    r.operation.includes("Sharing") || r.operation.includes("Anonymous") ||
    r.operation.includes("CompanyLink") || r.operation.includes("Invite")
  );

  for (const r of sharingOps) {
    const user = r.userPrincipalName || "Unknown";
    sharerCounts[user] = (sharerCounts[user] || 0) + 1;

    if (r.operation.includes("Anonymous")) {
      anonymousLinks.push({ user, file: r.objectId || "Unknown", timestamp: r.createdDateTime });
    }

    if (r.operation.includes("Invitation") || r.operation.includes("External")) {
      externalShares.push({ user, operation: r.operation, target: r.objectId || "Unknown", timestamp: r.createdDateTime });
    }

    const audit = (r.auditData || {}) as Record<string, unknown>;
    if (audit.SensitivityLabel || audit.SensitiveInfoDetected) sensitiveCount++;
  }

  const topSharers = Object.entries(sharerCounts)
    .map(([user, shareCount]) => ({ user, shareCount }))
    .sort((a, b) => b.shareCount - a.shareCount)
    .slice(0, 10);

  const riskLevel = anonymousLinks.length > 10 ? "critical" :
    externalShares.length > 20 ? "high" :
    sharingOps.length > 50 ? "medium" : "low";

  const recommendations: string[] = [];
  if (anonymousLinks.length > 0) recommendations.push(`🔴 ${anonymousLinks.length} anonymous sharing links created — these are accessible without authentication.`);
  if (externalShares.length > 10) recommendations.push(`🟡 ${externalShares.length} external sharing events — review sharing policies.`);
  if (sensitiveCount > 0) recommendations.push(`🔴 ${sensitiveCount} sharing events involved sensitive/labeled content.`);
  if (recommendations.length === 0) recommendations.push("✅ No significant data exposure detected.");

  return {
    summary: {
      totalSharingEvents: sharingOps.length,
      externalShares: externalShares.length,
      anonymousLinks: anonymousLinks.length,
      sensitiveFileShares: sensitiveCount,
    },
    externalShares: externalShares.slice(0, 25),
    anonymousLinks: anonymousLinks.slice(0, 25),
    topSharers,
    riskLevel,
    recommendations,
  };
}

// ============================================================
// 12. CREATIVE: COMPLIANCE HEALTH DASHBOARD
// ============================================================

export async function getComplianceHealthDashboard(): Promise<{
  secureScore: unknown;
  recentAlerts: unknown;
  recentIncidents: unknown;
  retentionLabels: unknown;
  riskDetections: unknown;
  overallHealth: string;
}> {
  const results = await Promise.allSettled([
    graphRequest("GET", "/security/secureScores?$top=1"),
    graphRequest("GET", "/security/alerts_v2?$top=10&$orderby=createdDateTime desc"),
    graphRequest("GET", "/security/incidents?$top=10&$orderby=createdDateTime desc"),
    graphRequest("GET", "/security/labels/retentionLabels?$top=10"),
    graphRequest("GET", "/identityProtection/riskDetections?$top=10&$orderby=detectedDateTime desc"),
  ]);

  const getValue = (r: PromiseSettledResult<unknown>) =>
    r.status === "fulfilled" ? r.value : { error: (r.reason as Error)?.message || "Access denied — check permissions" };

  return {
    secureScore: getValue(results[0]),
    recentAlerts: getValue(results[1]),
    recentIncidents: getValue(results[2]),
    retentionLabels: getValue(results[3]),
    riskDetections: getValue(results[4]),
    overallHealth: "Dashboard loaded — review each section for details",
  };
}

// ============================================================
// 13. SENSITIVITY LABELS (Most Requested)
// ============================================================

export async function listSensitivityLabels(): Promise<unknown> {
  // Try v1.0 first, fallback to beta
  try {
    return await graphRequest("GET", "/security/dataSecurityAndGovernance/sensitivityLabels");
  } catch {
    return await graphRequest("GET", "https://graph.microsoft.com/beta/security/informationProtection/sensitivityLabels");
  }
}

export async function getSensitivityLabel(labelId: string): Promise<unknown> {
  try {
    return await graphRequest("GET", `/security/dataSecurityAndGovernance/sensitivityLabels/${labelId}`);
  } catch {
    return await graphRequest("GET", `https://graph.microsoft.com/beta/security/informationProtection/sensitivityLabels/${labelId}`);
  }
}

export async function assignSensitivityLabelToFile(
  siteUrl: string, docLibrary: string, filePath: string, labelId: string
): Promise<unknown> {
  const site = (await graphRequest("GET", `/sites/${new URL(siteUrl).hostname}:/${new URL(siteUrl).pathname.slice(1)}`)) as { id: string };
  const drives = (await graphRequest("GET", `/sites/${site.id}/drives`)) as { value: Array<{ id: string; name: string }> };
  const drive = drives.value.find(d => d.name.toLowerCase() === docLibrary.toLowerCase());
  if (!drive) throw new Error(`Library "${docLibrary}" not found.`);
  const cleanPath = filePath.replace(/^\//, "");
  const item = (await graphRequest("GET", `/sites/${site.id}/drives/${drive.id}/items/root:/${cleanPath}`)) as { id: string };
  return await graphRequest("POST", `/sites/${site.id}/drives/${drive.id}/items/${item.id}/assignSensitivityLabel`, {
    sensitivityLabelId: labelId, assignmentMethod: "standard",
  });
}

// ============================================================
// 14. SIGN-IN LOGS (Most Requested)
// ============================================================

export async function getSignInLogs(top?: number, filter?: string): Promise<unknown> {
  let endpoint = `/auditLogs/signIns?$top=${top || 50}&$orderby=createdDateTime desc`;
  if (filter) endpoint += `&$filter=${encodeURIComponent(filter)}`;
  return await graphRequest("GET", endpoint);
}

// ============================================================
// 15. DIRECTORY AUDIT LOGS (Entra ID changes)
// ============================================================

export async function getDirectoryAuditLogs(top?: number, filter?: string): Promise<unknown> {
  let endpoint = `/auditLogs/directoryAudits?$top=${top || 50}&$orderby=activityDateTime desc`;
  if (filter) endpoint += `&$filter=${encodeURIComponent(filter)}`;
  return await graphRequest("GET", endpoint);
}

// ============================================================
// 16. SERVICE HEALTH (Most Requested)
// ============================================================

export async function getServiceHealth(): Promise<unknown> {
  return await graphRequest("GET", "/admin/serviceAnnouncement/healthOverviews");
}

export async function getServiceHealthIssues(top?: number): Promise<unknown> {
  return await graphRequest("GET", `/admin/serviceAnnouncement/issues?$top=${top || 25}&$orderby=startDateTime desc`);
}

export async function getServiceMessages(top?: number): Promise<unknown> {
  return await graphRequest("GET", `/admin/serviceAnnouncement/messages?$top=${top || 25}&$orderby=startDateTime desc`);
}

// ============================================================
// 17. CONDITIONAL ACCESS POLICIES
// ============================================================

export async function listConditionalAccessPolicies(): Promise<unknown> {
  return await graphRequest("GET", "/identity/conditionalAccess/policies");
}

export async function getConditionalAccessPolicy(policyId: string): Promise<unknown> {
  return await graphRequest("GET", `/identity/conditionalAccess/policies/${policyId}`);
}

// ============================================================
// 18. M365 USAGE REPORTS (Most Requested)
// ============================================================

export async function getM365ActiveUsers(period?: string): Promise<unknown> {
  return await graphRequest("GET", `/reports/getOffice365ActiveUserDetail(period='${period || "D7"}')`);
}

export async function getEmailActivityReport(period?: string): Promise<unknown> {
  return await graphRequest("GET", `/reports/getEmailActivityUserDetail(period='${period || "D7"}')`);
}

export async function getSharePointActivityReport(period?: string): Promise<unknown> {
  return await graphRequest("GET", `/reports/getSharePointActivityUserDetail(period='${period || "D7"}')`);
}

export async function getTeamsActivityReport(period?: string): Promise<unknown> {
  return await graphRequest("GET", `/reports/getTeamsUserActivityUserDetail(period='${period || "D7"}')`);
}

export async function getOneDriveActivityReport(period?: string): Promise<unknown> {
  return await graphRequest("GET", `/reports/getOneDriveActivityUserDetail(period='${period || "D7"}')`);
}

// ============================================================
// 19. REMOVE SENSITIVITY LABELS (Bulk)
// ============================================================

export async function removeSensitivityLabelFromFile(
  siteUrl: string, docLibrary: string, filePath: string
): Promise<unknown> {
  const url = new URL(siteUrl);
  const hostname = url.hostname;
  const sitePath = url.pathname.replace(/\/$/, "");
  let siteEndpoint: string;
  if (sitePath && sitePath !== "/" && (sitePath.includes("/sites/") || sitePath.includes("/teams/"))) {
    siteEndpoint = `/sites/${hostname}:/${sitePath.slice(1)}`;
  } else {
    siteEndpoint = `/sites/${hostname}`;
  }
  const site = (await graphRequest("GET", siteEndpoint)) as { id: string };
  const drives = (await graphRequest("GET", `/sites/${site.id}/drives`)) as { value: Array<{ id: string; name: string }> };
  const drive = drives.value.find(d => d.name.toLowerCase() === docLibrary.toLowerCase());
  if (!drive) throw new Error(`Library "${docLibrary}" not found.`);
  const cleanPath = filePath.replace(/^\//, "");
  const item = (await graphRequest("GET", `/sites/${site.id}/drives/${drive.id}/items/root:/${cleanPath}`)) as { id: string };
  // Assign empty label = remove label
  return await graphRequest("POST", `/sites/${site.id}/drives/${drive.id}/items/${item.id}/assignSensitivityLabel`, {
    sensitivityLabelId: "", assignmentMethod: "standard", justificationText: "Label removed via Purview MCP Server",
  });
}

export async function removeSiteSensitivityLabel(siteUrl: string): Promise<unknown> {
  const url = new URL(siteUrl);
  const hostname = url.hostname;
  const sitePath = url.pathname.replace(/\/$/, "");
  let siteEndpoint: string;
  if (sitePath && sitePath !== "/" && (sitePath.includes("/sites/") || sitePath.includes("/teams/"))) {
    siteEndpoint = `/sites/${hostname}:/${sitePath.slice(1)}`;
  } else {
    siteEndpoint = `/sites/${hostname}`;
  }
  const site = (await graphRequest("GET", siteEndpoint)) as { id: string };
  return await graphRequest("PATCH", `/sites/${site.id}`, { sensitivityLabelId: "" });
}

export async function bulkRemoveLabelsFromLibrary(
  siteUrl: string, docLibrary: string, folderPath?: string
): Promise<{ total: number; processed: number; succeeded: number; failed: number; errors: string[] }> {
  const url = new URL(siteUrl);
  const hostname = url.hostname;
  const sitePath = url.pathname.replace(/\/$/, "");
  let siteEndpoint: string;
  if (sitePath && sitePath !== "/" && (sitePath.includes("/sites/") || sitePath.includes("/teams/"))) {
    siteEndpoint = `/sites/${hostname}:/${sitePath.slice(1)}`;
  } else {
    siteEndpoint = `/sites/${hostname}`;
  }
  const site = (await graphRequest("GET", siteEndpoint)) as { id: string };
  const drives = (await graphRequest("GET", `/sites/${site.id}/drives`)) as { value: Array<{ id: string; name: string }> };
  const drive = drives.value.find(d => d.name.toLowerCase() === docLibrary.toLowerCase());
  if (!drive) throw new Error(`Library "${docLibrary}" not found.`);

  // Get all files recursively
  const allFiles: Array<{ id: string; name: string; path: string }> = [];
  async function listFilesRecursive(parentPath?: string) {
    let endpoint: string;
    if (parentPath) {
      endpoint = `/sites/${site.id}/drives/${drive!.id}/items/root:/${parentPath}:/children?$top=200`;
    } else {
      endpoint = `/sites/${site.id}/drives/${drive!.id}/items/root/children?$top=200`;
    }
    const result = (await graphRequest("GET", endpoint)) as { value: Array<{ id: string; name: string; file?: unknown; folder?: { childCount: number }; parentReference?: { path?: string } }> };
    for (const item of (result.value || [])) {
      if (item.file) {
        const itemPath = parentPath ? `${parentPath}/${item.name}` : item.name;
        allFiles.push({ id: item.id, name: item.name, path: itemPath });
      } else if (item.folder && item.folder.childCount > 0) {
        const subPath = parentPath ? `${parentPath}/${item.name}` : item.name;
        await listFilesRecursive(subPath);
      }
    }
  }

  await listFilesRecursive(folderPath);

  let succeeded = 0;
  let failed = 0;
  const errors: string[] = [];

  for (const file of allFiles) {
    try {
      await graphRequest("POST", `/sites/${site.id}/drives/${drive.id}/items/${file.id}/assignSensitivityLabel`, {
        sensitivityLabelId: "", assignmentMethod: "standard",
        justificationText: "Bulk label removal via Purview MCP Server",
      });
      succeeded++;
    } catch (err: unknown) {
      failed++;
      const msg = err instanceof Error ? err.message : String(err);
      if (errors.length < 20) errors.push(`${file.name}: ${msg}`);
    }
    // Rate limit: wait 200ms between calls
    await new Promise(r => setTimeout(r, 200));
  }

  return { total: allFiles.length, processed: allFiles.length, succeeded, failed, errors };
}

// ============================================================
// 20. APPLY LABELS AT SITE / LIBRARY / LIST LEVEL
// ============================================================

export async function applySensitivityLabelToSite(siteUrl: string, labelId: string): Promise<unknown> {
  const url = new URL(siteUrl);
  const hostname = url.hostname;
  const sitePath = url.pathname.replace(/\/$/, "");
  let siteEndpoint: string;
  if (sitePath && sitePath !== "/" && (sitePath.includes("/sites/") || sitePath.includes("/teams/"))) {
    siteEndpoint = `/sites/${hostname}:/${sitePath.slice(1)}`;
  } else {
    siteEndpoint = `/sites/${hostname}`;
  }
  const site = (await graphRequest("GET", siteEndpoint)) as { id: string };
  return await graphRequest("PATCH", `/sites/${site.id}`, { sensitivityLabelId: labelId });
}

export async function applyLabelToAllFilesInLibrary(
  siteUrl: string, docLibrary: string, labelId: string, folderPath?: string
): Promise<{ total: number; succeeded: number; failed: number; skipped: number; errors: string[] }> {
  const url = new URL(siteUrl);
  const hostname = url.hostname;
  const sitePath = url.pathname.replace(/\/$/, "");
  let siteEndpoint: string;
  if (sitePath && sitePath !== "/" && (sitePath.includes("/sites/") || sitePath.includes("/teams/"))) {
    siteEndpoint = `/sites/${hostname}:/${sitePath.slice(1)}`;
  } else {
    siteEndpoint = `/sites/${hostname}`;
  }
  const site = (await graphRequest("GET", siteEndpoint)) as { id: string };
  const drives = (await graphRequest("GET", `/sites/${site.id}/drives`)) as { value: Array<{ id: string; name: string }> };
  const drive = drives.value.find(d => d.name.toLowerCase() === docLibrary.toLowerCase());
  if (!drive) throw new Error(`Library "${docLibrary}" not found.`);

  const SUPPORTED_TYPES = new Set(["docx", "xlsx", "pptx", "pdf", "doc", "xls", "ppt"]);
  const allFiles: Array<{ id: string; name: string; path: string }> = [];

  async function listFilesRecursive(parentPath?: string) {
    let endpoint: string;
    if (parentPath) {
      endpoint = `/sites/${site.id}/drives/${drive!.id}/items/root:/${parentPath}:/children?$top=200`;
    } else {
      endpoint = `/sites/${site.id}/drives/${drive!.id}/items/root/children?$top=200`;
    }
    const result = (await graphRequest("GET", endpoint)) as { value: Array<{ id: string; name: string; file?: unknown; folder?: { childCount: number } }> };
    for (const item of (result.value || [])) {
      if (item.file) {
        const itemPath = parentPath ? `${parentPath}/${item.name}` : item.name;
        allFiles.push({ id: item.id, name: item.name, path: itemPath });
      } else if (item.folder && item.folder.childCount > 0) {
        const subPath = parentPath ? `${parentPath}/${item.name}` : item.name;
        await listFilesRecursive(subPath);
      }
    }
  }

  await listFilesRecursive(folderPath);

  let succeeded = 0, failed = 0, skipped = 0;
  const errors: string[] = [];

  for (const file of allFiles) {
    const ext = file.name.split(".").pop()?.toLowerCase() || "";
    if (!SUPPORTED_TYPES.has(ext)) {
      skipped++;
      continue;
    }
    try {
      await graphRequest("POST", `/sites/${site.id}/drives/${drive.id}/items/${file.id}/assignSensitivityLabel`, {
        sensitivityLabelId: labelId, assignmentMethod: "standard",
        justificationText: "Applied via Purview MCP Server",
      });
      succeeded++;
    } catch (err: unknown) {
      failed++;
      const msg = err instanceof Error ? err.message : String(err);
      if (errors.length < 20) errors.push(`${file.name}: ${msg}`);
    }
    await new Promise(r => setTimeout(r, 250));
  }

  return { total: allFiles.length, succeeded, failed, skipped, errors };
}

export async function setDefaultLibraryLabel(
  siteUrl: string, docLibrary: string, labelId: string
): Promise<unknown> {
  const url = new URL(siteUrl);
  const hostname = url.hostname;
  const sitePath = url.pathname.replace(/\/$/, "");
  let siteEndpoint: string;
  if (sitePath && sitePath !== "/" && (sitePath.includes("/sites/") || sitePath.includes("/teams/"))) {
    siteEndpoint = `/sites/${hostname}:/${sitePath.slice(1)}`;
  } else {
    siteEndpoint = `/sites/${hostname}`;
  }
  const site = (await graphRequest("GET", siteEndpoint)) as { id: string };
  const drives = (await graphRequest("GET", `/sites/${site.id}/drives`)) as { value: Array<{ id: string; name: string }> };
  const drive = drives.value.find(d => d.name.toLowerCase() === docLibrary.toLowerCase());
  if (!drive) throw new Error(`Library "${docLibrary}" not found.`);
  // Set default label via drive update
  return await graphRequest("PATCH", `/sites/${site.id}/drives/${drive.id}`, {
    list: { contentTypesEnabled: true },
    sensitivityLabelId: labelId,
  });
}

export async function extractFileLabels(
  siteUrl: string, docLibrary: string, folderPath?: string
): Promise<Array<{ name: string; path: string; labelId: string | null; labelName: string | null }>> {
  const url = new URL(siteUrl);
  const hostname = url.hostname;
  const sitePath = url.pathname.replace(/\/$/, "");
  let siteEndpoint: string;
  if (sitePath && sitePath !== "/" && (sitePath.includes("/sites/") || sitePath.includes("/teams/"))) {
    siteEndpoint = `/sites/${hostname}:/${sitePath.slice(1)}`;
  } else {
    siteEndpoint = `/sites/${hostname}`;
  }
  const site = (await graphRequest("GET", siteEndpoint)) as { id: string };
  const drives = (await graphRequest("GET", `/sites/${site.id}/drives`)) as { value: Array<{ id: string; name: string }> };
  const drive = drives.value.find(d => d.name.toLowerCase() === docLibrary.toLowerCase());
  if (!drive) throw new Error(`Library "${docLibrary}" not found.`);

  const SUPPORTED_TYPES = new Set(["docx", "xlsx", "pptx", "pdf"]);
  const results: Array<{ name: string; path: string; labelId: string | null; labelName: string | null }> = [];

  async function scanRecursive(parentPath?: string) {
    let endpoint: string;
    if (parentPath) {
      endpoint = `/sites/${site.id}/drives/${drive!.id}/items/root:/${parentPath}:/children?$top=200&$select=id,name,file,folder`;
    } else {
      endpoint = `/sites/${site.id}/drives/${drive!.id}/items/root/children?$top=200&$select=id,name,file,folder`;
    }
    const result = (await graphRequest("GET", endpoint)) as { value: Array<{ id: string; name: string; file?: unknown; folder?: { childCount: number } }> };
    for (const item of (result.value || [])) {
      if (item.file) {
        const ext = item.name.split(".").pop()?.toLowerCase() || "";
        const itemPath = parentPath ? `${parentPath}/${item.name}` : item.name;
        if (SUPPORTED_TYPES.has(ext)) {
          try {
            const labelInfo = (await graphRequest("POST", `/sites/${site.id}/drives/${drive!.id}/items/${item.id}/extractSensitivityLabels`, {})) as { labels?: Array<{ sensitivityLabelId: string; name?: string }> };
            const label = labelInfo.labels?.[0];
            results.push({ name: item.name, path: itemPath, labelId: label?.sensitivityLabelId || null, labelName: label?.name || null });
          } catch {
            results.push({ name: item.name, path: itemPath, labelId: null, labelName: null });
          }
        } else {
          results.push({ name: item.name, path: itemPath, labelId: null, labelName: "unsupported type" });
        }
        await new Promise(r => setTimeout(r, 100));
      } else if (item.folder && item.folder.childCount > 0) {
        const subPath = parentPath ? `${parentPath}/${item.name}` : item.name;
        await scanRecursive(subPath);
      }
    }
  }

  await scanRecursive(folderPath);
  return results;
}

// ============================================================
// 21. WORKLOAD AUDIT PRESETS — Search any M365 workload
// ============================================================

export const WORKLOAD_AUDIT_PRESETS: Record<string, {
  name: string; description: string;
  operationFilters?: string[]; serviceFilters?: string[]; recordTypeFilters?: string[];
}> = {
  // --- Copilot ---
  copilot_all: { name: "All Copilot Interactions", description: "Every Copilot interaction across Teams, Word, Excel, Outlook, M365 Chat", operationFilters: ["CopilotInteraction"] },
  copilot_agents: { name: "Copilot Studio Agent Activity", description: "Agent creation, update, publish, share, delete events", serviceFilters: ["CopilotStudio"], operationFilters: ["BotCreateOperation","BotUpdateOperation","BotPublish","BotShare","BotDeleteOperation"] },

  // --- Exchange / Email ---
  exchange_all: { name: "All Exchange Activity", description: "Email send/receive, mailbox access, rules, delegation", serviceFilters: ["Exchange"] },
  exchange_inbox_rules: { name: "Inbox Rule Changes", description: "New/modified inbox rules (potential BEC indicator)", operationFilters: ["New-InboxRule","Set-InboxRule","UpdateInboxRules","Remove-InboxRule"] },
  exchange_forwarding: { name: "Email Forwarding", description: "Auto-forwarding setup (data exfiltration risk)", operationFilters: ["Set-Mailbox","Set-TransportRule","New-TransportRule"] },
  exchange_delegation: { name: "Mailbox Delegation", description: "Delegate access changes", operationFilters: ["Add-MailboxPermission","Remove-MailboxPermission","Add-RecipientPermission"] },
  exchange_admin: { name: "Exchange Admin Actions", description: "Admin changes to Exchange config", operationFilters: ["Set-OrganizationConfig","Set-TransportConfig","New-TransportRule","Set-HostedContentFilterPolicy"] },

  // --- SharePoint ---
  sharepoint_all: { name: "All SharePoint Activity", description: "File access, sharing, site admin, page edits", serviceFilters: ["SharePoint"] },
  sharepoint_sharing: { name: "SharePoint Sharing", description: "External sharing, anonymous links, permission changes", operationFilters: ["SharingSet","SharingInvitationCreated","AnonymousLinkCreated","CompanyLinkCreated","SharingPolicyChanged","AddedToSecureLink"] },
  sharepoint_file_access: { name: "SharePoint File Access", description: "File downloads, views, modifications", operationFilters: ["FileAccessed","FileDownloaded","FileModified","FileUploaded","FileMoved","FileRenamed","FileDeleted","FileRecycled"] },
  sharepoint_admin: { name: "SharePoint Admin", description: "Site creation, policy changes, admin actions", operationFilters: ["SiteCollectionCreated","SiteCollectionAdminAdded","SiteCollectionAdminRemoved","HubSiteRegistered"] },
  sharepoint_dlp: { name: "SharePoint DLP Events", description: "Data loss prevention policy matches in SharePoint", operationFilters: ["DLPRuleMatch","DLPRuleUndo"] },

  // --- OneDrive ---
  onedrive_all: { name: "All OneDrive Activity", description: "File sync, sharing, access events", serviceFilters: ["OneDrive"] },
  onedrive_sharing: { name: "OneDrive Sharing", description: "External file shares from OneDrive", operationFilters: ["SharingSet","AnonymousLinkCreated","SharingInvitationCreated","CompanyLinkCreated"] },

  // --- Teams ---
  teams_all: { name: "All Teams Activity", description: "Messages, meetings, channel management, app installs", serviceFilters: ["MicrosoftTeams"] },
  teams_meetings: { name: "Teams Meetings", description: "Meeting creation, join/leave, recording", operationFilters: ["MeetingParticipantDetail","MeetingDetail"] },
  teams_messaging: { name: "Teams Messaging", description: "Message send/edit/delete in chats and channels", operationFilters: ["MessageSent","MessageUpdated","MessageDeleted","ChatCreated"] },
  teams_apps: { name: "Teams App Installs", description: "App installations and bot additions", operationFilters: ["AppInstalled","BotAddedToTeam","ConnectorAdded","TabAdded"] },
  teams_guest: { name: "Teams Guest Activity", description: "Guest user actions in Teams", operationFilters: ["MemberAdded","MemberRemoved","MemberRoleChanged"] },

  // --- Azure AD / Entra ID ---
  entra_all: { name: "All Entra ID Activity", description: "User, group, role, app, policy changes", serviceFilters: ["AzureActiveDirectory"] },
  entra_user_admin: { name: "Entra User Admin", description: "User create/delete/update, password changes", operationFilters: ["Add user.","Delete user.","Update user.","Reset user password.","Change user password."] },
  entra_group_changes: { name: "Entra Group Changes", description: "Group membership and ownership changes", operationFilters: ["Add member to group.","Remove member from group.","Add owner to group.","Add group.","Delete group."] },
  entra_role_changes: { name: "Entra Role Changes", description: "Admin role assignments (privilege escalation)", operationFilters: ["Add member to role.","Remove member from role."] },
  entra_app_consent: { name: "App Consent & Registration", description: "OAuth app consent grants and new app registrations", operationFilters: ["Consent to application.","Add application.","Add service principal.","Add app role assignment to service principal.","Add OAuth2PermissionGrant."] },
  entra_conditional_access: { name: "Conditional Access Changes", description: "CA policy create/update/delete", operationFilters: ["Add policy.","Update policy.","Delete policy."] },

  // --- Power Platform ---
  powerplatform_all: { name: "All Power Platform Activity", description: "Power Apps, Power Automate, Copilot Studio", serviceFilters: ["PowerApps","MicrosoftFlow","PowerPlatformAdminCenter"] },
  powerapps_activity: { name: "Power Apps Activity", description: "App launches, edits, shares, deletes", serviceFilters: ["PowerApps"] },
  powerautomate_activity: { name: "Power Automate Activity", description: "Flow runs, edits, shares, failures", serviceFilters: ["MicrosoftFlow"] },

  // --- Compliance ---
  compliance_all: { name: "All Compliance Activity", description: "DLP, retention, eDiscovery, sensitivity labels", serviceFilters: ["SecurityComplianceCenter","MicrosoftPurview"] },
  dlp_all: { name: "DLP Policy Matches", description: "All DLP rule matches across workloads", operationFilters: ["DLPRuleMatch","DLPRuleUndo"] },
  sensitivity_label_changes: { name: "Sensitivity Label Activity", description: "Label applied, changed, removed from files", operationFilters: ["SensitivityLabelApplied","SensitivityLabelUpdated","SensitivityLabelRemoved","FileSensitivityLabelApplied","FileSensitivityLabelChanged","FileSensitivityLabelRemoved"] },
  retention_activity: { name: "Retention Activity", description: "Retention label and policy events", operationFilters: ["TagApplied","TagRemoved","TagChanged"] },
  ediscovery_activity: { name: "eDiscovery Activity", description: "Case management, search, export events", operationFilters: ["CaseAdded","CaseUpdated","SearchCreated","SearchStarted","ExportCreated","ExportDownloaded"] },

  // --- Security ---
  security_alerts: { name: "Security Alert Activity", description: "Defender, DLP, Insider Risk alert events", serviceFilters: ["SecurityComplianceAlerts","ThreatIntelligence"] },
  sign_in_failures: { name: "Failed Sign-ins", description: "All failed authentication attempts", operationFilters: ["UserLoginFailed"] },

  // --- General ---
  all_admin: { name: "All Admin Activity", description: "Every admin operation across all workloads", operationFilters: ["Add user.","Delete user.","Add member to role.","Remove member from role.","Set-Mailbox","New-TransportRule","SiteCollectionCreated","Add policy.","Update policy.","BotCreateOperation","BotPublish"] },
  all_activity: { name: "All Activity (No Filter)", description: "Everything — all workloads, all operations. Use with short date ranges!", operationFilters: [] },
};

// ============================================================
// 22. COPILOT AGENT SECURITY MONITOR
// ============================================================

// (AuditRecord already imported at top of file)

export function analyzeCopilotAgentSecurity(records: AuditRecord[]): {
  summary: { totalEvents: number; agentEvents: number; riskScore: number; riskLevel: string };
  agents: Array<{
    agentName: string; agentId: string; events: number;
    operations: string[]; users: string[];
    risks: string[];
  }>;
  securityFindings: Array<{ severity: string; finding: string; detail: string }>;
  recommendations: string[];
} {
  const agentMap: Record<string, { name: string; id: string; events: number; ops: Set<string>; users: Set<string>; risks: string[] }> = {};
  const findings: Array<{ severity: string; finding: string; detail: string }> = [];

  const RISKY_OPS = new Set([
    "BotUpdateOperation-BotAuthUpdate", "BotShare", "BotDeleteOperation",
    "BotUpdateOperation-BotAppInsightsUpdate", "BotPublish",
  ]);

  const agentRecords = records.filter(r =>
    r.service === "CopilotStudio" || r.operation.startsWith("Bot") ||
    r.operation === "CopilotInteraction" ||
    (r.auditData as Record<string, unknown>)?.CopilotEventData
  );

  for (const r of agentRecords) {
    const audit = (r.auditData || {}) as Record<string, unknown>;
    const copilotData = audit.CopilotEventData as Record<string, unknown> | undefined;
    const agentId = (audit.ResourceId as string) || (copilotData?.AgentId as string) || "unknown";
    const agentName = (audit.ResourceName as string) || (copilotData?.AgentName as string) || (copilotData?.AppHost as string) || "Unknown Agent";

    if (!agentMap[agentId]) {
      agentMap[agentId] = { name: agentName, id: agentId, events: 0, ops: new Set(), users: new Set(), risks: [] };
    }
    agentMap[agentId].events++;
    agentMap[agentId].ops.add(r.operation);
    agentMap[agentId].users.add(r.userPrincipalName || "unknown");

    // Check for risky operations
    if (RISKY_OPS.has(r.operation)) {
      agentMap[agentId].risks.push(r.operation);
    }

    // Auth setting changes
    if (r.operation.includes("AuthUpdate")) {
      findings.push({
        severity: "HIGH",
        finding: `Agent auth settings modified: ${agentName}`,
        detail: `User: ${r.userPrincipalName} at ${r.createdDateTime}`,
      });
    }

    // Agent shared externally
    if (r.operation === "BotShare") {
      findings.push({
        severity: "MEDIUM",
        finding: `Agent shared: ${agentName}`,
        detail: `Shared by: ${r.userPrincipalName} at ${r.createdDateTime}`,
      });
    }

    // Agent deleted
    if (r.operation === "BotDeleteOperation") {
      findings.push({
        severity: "MEDIUM",
        finding: `Agent deleted: ${agentName}`,
        detail: `Deleted by: ${r.userPrincipalName} at ${r.createdDateTime}`,
      });
    }

    // App Insights logging disabled
    if (r.operation.includes("AppInsightsUpdate")) {
      findings.push({
        severity: "HIGH",
        finding: `Agent monitoring settings changed: ${agentName}`,
        detail: `Potential logging disabled by: ${r.userPrincipalName}`,
      });
    }
  }

  // Check for agents with no auth
  for (const [, agent] of Object.entries(agentMap)) {
    if (agent.risks.length > 0) {
      findings.push({
        severity: "HIGH",
        finding: `Agent "${agent.name}" has ${agent.risks.length} risky operations`,
        detail: `Operations: ${agent.risks.join(", ")}`,
      });
    }
  }

  // Copilot accessing sensitive data
  const sensitiveAccess = agentRecords.filter(r => {
    const audit = (r.auditData || {}) as Record<string, unknown>;
    const copilotData = audit.CopilotEventData as Record<string, unknown> | undefined;
    const resources = copilotData?.AccessedResources as Array<{ SensitivityLabelId?: string }> | undefined;
    return resources?.some(res => res.SensitivityLabelId);
  });

  if (sensitiveAccess.length > 0) {
    findings.push({
      severity: "HIGH",
      finding: `${sensitiveAccess.length} Copilot interactions accessed labeled/sensitive content`,
      detail: `Users: ${[...new Set(sensitiveAccess.map(r => r.userPrincipalName))].join(", ")}`,
    });
  }

  const agents = Object.values(agentMap).map(a => ({
    agentName: a.name, agentId: a.id, events: a.events,
    operations: Array.from(a.ops), users: Array.from(a.users), risks: a.risks,
  })).sort((a, b) => b.events - a.events);

  const highFindings = findings.filter(f => f.severity === "HIGH").length;
  const riskScore = Math.min(100, highFindings * 25 + findings.length * 5);
  const riskLevel = riskScore >= 75 ? "critical" : riskScore >= 50 ? "high" : riskScore >= 25 ? "medium" : "low";

  const recommendations: string[] = [];
  if (highFindings > 0) recommendations.push(`🔴 ${highFindings} high-severity findings — review agent auth and sharing settings immediately.`);
  if (sensitiveAccess.length > 0) recommendations.push(`🔴 Copilot accessed ${sensitiveAccess.length} sensitive/labeled files — review DLP policies for Copilot.`);
  if (agents.length > 10) recommendations.push(`🟡 ${agents.length} active agents detected — consider agent inventory review.`);
  const sharedAgents = agents.filter(a => a.operations.includes("BotShare"));
  if (sharedAgents.length > 0) recommendations.push(`🟡 ${sharedAgents.length} agents were shared — verify sharing permissions are appropriate.`);
  if (findings.length === 0) recommendations.push("✅ No security concerns detected in agent activity.");

  return {
    summary: { totalEvents: records.length, agentEvents: agentRecords.length, riskScore, riskLevel },
    agents, securityFindings: findings, recommendations,
  };
}

export function generateCopilotSecurityReport(records: AuditRecord[]): {
  agentInventory: Array<{ name: string; users: number; interactions: number; lastSeen: string; apps: string[] }>;
  dataAccessSummary: { totalInteractions: number; sensitiveAccess: number; webSearchUsed: number; filesAccessed: number };
  userRiskProfiles: Array<{ user: string; interactions: number; sensitiveAccess: number; uniqueAgents: number; riskLevel: string }>;
  oversharing: Array<{ user: string; sharedWith: string; resource: string; timestamp: string }>;
} {
  const agentMap: Record<string, { users: Set<string>; interactions: number; lastSeen: string; apps: Set<string> }> = {};
  let sensitiveCount = 0, webSearchCount = 0, filesCount = 0;
  const userMap: Record<string, { interactions: number; sensitive: number; agents: Set<string> }> = {};
  const oversharingEvents: Array<{ user: string; sharedWith: string; resource: string; timestamp: string }> = [];

  for (const r of records) {
    if (r.operation !== "CopilotInteraction") continue;
    const audit = (r.auditData || {}) as Record<string, unknown>;
    const copilotData = audit.CopilotEventData as Record<string, unknown> | undefined;
    if (!copilotData) continue;

    const appHost = (copilotData.AppHost as string) || "Unknown";
    const user = r.userPrincipalName || "unknown";

    if (!agentMap[appHost]) agentMap[appHost] = { users: new Set(), interactions: 0, lastSeen: r.createdDateTime, apps: new Set() };
    agentMap[appHost].users.add(user);
    agentMap[appHost].interactions++;
    agentMap[appHost].apps.add(appHost);
    if (r.createdDateTime > agentMap[appHost].lastSeen) agentMap[appHost].lastSeen = r.createdDateTime;

    if (!userMap[user]) userMap[user] = { interactions: 0, sensitive: 0, agents: new Set() };
    userMap[user].interactions++;
    userMap[user].agents.add(appHost);

    // Check sensitive access
    const resources = copilotData.AccessedResources as Array<{ SensitivityLabelId?: string }> | undefined;
    if (resources?.some(res => res.SensitivityLabelId)) {
      sensitiveCount++;
      userMap[user].sensitive++;
    }
    if (resources && resources.length > 0) filesCount += resources.length;

    // Check web search
    const plugins = copilotData.AISystemPlugin as Array<{ Id?: string }> | undefined;
    if (plugins?.some(p => p.Id === "BingWebSearch")) webSearchCount++;
  }

  const agentInventory = Object.entries(agentMap).map(([name, data]) => ({
    name, users: data.users.size, interactions: data.interactions,
    lastSeen: data.lastSeen.slice(0, 10), apps: Array.from(data.apps),
  })).sort((a, b) => b.interactions - a.interactions);

  const userRiskProfiles = Object.entries(userMap).map(([user, data]) => ({
    user, interactions: data.interactions, sensitiveAccess: data.sensitive,
    uniqueAgents: data.agents.size,
    riskLevel: data.sensitive > 10 ? "high" : data.sensitive > 0 ? "medium" : "low",
  })).sort((a, b) => b.sensitiveAccess - a.sensitiveAccess);

  return {
    agentInventory,
    dataAccessSummary: {
      totalInteractions: records.filter(r => r.operation === "CopilotInteraction").length,
      sensitiveAccess: sensitiveCount, webSearchUsed: webSearchCount, filesAccessed: filesCount,
    },
    userRiskProfiles,
    oversharing: oversharingEvents.slice(0, 25),
  };
}
