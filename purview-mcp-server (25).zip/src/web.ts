#!/usr/bin/env node
// ============================================================
// Purview MCP Server — Azure Web Entry Point
// MANUAL JSON-RPC handling — bypasses SDK transport completely
// No session issues, no _initialized flag, no transport conflicts
// ============================================================

import express from "express";
import { server, initPurviewMCP } from "./index.js";

const PORT = parseInt(process.env.PORT || process.env.WEBSITES_PORT || "8000", 10);
const app = express();
app.use(express.json({ limit: "10mb" }));

// CORS for Copilot Studio
app.use((_req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, Accept, Mcp-Session-Id");
  res.setHeader("Access-Control-Expose-Headers", "Mcp-Session-Id");
  if (_req.method === "OPTIONS") { res.status(204).end(); return; }
  next();
});

// ============================================================
// Get tool list and call handler from the registered server
// ============================================================
let cachedToolList: unknown = null;

async function getToolList(): Promise<unknown> {
  if (cachedToolList) return cachedToolList;
  try {
    // Access the registered ListTools handler
    const handler = (server as any)._requestHandlers?.get("tools/list");
    if (handler) {
      const result = await handler({ method: "tools/list", params: {} });
      cachedToolList = result;
      return result;
    }
  } catch (err) {
    console.error("[MCP] Error getting tool list:", err);
  }
  return { tools: [] };
}

async function callTool(name: string, args: Record<string, unknown>): Promise<unknown> {
  try {
    const handler = (server as any)._requestHandlers?.get("tools/call");
    if (handler) {
      return await handler({ method: "tools/call", params: { name, arguments: args } });
    }
  } catch (err) {
    console.error(`[MCP] Error calling tool ${name}:`, err);
    return { content: [{ type: "text", text: `Error: ${err instanceof Error ? err.message : String(err)}` }], isError: true };
  }
  return { content: [{ type: "text", text: "Tool handler not found" }], isError: true };
}

// ============================================================
// MCP JSON-RPC Handler — manual protocol implementation
// ============================================================
async function handleMcpRequest(body: unknown): Promise<unknown> {
  // Handle batch requests (array of messages)
  if (Array.isArray(body)) {
    const results = [];
    for (const msg of body) {
      const result = await handleSingleMessage(msg);
      if (result !== null) results.push(result);
    }
    return results.length > 0 ? results : undefined;
  }
  return handleSingleMessage(body);
}

async function handleSingleMessage(msg: any): Promise<unknown> {
  const { method, id, params } = msg || {};

  console.error(`[MCP] ${method} (id: ${id || "notification"})`);

  switch (method) {
    // ---- Initialize ----
    case "initialize": {
      return {
        jsonrpc: "2.0",
        id,
        result: {
          protocolVersion: params?.protocolVersion || "2025-03-26",
          capabilities: {
            tools: { listChanged: false },
          },
          serverInfo: {
            name: "purview-mcp-server",
            version: "6.0.0",
          },
        },
      };
    }

    // ---- Initialized notification (no response needed) ----
    case "notifications/initialized": {
      return null; // notifications don't get responses
    }

    // ---- List tools ----
    case "tools/list": {
      const toolResult = await getToolList();
      return {
        jsonrpc: "2.0",
        id,
        result: toolResult,
      };
    }

    // ---- Call tool ----
    case "tools/call": {
      const toolName = params?.name;
      const toolArgs = params?.arguments || {};
      const result = await callTool(toolName, toolArgs);
      return {
        jsonrpc: "2.0",
        id,
        result,
      };
    }

    // ---- Ping ----
    case "ping": {
      return {
        jsonrpc: "2.0",
        id,
        result: {},
      };
    }

    // ---- List resources (we have none) ----
    case "resources/list": {
      return {
        jsonrpc: "2.0",
        id,
        result: { resources: [] },
      };
    }

    // ---- List prompts (we have none) ----
    case "prompts/list": {
      return {
        jsonrpc: "2.0",
        id,
        result: { prompts: [] },
      };
    }

    // ---- Cancellation notification ----
    case "notifications/cancelled": {
      return null;
    }

    // ---- Unknown method ----
    default: {
      if (id !== undefined) {
        return {
          jsonrpc: "2.0",
          id,
          error: { code: -32601, message: `Method not found: ${method}` },
        };
      }
      return null; // unknown notification
    }
  }
}

// ============================================================
// Routes
// ============================================================

// POST /mcp — MCP JSON-RPC endpoint
app.post("/mcp", async (req, res) => {
  try {
    const result = await handleMcpRequest(req.body);
    if (result === undefined || result === null) {
      // Notification — no response body, just 202 Accepted
      res.status(202).end();
    } else {
      res.json(result);
    }
  } catch (err) {
    console.error("[MCP] Error:", err);
    res.status(500).json({
      jsonrpc: "2.0",
      error: { code: -32603, message: String(err) },
      id: null,
    });
  }
});

// POST /mcp/mcp — Copilot Studio alias
app.post("/mcp/mcp", async (req, res) => {
  try {
    const result = await handleMcpRequest(req.body);
    if (result === undefined || result === null) {
      res.status(202).end();
    } else {
      res.json(result);
    }
  } catch (err) {
    console.error("[MCP] Error:", err);
    res.status(500).json({
      jsonrpc: "2.0",
      error: { code: -32603, message: String(err) },
      id: null,
    });
  }
});

// GET /mcp — Copilot Studio may probe with GET
app.get("/mcp", (_req, res) => {
  res.json({
    jsonrpc: "2.0",
    error: { code: -32000, message: "Use POST for MCP requests" },
    id: null,
  });
});

// Health
app.get("/health", (_req, res) => {
  res.json({
    status: "healthy",
    server: "purview-mcp-server",
    version: "6.0.0",
    tools: 106,
    transport: "manual-jsonrpc",
    uptime: Math.round(process.uptime()),
    memory: Math.round(process.memoryUsage().heapUsed / 1024 / 1024) + "MB",
    timestamp: new Date().toISOString(),
  });
});

// Landing page
app.get("/", (_req, res) => {
  res.send(`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Purview MCP</title>
<style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:system-ui;background:#0c0f1a;color:#e8ecf4;min-height:100vh;display:flex;align-items:center;justify-content:center;flex-direction:column;padding:40px}
h1{font-size:36px;font-weight:800;background:linear-gradient(135deg,#fff,#8b5cf6,#22d3ee);-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:8px}
p{color:#94a3c0;font-size:14px;margin-bottom:20px}.k{display:flex;gap:16px;flex-wrap:wrap;justify-content:center;margin-bottom:20px}
.ki{background:#1e2540;border:1px solid #2a3460;border-radius:10px;padding:12px 20px;text-align:center}
.ki .v{font-size:28px;font-weight:800;color:#8b5cf6}.ki .l{font-size:10px;color:#6b7da0;text-transform:uppercase}
.u{font-family:monospace;background:#161b22;border:1px solid #2a3460;border-radius:6px;padding:8px 16px;color:#22d3ee;font-size:13px}
a{color:#22d3ee}</style></head><body>
<div style="background:rgba(52,211,153,.15);border:1px solid rgba(52,211,153,.3);color:#34d399;padding:5px 16px;border-radius:50px;font-size:12px;font-weight:700;margin-bottom:20px">● ONLINE</div>
<h1>Microsoft Purview MCP Server</h1>
<p>106 tools — Audit · SharePoint · Copilot · Threat Hunting · Labels · Security · Reports</p>
<div class="k"><div class="ki"><div class="v">106</div><div class="l">Tools</div></div><div class="ki"><div class="v" style="color:#34d399">12</div><div class="l">Modules</div></div></div>
<div class="u">MCP: /mcp</div>
<p style="margin-top:16px"><a href="/health">/health</a></p>
</body></html>`);
});

// ============================================================
// Start
// ============================================================
async function main() {
  console.log("[Purview MCP] Azure Web — Manual JSON-RPC — 106 Tools");

  // Start Express FIRST
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Web] Port ${PORT}`);
    console.log(`[Web] MCP: http://0.0.0.0:${PORT}/mcp`);
    if (process.env.WEBSITE_HOSTNAME) {
      console.log(`[Web] Azure: https://${process.env.WEBSITE_HOSTNAME}/mcp`);
    }
  });

  // Init auth (non-fatal)
  try {
    initPurviewMCP();
    console.log("[Web] Auth OK");
  } catch (err) {
    console.error("[Web] Auth failed:", err);
  }

  // Pre-cache tool list
  setTimeout(async () => {
    try {
      await getToolList();
      const tools = cachedToolList as any;
      console.log(`[Web] Tool cache: ${tools?.tools?.length || 0} tools`);
    } catch {}
  }, 2000);

  // Keepalive
  if (process.env.WEBSITE_HOSTNAME) {
    setInterval(async () => {
      try { await fetch(`https://${process.env.WEBSITE_HOSTNAME}/health`); } catch {}
    }, 240000);
  }
}

main().catch(err => console.error("[Web]", err));
