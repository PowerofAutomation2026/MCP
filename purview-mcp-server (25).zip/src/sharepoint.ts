// ============================================================
// Microsoft Purview MCP Server - SharePoint Module
// Upload audit exports to SharePoint document libraries
// Uses Microsoft Graph API (NOT SharePoint REST API)
// ============================================================

import { graphRequest, graphUpload } from "./auth.js";
import { SharePointSite, SharePointDrive, SharePointDriveItem } from "./types.js";
import * as fs from "fs";
import * as path from "path";

// --- Resolve SharePoint site ID from URL ---
export async function getSiteByUrl(siteUrl: string): Promise<SharePointSite> {
  // Extract hostname and site path from URL
  // e.g., https://contoso.sharepoint.com/sites/MySite
  const url = new URL(siteUrl);
  const hostname = url.hostname;
  const sitePath = url.pathname.replace(/\/$/, "");

  let endpoint: string;
  if (sitePath && sitePath !== "/" && sitePath.includes("/sites/")) {
    // Site with path: /sites/{siteName}
    const relativePath = sitePath.startsWith("/") ? sitePath.slice(1) : sitePath;
    endpoint = `/sites/${hostname}:/${relativePath}`;
  } else if (sitePath && sitePath !== "/" && sitePath.includes("/teams/")) {
    const relativePath = sitePath.startsWith("/") ? sitePath.slice(1) : sitePath;
    endpoint = `/sites/${hostname}:/${relativePath}`;
  } else {
    // Root site
    endpoint = `/sites/${hostname}`;
  }

  const result = await graphRequest("GET", endpoint);
  return result as SharePointSite;
}

// --- Get document libraries for a site ---
export async function getSiteDrives(siteId: string): Promise<SharePointDrive[]> {
  const result = (await graphRequest("GET", `/sites/${siteId}/drives`)) as {
    value: SharePointDrive[];
  };
  return result.value || [];
}

// --- Get a specific drive by name ---
export async function getDriveByName(
  siteId: string,
  driveName: string
): Promise<SharePointDrive | null> {
  const drives = await getSiteDrives(siteId);
  return (
    drives.find(
      (d) =>
        d.name.toLowerCase() === driveName.toLowerCase() ||
        d.name.toLowerCase().replace(/\s/g, "") ===
          driveName.toLowerCase().replace(/\s/g, "")
    ) || null
  );
}

// --- Upload file to SharePoint document library ---
export async function uploadFileToSharePoint(
  siteUrl: string,
  docLibraryName: string,
  localFilePath: string,
  targetFolder?: string
): Promise<SharePointDriveItem> {
  // 1. Resolve site
  const site = await getSiteByUrl(siteUrl);

  // 2. Find document library
  const drive = await getDriveByName(site.id, docLibraryName);
  if (!drive) {
    const drives = await getSiteDrives(site.id);
    const driveNames = drives.map((d) => d.name).join(", ");
    throw new Error(
      `Document library "${docLibraryName}" not found. Available libraries: ${driveNames}`
    );
  }

  // 3. Read file content
  const fileContent = fs.readFileSync(localFilePath);
  const fileName = path.basename(localFilePath);

  // 4. Build upload path
  let uploadPath: string;
  if (targetFolder) {
    const cleanFolder = targetFolder.replace(/^\/|\/$/g, "");
    uploadPath = `/sites/${site.id}/drives/${drive.id}/items/root:/${cleanFolder}/${fileName}:/content`;
  } else {
    uploadPath = `/sites/${site.id}/drives/${drive.id}/items/root:/${fileName}:/content`;
  }

  // 5. Determine content type
  const ext = path.extname(localFilePath).toLowerCase();
  const contentTypes: Record<string, string> = {
    ".csv": "text/csv",
    ".json": "application/json",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".pdf": "application/pdf",
    ".txt": "text/plain",
  };
  const contentType = contentTypes[ext] || "application/octet-stream";

  // 6. Upload (simple upload for files < 4MB, else large file upload session)
  if (fileContent.length < 4 * 1024 * 1024) {
    // Simple upload
    const result = await graphUpload(uploadPath, fileContent, contentType);
    return result as SharePointDriveItem;
  } else {
    // Large file upload session
    return await uploadLargeFile(site.id, drive.id, fileName, fileContent, targetFolder);
  }
}

// --- Large file upload (> 4MB) using upload session ---
async function uploadLargeFile(
  siteId: string,
  driveId: string,
  fileName: string,
  content: Buffer,
  folder?: string
): Promise<SharePointDriveItem> {
  // Create upload session
  let itemPath: string;
  if (folder) {
    const cleanFolder = folder.replace(/^\/|\/$/g, "");
    itemPath = `/sites/${siteId}/drives/${driveId}/items/root:/${cleanFolder}/${fileName}:/createUploadSession`;
  } else {
    itemPath = `/sites/${siteId}/drives/${driveId}/items/root:/${fileName}:/createUploadSession`;
  }

  const session = (await graphRequest("POST", itemPath, {
    item: {
      "@microsoft.graph.conflictBehavior": "rename",
      name: fileName,
    },
  })) as { uploadUrl: string };

  // Upload in 5MB chunks
  const chunkSize = 5 * 1024 * 1024;
  const totalSize = content.length;
  let offset = 0;
  let result: unknown;

  while (offset < totalSize) {
    const end = Math.min(offset + chunkSize, totalSize);
    const chunk = new Uint8Array(content.subarray(offset, end));

    const response = await fetch(session.uploadUrl, {
      method: "PUT",
      headers: {
        "Content-Length": chunk.byteLength.toString(),
        "Content-Range": `bytes ${offset}-${end - 1}/${totalSize}`,
      },
      body: chunk,
    });

    result = await response.json();
    offset = end;
  }

  return result as SharePointDriveItem;
}

// --- List files in a SharePoint folder ---
export async function listSharePointFiles(
  siteUrl: string,
  docLibraryName: string,
  folderPath?: string
): Promise<SharePointDriveItem[]> {
  const site = await getSiteByUrl(siteUrl);
  const drive = await getDriveByName(site.id, docLibraryName);

  if (!drive) {
    throw new Error(`Document library "${docLibraryName}" not found.`);
  }

  let endpoint: string;
  if (folderPath) {
    const cleanPath = folderPath.replace(/^\/|\/$/g, "");
    endpoint = `/sites/${site.id}/drives/${drive.id}/items/root:/${cleanPath}:/children`;
  } else {
    endpoint = `/sites/${site.id}/drives/${drive.id}/items/root/children`;
  }

  const result = (await graphRequest("GET", endpoint)) as {
    value: SharePointDriveItem[];
  };
  return result.value || [];
}

// --- Create folder in SharePoint ---
export async function createSharePointFolder(
  siteUrl: string,
  docLibraryName: string,
  folderName: string,
  parentFolder?: string
): Promise<SharePointDriveItem> {
  const site = await getSiteByUrl(siteUrl);
  const drive = await getDriveByName(site.id, docLibraryName);

  if (!drive) {
    throw new Error(`Document library "${docLibraryName}" not found.`);
  }

  let endpoint: string;
  if (parentFolder) {
    const cleanParent = parentFolder.replace(/^\/|\/$/g, "");
    endpoint = `/sites/${site.id}/drives/${drive.id}/items/root:/${cleanParent}:/children`;
  } else {
    endpoint = `/sites/${site.id}/drives/${drive.id}/items/root/children`;
  }

  const body = {
    name: folderName,
    folder: {},
    "@microsoft.graph.conflictBehavior": "fail",
  };

  const result = await graphRequest("POST", endpoint, body);
  return result as SharePointDriveItem;
}

// --- List all document libraries for a site ---
export async function listDocumentLibraries(
  siteUrl: string
): Promise<SharePointDrive[]> {
  const site = await getSiteByUrl(siteUrl);
  return await getSiteDrives(site.id);
}
