// ============================================================
// Microsoft Purview MCP Server - Notification Module
// Supports: Power Automate Flow, Copilot Studio Agent,
//           Teams Webhook, and Email (Graph API)
// ============================================================

import { graphRequest } from "./auth.js";

export interface NotificationConfig {
  powerAutomateUrl?: string;
  copilotStudioUrl?: string;
  teamsWebhookUrl?: string;
  emailRecipients?: string[];
  emailSender?: string;
}

// --- Standard payload sent to Power Automate / Copilot Studio ---
export interface AuditReportPayload {
  reportName: string;
  recordCount: number;
  startDate: string;
  endDate: string;
  filters: string;
  sharePointUrl: string;
  fileName: string;
  status: "success" | "failed";
  timestamp: string;
  scheduleName?: string;
  errorMessage?: string;
}

// ============================================================
// POWER AUTOMATE FLOW — HTTP Trigger
// ============================================================
export async function sendPowerAutomateNotification(
  flowUrl: string,
  payload: AuditReportPayload
): Promise<void> {
  const response = await fetch(flowUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Power Automate flow failed (${response.status}): ${errorText}`);
  }
}

// ============================================================
// COPILOT STUDIO AGENT — HTTP Trigger
// ============================================================
export async function sendCopilotStudioNotification(
  agentUrl: string,
  payload: AuditReportPayload
): Promise<void> {
  // Copilot Studio Direct Line or HTTP trigger
  const response = await fetch(agentUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      type: "message",
      text: `Purview Audit Report: ${payload.reportName}`,
      value: payload,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Copilot Studio agent failed (${response.status}): ${errorText}`);
  }
}

// ============================================================
// TEAMS WEBHOOK — Incoming Webhook (legacy fallback)
// ============================================================
export async function sendTeamsNotification(
  webhookUrl: string,
  title: string,
  message: string,
  sharePointUrl?: string,
  facts?: Array<{ name: string; value: string }>
): Promise<void> {
  const card = {
    type: "message",
    attachments: [
      {
        contentType: "application/vnd.microsoft.card.adaptive",
        contentUrl: null,
        content: {
          $schema: "http://adaptivecards.io/schemas/adaptive-card.json",
          type: "AdaptiveCard",
          version: "1.4",
          body: [
            {
              type: "ColumnSet",
              columns: [
                {
                  type: "Column",
                  width: "auto",
                  items: [
                    {
                      type: "Image",
                      url: "https://img.icons8.com/fluency/48/microsoft-purview.png",
                      size: "Small",
                      style: "Person",
                    },
                  ],
                },
                {
                  type: "Column",
                  width: "stretch",
                  items: [
                    {
                      type: "TextBlock",
                      text: "Microsoft Purview Audit",
                      weight: "Bolder",
                      size: "Medium",
                      color: "Accent",
                    },
                    {
                      type: "TextBlock",
                      text: new Date().toLocaleString("en-US", {
                        timeZone: "America/New_York",
                        dateStyle: "full",
                        timeStyle: "short",
                      }),
                      size: "Small",
                      isSubtle: true,
                      spacing: "None",
                    },
                  ],
                },
              ],
            },
            {
              type: "TextBlock",
              text: title,
              weight: "Bolder",
              size: "Large",
              wrap: true,
              spacing: "Medium",
            },
            {
              type: "TextBlock",
              text: message,
              wrap: true,
              spacing: "Small",
            },
            ...(facts && facts.length > 0
              ? [
                  {
                    type: "FactSet",
                    facts: facts.map((f) => ({
                      title: f.name,
                      value: f.value,
                    })),
                    spacing: "Medium",
                  },
                ]
              : []),
          ],
          actions: sharePointUrl
            ? [
                {
                  type: "Action.OpenUrl",
                  title: "📄 View Report in SharePoint",
                  url: sharePointUrl,
                  style: "positive",
                },
              ]
            : [],
        },
      },
    ],
  };

  const response = await fetch(webhookUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(card),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Teams webhook failed (${response.status}): ${errorText}`);
  }
}

// ============================================================
// EMAIL — Graph API SendMail
// ============================================================
export async function sendEmailNotification(
  recipients: string[],
  subject: string,
  htmlBody: string,
  senderAddress?: string
): Promise<void> {
  const message = {
    message: {
      subject,
      body: {
        contentType: "HTML",
        content: htmlBody,
      },
      toRecipients: recipients.map((email) => ({
        emailAddress: { address: email },
      })),
    },
    saveToSentItems: false,
  };

  const endpoint = senderAddress
    ? `/users/${senderAddress}/sendMail`
    : `/users/${recipients[0]}/sendMail`;

  await graphRequest("POST", endpoint, message);
}

// --- Build HTML email body ---
export function buildAuditReportEmailBody(params: {
  reportName: string;
  recordCount: number;
  dateRange: string;
  filters: string;
  sharePointUrl: string;
  fileName: string;
}): string {
  return `
<!DOCTYPE html>
<html>
<body style="font-family:'Segoe UI',Arial,sans-serif;margin:0;padding:20px;background:#f5f5f5;">
  <div style="max-width:600px;margin:0 auto;background:white;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.1);">
    <div style="background:linear-gradient(135deg,#0078d4,#5c2d91);padding:24px 30px;color:white;">
      <h1 style="margin:0;font-size:20px;">🔍 Purview Audit Report Ready</h1>
      <p style="margin:8px 0 0;opacity:0.9;font-size:14px;">${params.reportName}</p>
    </div>
    <div style="padding:30px;">
      <p style="color:#333;font-size:15px;line-height:1.6;margin-top:0;">Your scheduled Purview audit search has completed and the report has been uploaded to SharePoint.</p>
      <table style="width:100%;border-collapse:collapse;margin:20px 0;">
        <tr>
          <td style="padding:12px 16px;background:#f0f6ff;border-bottom:1px solid #e0e0e0;">
            <strong style="color:#0078d4;">Records Found</strong><br>
            <span style="font-size:24px;font-weight:700;color:#333;">${params.recordCount.toLocaleString()}</span>
          </td>
          <td style="padding:12px 16px;background:#f0f6ff;border-bottom:1px solid #e0e0e0;">
            <strong style="color:#0078d4;">Date Range</strong><br>
            <span style="font-size:14px;color:#333;">${params.dateRange}</span>
          </td>
        </tr>
        <tr>
          <td colspan="2" style="padding:12px 16px;background:#fafafa;">
            <strong style="color:#666;">Filters:</strong>
            <span style="color:#333;font-size:14px;"> ${params.filters}</span>
          </td>
        </tr>
      </table>
      <p style="color:#333;font-size:14px;"><strong>File:</strong> ${params.fileName}</p>
      <div style="text-align:center;margin:24px 0;">
        <a href="${params.sharePointUrl}" style="display:inline-block;background:#0078d4;color:white;text-decoration:none;padding:12px 32px;border-radius:6px;font-weight:600;font-size:15px;">📄 View Report in SharePoint</a>
      </div>
    </div>
    <div style="padding:16px 30px;background:#f9f9f9;border-top:1px solid #e0e0e0;text-align:center;">
      <p style="margin:0;color:#999;font-size:12px;">Automated by Microsoft Purview MCP Server • Power of Automation</p>
    </div>
  </div>
</body>
</html>`;
}

// ============================================================
// MASTER NOTIFY — Sends to all configured channels
// ============================================================
export async function notifyAuditComplete(params: {
  reportName: string;
  recordCount: number;
  startDate: string;
  endDate: string;
  filters: string;
  sharePointUrl: string;
  fileName: string;
  powerAutomateUrl?: string;
  copilotStudioUrl?: string;
  teamsWebhookUrl?: string;
  emailRecipients?: string[];
  emailSender?: string;
}): Promise<{
  powerAutomateNotified: boolean;
  copilotStudioNotified: boolean;
  teamsNotified: boolean;
  emailNotified: boolean;
  errors: string[];
}> {
  const errors: string[] = [];
  let powerAutomateNotified = false;
  let copilotStudioNotified = false;
  let teamsNotified = false;
  let emailNotified = false;

  const dateRange = `${params.startDate.slice(0, 10)} → ${params.endDate.slice(0, 10)}`;

  // Build standard payload for Power Automate / Copilot Studio
  const payload: AuditReportPayload = {
    reportName: params.reportName,
    recordCount: params.recordCount,
    startDate: params.startDate,
    endDate: params.endDate,
    filters: params.filters,
    sharePointUrl: params.sharePointUrl,
    fileName: params.fileName,
    status: "success",
    timestamp: new Date().toISOString(),
  };

  // 1. Power Automate Flow (PRIMARY)
  if (params.powerAutomateUrl) {
    try {
      await sendPowerAutomateNotification(params.powerAutomateUrl, payload);
      powerAutomateNotified = true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      errors.push(`Power Automate: ${msg}`);
    }
  }

  // 2. Copilot Studio Agent
  if (params.copilotStudioUrl) {
    try {
      await sendCopilotStudioNotification(params.copilotStudioUrl, payload);
      copilotStudioNotified = true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      errors.push(`Copilot Studio: ${msg}`);
    }
  }

  // 3. Teams Webhook (legacy fallback)
  if (params.teamsWebhookUrl) {
    try {
      await sendTeamsNotification(
        params.teamsWebhookUrl,
        `✅ ${params.reportName}`,
        `Audit search completed with **${params.recordCount.toLocaleString()}** records. Report uploaded to SharePoint.`,
        params.sharePointUrl,
        [
          { name: "Records", value: params.recordCount.toLocaleString() },
          { name: "Date Range", value: dateRange },
          { name: "Filters", value: params.filters || "None" },
          { name: "File", value: params.fileName },
        ]
      );
      teamsNotified = true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      errors.push(`Teams webhook: ${msg}`);
    }
  }

  // 4. Email
  if (params.emailRecipients?.length) {
    try {
      const htmlBody = buildAuditReportEmailBody({
        reportName: params.reportName,
        recordCount: params.recordCount,
        dateRange,
        filters: params.filters || "None",
        sharePointUrl: params.sharePointUrl,
        fileName: params.fileName,
      });
      await sendEmailNotification(
        params.emailRecipients,
        `🔍 Purview Audit Report: ${params.reportName}`,
        htmlBody,
        params.emailSender
      );
      emailNotified = true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      errors.push(`Email: ${msg}`);
    }
  }

  return { powerAutomateNotified, copilotStudioNotified, teamsNotified, emailNotified, errors };
}
